import { AnimatePresence, motion } from 'framer-motion'
import { invoke } from '@/lib/platform-api'
import {
	ChevronDown,
	ChevronRight,
	FilePlus,
	FolderPlus,
	Plus,
	Upload,
	X,
} from 'lucide-react'
import { useEffect, useRef, useState } from 'react'
import { useTranslation } from '../../i18n/react-i18next-compat'
import type { DropzoneProps } from '../../types/sender'
import { getPreviewFileIcon } from '../../lib/fileIcons'
import { Button } from '../ui/button'
import { Menu, MenuItem, MenuPopup, MenuTrigger } from '../ui/menu'
import {
	Tooltip,
	TooltipContent,
	TooltipProvider,
	TooltipTrigger,
} from '../ui/tooltip'

const getPathBaseName = (path: string) => {
	const normalized = path.replace(/\\/g, '/')
	return normalized.split('/').pop() ?? path
}

export function Dropzone({
	isDragActive,
	selectedPaths,
	selectedPath,
	pathType,
	showFullPath,
	isLoading,
	onToggleFullPath,
	onAddFiles,
	onAddFolders,
	onRemoveSelectedPath,
	onClearSelection,
	onEmptyClick,
	dropzoneDragProps,
}: DropzoneProps) {
	const { t } = useTranslation()
	const hasSelection = selectedPaths.length > 0
	const [mimeTypesByPath, setMimeTypesByPath] = useState<
		Record<string, string>
	>({})
	const previewScrollerRef = useRef<HTMLDivElement | null>(null)
	const previewScrollerCleanupRef = useRef<(() => void) | null>(null)
	const [_canScrollLeft, setCanScrollLeft] = useState(false)
	const [_canScrollRight, setCanScrollRight] = useState(false)

	useEffect(() => {
		if (!selectedPaths.length) {
			setMimeTypesByPath({})
			return
		}

		let mounted = true
		void (async () => {
			try {
				const mimeTypes = await invoke<(string | null)[]>(
					'get_paths_mime_types',
					{
						paths: selectedPaths,
					}
				)
				if (!mounted) return

				const nextMap: Record<string, string> = {}
				for (const [index, path] of selectedPaths.entries()) {
					const mimeType = mimeTypes[index]
					if (mimeType) nextMap[path] = mimeType
				}
				setMimeTypesByPath(nextMap)
			} catch (error) {
				console.error('Failed to resolve mime types for selected paths:', error)
			}
		})()

		return () => {
			mounted = false
		}
	}, [selectedPaths])

	const updateScrollHints = () => {
		const container = previewScrollerRef.current
		if (!container) {
			setCanScrollLeft(false)
			setCanScrollRight(false)
			return
		}

		const { scrollLeft, scrollWidth, clientWidth } = container
		const maxScrollLeft = scrollWidth - clientWidth
		setCanScrollLeft(scrollLeft > 4)
		setCanScrollRight(maxScrollLeft - scrollLeft > 4)
	}

	const attachPreviewScroller = (node: HTMLDivElement | null) => {
		previewScrollerCleanupRef.current?.()
		previewScrollerCleanupRef.current = null
		previewScrollerRef.current = node

		if (!node) {
			updateScrollHints()
			return
		}

		updateScrollHints()
		node.addEventListener('scroll', updateScrollHints, { passive: true })

		previewScrollerCleanupRef.current = () => {
			node.removeEventListener('scroll', updateScrollHints)
		}
	}

	useEffect(() => {
		const handleResize = () => {
			const container = previewScrollerRef.current
			if (!container) {
				setCanScrollLeft(false)
				setCanScrollRight(false)
				return
			}

			const { scrollLeft, scrollWidth, clientWidth } = container
			const maxScrollLeft = scrollWidth - clientWidth
			setCanScrollLeft(scrollLeft > 4)
			setCanScrollRight(maxScrollLeft - scrollLeft > 4)
		}

		window.addEventListener('resize', handleResize)
		return () => {
			previewScrollerCleanupRef.current?.()
			window.removeEventListener('resize', handleResize)
		}
	}, [])

	const getDropzoneStyles = () => {
		const baseStyles: React.CSSProperties = {}

		if (isDragActive) {
			return {
				...baseStyles,
				borderColor: 'var(--info)',
				backgroundColor: 'color-mix(in srgb, var(--info) 10%, transparent)',
			}
		}

		if (selectedPath && !isLoading) {
			return {
				...baseStyles,
			}
		}

		if (isLoading) {
			return {
				...baseStyles,
			}
		}

		return baseStyles
	}

	const getStatusText = () => {
		if (isLoading) return t('common:sender.preparingForTransport')
		if (isDragActive) return t('common:sender.dropFilesHere')
		if (selectedPaths.length > 1) return t('common:sender.itemSelected')
		if (selectedPath) {
			if (pathType === 'directory') return t('common:sender.folderSelected')
			if (pathType === 'file') return t('common:sender.fileSelected')
			return t('common:sender.itemSelected')
		}
		return t('common:sender.dragAndDrop')
	}

	const getSubText = () => {
		if (isLoading) return t('common:sender.pleaseWaitProcessing')
		if (selectedPaths.length > 1) {
			const firstPath = selectedPaths[0]
			const firstName = firstPath ? getPathBaseName(firstPath) : ''
			const extraCount = selectedPaths.length - 1
			return (
				<div>
					<div className="font-medium flex items-center justify-center">
						{t('common:sender.multipleItemsSelected', {
							count: extraCount,
							firstName:
								firstName.length > 40
									? `${firstName.slice(0, 40)}…`
									: firstName,
						})}
					</div>
				</div>
			)
		}
		if (selectedPath) {
			const fileName = getPathBaseName(selectedPath)
			const displayName =
				fileName.length > 60 ? `${fileName.slice(0, 60)}…` : fileName
			return (
				<div>
					<div
						className="font-medium cursor-pointer hover:opacity-80 transition-opacity flex items-center justify-center"
						onClick={onToggleFullPath}
						title="Click to toggle full path"
					>
						{displayName}
						<span className="-mr-2 hidden sm:block ">
							{showFullPath ? (
								<ChevronDown className="p-0.5 h-6 w-6" size={16} />
							) : (
								<ChevronRight className="p-0.5 h-6 w-6" size={16} />
							)}
						</span>
					</div>
					<div
						className="text-xs mt-1 opacity-75 break-all transition-opacity max-sm:hidden"
						style={{
							visibility: showFullPath ? 'visible' : 'hidden',
						}}
					>
						{selectedPath}
					</div>
				</div>
			)
		}
		return t('common:sender.orBrowse')
	}

	const renderPathIcon = (path: string) => {
		const fileName = getPathBaseName(path)
		const mimeType = mimeTypesByPath[path]
		return (
			<div className="origin-center scale-[1.85]">
				{getPreviewFileIcon(mimeType, fileName)}
			</div>
		)
	}

	const handlePreviewWheel = (event: React.WheelEvent<HTMLDivElement>) => {
		const container = event.currentTarget
		if (
			Math.abs(event.deltaY) <= Math.abs(event.deltaX) ||
			container.scrollWidth <= container.clientWidth
		) {
			return
		}

		container.scrollLeft += event.deltaY
		event.preventDefault()
	}

	return (
		<TooltipProvider>
			<motion.div
				layout
				transition={{ duration: 0.3, ease: 'easeInOut' }}
				style={getDropzoneStyles()}
				className="relative border-2 border-dashed rounded-lg text-center cursor-pointer transition-all duration-200 bg-accent text-accent-foreground h-fit min-h-64 border-border overflow-hidden"
				role={!hasSelection ? 'button' : undefined}
				tabIndex={!hasSelection && !isLoading ? 0 : undefined}
				aria-label={!hasSelection ? t('common:sender.orBrowse') : undefined}
				onClick={() => {
					if (hasSelection || isLoading || !onEmptyClick) return
					void onEmptyClick()
				}}
				onKeyDown={(event) => {
					if (hasSelection || isLoading || !onEmptyClick) return
					if (event.key === 'Enter' || event.key === ' ') {
						event.preventDefault()
						void onEmptyClick()
					}
				}}
				{...dropzoneDragProps}
			>
				{hasSelection && !isLoading ? (
					<>
						<div
							className="absolute top-3 left-3 z-30"
							onClick={(e) => e.stopPropagation()}
							onKeyDown={(e) => e.stopPropagation()}
						>
							<Menu>
								<MenuTrigger
									render={
										<Button
											type="button"
											variant="ghost"
											size="icon-sm"
											className="text-muted-foreground/70 hover:text-muted-foreground"
											aria-label={t('common:sender.addMore')}
											title={t('common:sender.addMore')}
										/>
									}
								>
									<Plus className="size-4" strokeWidth={1.75} />
								</MenuTrigger>
								<MenuPopup align="start" side="bottom" sideOffset={6}>
									<MenuItem
										onClick={() => {
											void onAddFiles()
										}}
									>
										<FilePlus />
										{t('common:sender.addFile')}
									</MenuItem>
									<MenuItem
										onClick={() => {
											void onAddFolders()
										}}
									>
										<FolderPlus />
										{t('common:sender.addFolder')}
									</MenuItem>
								</MenuPopup>
							</Menu>
						</div>
						<Tooltip>
							<TooltipTrigger
								render={
									<Button
										type="button"
										variant="ghost"
										size="icon-sm"
										onClick={(e) => {
											e.stopPropagation()
											onClearSelection()
										}}
										className="absolute top-3 right-3 z-30 text-muted-foreground"
										aria-label={t('common:sender.clearSelection')}
									>
										<X />
									</Button>
								}
							/>
							<TooltipContent>
								<p>{t('common:sender.clearSelection')}</p>
							</TooltipContent>
						</Tooltip>
					</>
				) : null}
				<motion.div
					key={selectedPath ? 'selected' : 'empty'}
					initial={{ opacity: 0, filter: 'blur(4px)' }}
					animate={{ opacity: 1, filter: 'blur(0px)' }}
					exit={{ opacity: 0, filter: 'blur(4px)' }}
					transition={{ duration: 0.25 }}
					className="h-full w-full p-4 sm:p-6"
				>
					{!hasSelection && (
						<div className="flex h-full min-h-52 w-full flex-col items-center justify-center space-y-4">
							<div className="flex justify-center items-center h-16">
								<Upload
									className="h-12 w-12 text-foreground/60 data-active:text-accent-foreground transition-transform"
									data-active={isDragActive ? 'true' : 'false'}
								/>
							</div>

							<div>
								<p className=" hidden sm:block text-lg font-medium mb-2 text-accent-foreground">
									{getStatusText()}
								</p>
								<div className="text-sm truncate text-muted-foreground">
									{getSubText()}
								</div>
							</div>
						</div>
					)}

					<AnimatePresence initial={false}>
						{hasSelection && (
							<motion.div
								key="selected-files-preview"
								initial={{ opacity: 0, y: 10 }}
								animate={{ opacity: 1, y: 0 }}
								exit={{ opacity: 0, y: 6 }}
								transition={{ duration: 0.2 }}
								className="flex h-full w-full flex-col items-center justify-center gap-4 pt-4"
							>
								<div
									ref={attachPreviewScroller}
									className="w-full overflow-x-auto overflow-y-hidden overscroll-x-contain"
									onWheel={handlePreviewWheel}
								>
									<motion.div
										layout
										className="inline-flex min-w-full justify-center gap-3 px-1"
									>
										<AnimatePresence initial={false}>
											{selectedPaths.map((path) => {
												const fileName = getPathBaseName(path)
												return (
													<motion.div
														key={path}
														layout
														initial={{
															opacity: 0,
															scale: 0.94,
														}}
														animate={{
															opacity: 1,
															scale: 1,
														}}
														exit={{
															opacity: 0,
															scale: 0.94,
														}}
														transition={{
															duration: 0.16,
														}}
														className="group relative w-44 shrink-0"
													>
														<div className="p-1">
															<div className="relative flex h-36 w-full items-center justify-center overflow-hidden">
																{renderPathIcon(path)}
																<Tooltip>
																	<TooltipTrigger
																		render={
																			<button
																				type="button"
																				onClick={(e) => {
																					e.stopPropagation()
																					onRemoveSelectedPath(path)
																				}}
																				className="absolute right-2 top-2 z-10 rounded-full border bg-background p-1 text-muted-foreground opacity-100 transition-opacity sm:opacity-0 sm:group-hover:opacity-100 focus-visible:opacity-100"
																				aria-label={`Remove ${fileName}`}
																			>
																				<X className="h-3.5 w-3.5" />
																			</button>
																		}
																	></TooltipTrigger>
																	<TooltipContent>
																		<p>
																			{t('common:sender.removeFromSelection')}
																		</p>
																	</TooltipContent>
																</Tooltip>
															</div>
														</div>

														<p className="mt-1 truncate text-sm text-muted-foreground">
															{fileName}
														</p>
													</motion.div>
												)
											})}
										</AnimatePresence>
									</motion.div>
								</div>
							</motion.div>
						)}
					</AnimatePresence>
				</motion.div>
			</motion.div>
		</TooltipProvider>
	)
}
