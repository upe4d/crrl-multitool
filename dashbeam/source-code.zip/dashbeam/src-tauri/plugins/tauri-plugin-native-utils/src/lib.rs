use tauri::{
    plugin::{Builder, TauriPlugin},
    Manager, Runtime,
};

pub use models::*;

#[cfg(desktop)]
mod desktop;
#[cfg(mobile)]
mod mobile;

mod commands;
mod error;
mod models;

pub use error::{Error, Result};

#[cfg(desktop)]
use desktop::NativeUtils;
#[cfg(mobile)]
use mobile::NativeUtils;

/// Extensions to [`tauri::App`], [`tauri::AppHandle`] and [`tauri::Window`] to access the native-utils APIs.
pub trait NativeUtilsExt<R: Runtime> {
    fn native_utils(&self) -> &NativeUtils<R>;
}

impl<R: Runtime, T: Manager<R>> crate::NativeUtilsExt<R> for T {
    fn native_utils(&self) -> &NativeUtils<R> {
        self.state::<NativeUtils<R>>().inner()
    }
}

/// Initializes the plugin.
pub fn init<R: Runtime>() -> TauriPlugin<R> {
    Builder::new("native-utils")
        .invoke_handler(tauri::generate_handler![
            commands::select_download_folder,
            commands::select_send_document,
            commands::select_send_folder,
            commands::consume_share_intent,
            commands::cancel_job,
            commands::export_to_tree,
            commands::open_download_folder,
            commands::export_to_media_store,
            commands::open_download_target,
            commands::get_window_insets,
            commands::start_presence_service,
            commands::stop_presence_service,
            commands::write_text_to_uri,
            commands::fetch_update_manifest,
        ])
        .setup(|app, api| {
            #[cfg(mobile)]
            let native_utils = mobile::init(app, api)?;
            #[cfg(desktop)]
            let native_utils = desktop::init(app, api)?;
            app.manage(native_utils);
            Ok(())
        })
        .build()
}
