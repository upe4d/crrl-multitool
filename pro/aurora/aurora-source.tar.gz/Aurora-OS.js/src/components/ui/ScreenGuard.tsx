import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MonitorX } from 'lucide-react';

// Мультитул: рабочая область помещается в окно ноутбука вместе с общей панелью.
const MIN_WIDTH = 1024;
const MIN_HEIGHT = 540; // Оставляем место для панели браузера и навигации Мультитула.

export const ScreenGuard = ({ children }: { children: React.ReactNode }) => {
  const [isInvalid, setIsInvalid] = useState(false);
  const [reason, setReason] = useState<string>('');

  useEffect(() => {
    const checkScreen = () => {
      const { innerWidth, innerHeight } = window;
      const isPortrait = innerHeight > innerWidth;

      if (isPortrait) {
        setIsInvalid(true);
        setReason('Нужно горизонтальное положение экрана');
        return;
      }

      if (innerWidth < MIN_WIDTH) {
        setIsInvalid(true);
        setReason(`Недостаточная ширина (${innerWidth} < ${MIN_WIDTH})`);
        return;
      }

      if (innerHeight < MIN_HEIGHT) {
        setIsInvalid(true);
        setReason(`Недостаточная высота (${innerHeight} < ${MIN_HEIGHT})`);
        return;
      }

      setIsInvalid(false);
    };

    checkScreen();
    window.addEventListener('resize', checkScreen);
    return () => window.removeEventListener('resize', checkScreen);
  }, []);

  return (
    <>
      <AnimatePresence>
        {isInvalid && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="fixed inset-0 z-9999 bg-black text-red-500 font-mono flex flex-col items-center justify-center p-8 select-none"
          >
            <div className="max-w-2xl w-full border-2 border-red-500/50 p-8 rounded-lg bg-red-950/10 backdrop-blur-sm shadow-[0_0_50px_rgba(220,38,38,0.2)]">
              <div className="flex items-center gap-4 mb-8">
                <MonitorX className="w-16 h-16 animate-pulse" />
                <div>
                  <h1 className="text-2xl font-bold tracking-tighter">Нужен большой экран</h1>
                  <p className="text-xl opacity-75">Симулятор рассчитан на компьютер</p>
                </div>
              </div>

              <div className="space-y-4 text-lg border-t border-red-500/30 pt-6">
                <p>
                  <span className="opacity-50 mr-4">Причина:</span>
                  <span className="font-bold">{reason}</span>
                </p>
                <p>
                  <span className="opacity-50 mr-4">Нужно:</span>
                  <span>{MIN_WIDTH}x{MIN_HEIGHT} (горизонтально)</span>
                </p>
                <p>
                  <span className="opacity-50 mr-4">Сейчас:</span>
                  <span>{window.innerWidth}x{window.innerHeight}</span>
                </p>
              </div>

              <div className="mt-12 text-sm opacity-50 text-center animate-pulse">
                Разверните окно или откройте симулятор на компьютере.
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      <div className={isInvalid ? 'blur-sm grayscale opacity-20 pointer-events-none' : ''}>
        {children}
      </div>
    </>
  );
};
