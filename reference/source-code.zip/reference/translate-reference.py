"""Создание локального русско-английского словаря по открытым шпаргалкам."""
from concurrent.futures import ThreadPoolExecutor, as_completed
from html.parser import HTMLParser
from pathlib import Path
import json
import re
import time
import urllib.parse
import urllib.request

root = Path(r'E:\CODEX SKILLS SOFT\file-news-suite\github-release-20261107\reference')
cache = root / 'translations-ru.json'
void = {'img', 'input', 'br', 'hr', 'meta', 'link', 'wbr', 'source', 'area', 'embed', 'param', 'track', 'col'}
blocked = {'head', 'script', 'style', 'pre', 'code', 'svg', 'nav', 'footer', 'button', 'textarea', 'kbd'}
allowed = {'p', 'li', 'td', 'th', 'h1', 'h2', 'h3', 'h4', 'h5', 'label'}
keep = {'python', 'javascript', 'typescript', 'html', 'css', 'php', 'sql', 'bash', 'json', 'yaml', 'xml', 'git', 'github', 'linux', 'windows', 'docker', 'kubernetes', 'chatgpt', 'react', 'vue', 'java', 'rust', 'go', 'npm', 'regex', 'svg', 'api', 'cli', 'ssh', 'http', 'https', 'url', 'uri', 'id', 'html5', 'css3', 'null', 'true', 'false', 'none', 'str', 'int', 'float', 'bool', 'dict', 'list', 'tuple', 'set'}

class Texts(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.stack = []
        self.items = set()

    def handle_starttag(self, tag, attrs):
        if tag not in void:
            self.stack.append(tag)

    def handle_endtag(self, tag):
        if tag in self.stack:
            pos = len(self.stack) - 1 - self.stack[::-1].index(tag)
            del self.stack[pos:]

    def handle_data(self, data):
        text = data.strip()
        if not text or not any(c.isascii() and c.isalpha() for c in text): return
        if any(tag in self.stack for tag in blocked) or not any(tag in self.stack for tag in allowed): return
        if text.lower() in keep or re.fullmatch(r'[\w.$/@:-]+', text) and ('_' in text or '.' in text or '$' in text): return
        if len(text) > 1800 or '@@@0000@@@' in text: return
        self.items.add(text)

all_texts = set()
for page in root.rglob('*.html'):
    parser = Texts()
    parser.feed(page.read_text(encoding='utf-8'))
    all_texts.update(parser.items)

translations = json.loads(cache.read_text(encoding='utf-8')) if cache.exists() else {}
pending = sorted(all_texts - translations.keys())
chunks = []
batch = []
size = 0
for item in pending:
    if batch and (size + len(item) > 2200 or len(batch) >= 75):
        chunks.append(batch)
        batch, size = [], 0
    batch.append(item)
    size += len(item) + 14
if batch: chunks.append(batch)

separator = '\n@@@0000@@@\n'
def request(items):
    query = urllib.parse.urlencode({'client':'gtx', 'sl':'en', 'tl':'ru', 'dt':'t', 'q':separator.join(items)})
    for attempt in range(4):
        try:
            req = urllib.request.Request('https://translate.googleapis.com/translate_a/single?' + query, headers={'User-Agent':'Mozilla/5.0'})
            with urllib.request.urlopen(req, timeout=35) as response:
                result = json.load(response)
            result = ''.join(part[0] for part in result[0] if part[0])
            parts = re.split(r'\s*@@@0000@@@\s*', result)
            if len(parts) == len(items): return dict(zip(items, parts))
            if len(items) > 1:
                mid = len(items) // 2
                return request(items[:mid]) | request(items[mid:])
            return {}
        except Exception:
            time.sleep(1 + 2 ** attempt)
    return {}

print(f'Переводимых текстов: {len(all_texts)}; осталось пакетов: {len(chunks)}', flush=True)
failed = 0
with ThreadPoolExecutor(max_workers=4) as pool:
    futures = [pool.submit(request, chunk) for chunk in chunks]
    for index, future in enumerate(as_completed(futures), 1):
        result = future.result()
        if not result: failed += 1
        translations.update(result)
        if index % 25 == 0 or index == len(chunks):
            tmp = cache.with_suffix('.tmp')
            tmp.write_text(json.dumps(translations, ensure_ascii=False, separators=(',', ':')), encoding='utf-8')
            tmp.replace(cache)
            print(f'Пакетов: {index}/{len(chunks)}; готово текстов: {len(translations)}; не удалось пакетов: {failed}', flush=True)
print('Перевод готов; отсутствуют:', len(all_texts - translations.keys()), flush=True)
