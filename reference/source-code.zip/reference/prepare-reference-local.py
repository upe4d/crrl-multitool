from pathlib import Path
import json
import re
import shutil
import subprocess
import zipfile

# Создаём отдельную копию справочника и не затрагиваем его исходники.
base = Path(r'E:\CODEX SKILLS SOFT\file-news-suite')
source = base / 'imported-reference-20261115'
site = base / 'github-release-20261107'
target = site / 'reference'
shutil.copytree(source / 'public', target)
shutil.copy2(source / 'LICENSE', target / 'LICENSE.txt')
for name in ['multitool.css', 'multitool.js', 'runner.js']:
    shutil.copy2(base / 'reference-shell' / name, target / name)

header = '''<header class="mt-reference-header"><a href="/" class="mt-reference-brand">МУЛЬТИ<span>ТУЛ</span></a><nav aria-label="Разделы мультитула"><a href="/">Мультитул</a><a href="/#catalogs">Дизайн и разработка</a><a href="/pro/">Профи</a></nav><a href="https://github.com/Fechin/reference" target="_blank" rel="noopener noreferrer">Fechin / GPL-3.0 ↗</a><button type="button" id="mt-reference-language">EN</button></header><div class="mt-reference-note" data-ru="Интерфейс справочника переведён частично; содержимое шпаргалок пока на английском." data-en="The interface is partially translated; cheat sheet content is currently in English."></div>'''
insert = '<script src="/reference/runner.js?v=20261115-1" defer></script><link rel="stylesheet" href="/reference/multitool.css?v=20261115-1"><script src="/reference/multitool.js?v=20261115-1" defer></script>'

def local_path(match):
    prefix, path, quote = match.groups()
    if path.startswith('//'):
        return match.group(0)
    path = path.replace('/reference/reference/', '/reference/')
    if path.startswith('/reference/'):
        return prefix + path + quote
    if path == '/':
        path = '/reference/'
    else:
        path = '/reference' + path
        bare, sep, fragment = path.partition('#')
        if bare.count('/') == 2 and (target / (bare.rsplit('/', 1)[-1] + '.html')).is_file():
            path = bare + '.html' + (sep + fragment if sep else '')
    return prefix + path + quote

for path in target.rglob('*.html'):
    html = path.read_text(encoding='utf-8')
    html = html.replace('https://tools.crrl.ru/reference/reference/', 'https://tools.crrl.ru/reference/')
    html = re.sub(r'''((?:href|src|action)=["'])(/[^"']*)(["'])''', local_path, html)
    # Чужой service worker не должен регистрироваться на корне мультитула.
    html = re.sub(r'<!-- PWA Service Worker Registration -->\s*<script>.*?</script>', '', html, flags=re.S)
    html = html.replace('localStorage.theme', 'localStorage.reference_theme').replace("'theme' in localStorage", "'reference_theme' in localStorage")
    if path.name == 'python.html':
        html = re.sub(r'<!-- see https://livecodes\.io/docs/ and https://livecodes\.io/docs/sdk -->\s*<script src="https://cdn\.jsdelivr\.net/npm/livecodes@0\.7\.2/livecodes\.umd\.js"></script>\s*<script>.*?</script>', '', html, flags=re.S)
    html = html.replace('</head>', insert + '</head>', 1)
    html = re.sub(r'(<body\b[^>]*>)', lambda m: m.group(1) + header, html, count=1, flags=re.I)
    path.write_text(html, encoding='utf-8')

js = target / 'js/main.js'
text = js.read_text(encoding='utf-8').replace('/search.json?v=1.0', '/reference/search.json?v=1.0').replace("'/js/fuse_7.1.0.js'", "'/reference/js/fuse_7.1.0.js'").replace('localStorage.theme', 'localStorage.reference_theme')
js.write_text(text, encoding='utf-8')
search = target / 'search.json'
items = json.loads(search.read_text(encoding='utf-8'))
for item in items:
    if isinstance(item.get('path'), str) and item['path'].startswith('/'):
        item['path'] = '/reference' + item['path']
search.write_text(json.dumps(items, ensure_ascii=False, separators=(',', ':')), encoding='utf-8')

# Исходники модифицированной версии доступны посетителям вместе с лицензией.
files = subprocess.check_output(['git', 'ls-files', '-z'], cwd=source).decode('utf-8').split('\0')
with zipfile.ZipFile(target / 'source-code.zip', 'w', zipfile.ZIP_DEFLATED) as out:
    for name in filter(None, files):
        p = source / name
        if p.is_file(): out.write(p, 'reference/' + name)
    for name in ['_config.local.yml', 'codex-node-compat.cjs']:
        out.write(source / name, 'reference/' + name)
    for name in ['multitool.css', 'multitool.js', 'runner.js']:
        out.write(base / 'reference-shell' / name, 'reference/multitool/' + name)
    out.write(__file__, 'reference/prepare-reference-local.py')
shutil.copytree(base / 'reference-runner-build/package', target / 'runner')
print('pages:', len(list(target.rglob('*.html'))), 'search entries:', len(items))
