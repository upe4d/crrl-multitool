require('node:buffer').SlowBuffer ||= require('node:buffer').Buffer;
