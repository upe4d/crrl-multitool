import React from 'react';
import {createRoot} from 'react-dom/client';
import {createRootRoute,createRoute,createRouter,RouterProvider,Outlet,Link,redirect} from '@tanstack/react-router';
import {QueryClient,QueryClientProvider} from '@tanstack/react-query';
import {ThemeProvider} from '../src/components/theme-provider';
import {Toaster} from '../src/components/ui/sonner';
import {Route as FormLayout} from '../src/routes/form-builder';
import {Route as FormIndex} from '../src/routes/form-builder/index';
import {Route as TableLayout} from '../src/routes/table-builder';
import {Route as TableIndex} from '../src/routes/table-builder/index';
import '../src/styles.css';
import './shell.css';
import './translate.js';
// Используем исходные редакторы TANCN и локальное хранилище вместо серверной оболочки.
const queryClient=new QueryClient();
function Shell(){return <ThemeProvider defaultTheme="dark" storageKey="multitool-tancn-theme"><header className="mt-tancn-header"><a href="/">← Мультитул</a><strong>TANCN</strong><nav><Link to="/form-builder">Формы</Link><Link to="/table-builder">Таблицы</Link></nav><a href="https://github.com/Vijayabaskar56/tancn" target="_blank" rel="noopener noreferrer">Автор / MIT ↗</a></header><Outlet/><Toaster richColors/></ThemeProvider>}
const root=createRootRoute({component:Shell});
const home=createRoute({getParentRoute:()=>root,path:'/',beforeLoad:()=>{throw redirect({to:'/form-builder'})}});
const forms=createRoute({getParentRoute:()=>root,path:'form-builder',component:FormLayout.options.component as any,loader:FormLayout.options.loader as any});
const formIndex=createRoute({getParentRoute:()=>forms,path:'/',component:FormIndex.options.component as any});
const tables=createRoute({getParentRoute:()=>root,path:'table-builder',component:TableLayout.options.component as any});
const tableIndex=createRoute({getParentRoute:()=>tables,path:'/',component:TableIndex.options.component as any});
const router=createRouter({basepath:'/tancn',routeTree:root.addChildren([home,forms.addChildren([formIndex]),tables.addChildren([tableIndex])]),context:{queryClient}});
createRoot(document.getElementById('root')!).render(<QueryClientProvider client={queryClient}><RouterProvider router={router}/></QueryClientProvider>);
