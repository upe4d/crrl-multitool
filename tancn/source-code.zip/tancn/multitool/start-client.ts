// Эта сборка работает в браузере: выбираем клиентскую ветку изоморфных функций.
export function createIsomorphicFn(){
 let implementation=(..._args:any[])=>undefined;
 const call:any=(...args:any[])=>implementation(...args);
 call.server=()=>call;
 call.client=(fn:any)=>{implementation=fn;return call};
 return call;
}
export const createClientOnlyFn=(fn:any)=>fn;
