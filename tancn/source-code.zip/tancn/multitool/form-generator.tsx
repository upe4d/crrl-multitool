import {setActiveTab} from '../src/services/form-builder.service';
// ИИ не вызывается без настроенного API: основной конструктор работает автономно.
export function FormGenerator(){return <section className="p-4 space-y-3"><h3>Создание по описанию</h3><p>Для ИИ-генерации требуется подключение API модели. В этой установке он не настроен.</p><p>Создайте форму из готового шаблона или добавьте поля вручную.</p><button className="border rounded px-3 py-2" onClick={()=>setActiveTab('template')}>Открыть шаблоны</button></section>}
