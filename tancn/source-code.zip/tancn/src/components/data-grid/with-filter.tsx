import type { DragEndEvent } from "@dnd-kit/core";
import { arrayMove } from "@dnd-kit/sortable";
import {
	type ColumnDef,
	getCoreRowModel,
	getFilteredRowModel,
	getPaginationRowModel,
	getSortedRowModel,
	type PaginationState,
	type SortingState,
	useReactTable,
} from "@tanstack/react-table";
import {
	Building,
	Calendar,
	DollarSign,
	FunnelX,
	Mail,
	MapPin,
	User,
} from "lucide-react";
import { useCallback, useMemo, useState } from "react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { DataGrid, DataGridContainer } from "@/components/ui/data-grid";
import { DataGridColumnHeader } from "@/components/ui/data-grid-column-header";
import { DataGridPagination } from "@/components/ui/data-grid-pagination";
import {
	createFilter,
	type Filter,
	type FilterFieldConfig,
	Filters,
} from "@/components/ui/filters";
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area";
import { DataGridTableDnd } from "../ui/data-grid-table-dnd";

interface IData {
	id: string;
	name: string;
	availability: "online" | "away" | "busy" | "offline";
	avatar: string;
	status: "active" | "inactive";
	flag: string; // Emoji flags
	email: string;
	company: string;
	role: string;
	joined: string;
	location: string;
	balance: number;
	skills: string[];
}

const demoData: IData[] = [
	{
		id: "1",
		name: "Kathryn Campbell",
		availability: "online",
		avatar: "1.png",
		status: "active",
		flag: "🇺🇸",
		email: "kathryn@apple.com",
		company: "Apple",
		role: "CEO",
		joined: "2021-04-15",
		location: "San Francisco, USA",
		balance: 5143.03,
		skills: [
			"Leadership",
			"Strategy",
			"Innovation",
			"Product Vision",
			"testing",
			"testing",
		],
	},
	{
		id: "2",
		name: "Robert Smith",
		availability: "away",
		avatar: "2.png",
		status: "inactive",
		flag: "🇬🇧",
		email: "robert@openai.com",
		company: "OpenAI",
		role: "CTO",
		joined: "2020-07-20",
		location: "London, UK",
		balance: 4321.87,
		skills: ["AI/ML", "System Architecture", "Team Leadership", "Research"],
	},
	{
		id: "3",
		name: "Sophia Johnson",
		availability: "busy",
		avatar: "3.png",
		status: "active",
		flag: "🇨🇦",
		email: "sophia@meta.com",
		company: "Meta",
		role: "Designer",
		joined: "2019-03-12",
		location: "Toronto, Canada",
		balance: 7654.98,
		skills: ["UI/UX Design", "Figma", "User Research", "Prototyping"],
	},
	{
		id: "4",
		name: "Lucas Walker",
		availability: "offline",
		avatar: "4.png",
		status: "inactive",
		flag: "🇦🇺",
		email: "lucas@tesla.com",
		company: "Tesla",
		role: "Developer",
		joined: "2022-01-18",
		location: "Sydney, Australia",
		balance: 3456.45,
		skills: ["React", "TypeScript", "Node.js", "Python"],
	},
	{
		id: "5",
		name: "Emily Davis",
		availability: "online",
		avatar: "5.png",
		status: "active",
		flag: "🇩🇪",
		email: "emily@sap.com",
		company: "SAP",
		role: "Lawyer",
		joined: "2023-05-23",
		location: "Berlin, Germany",
		balance: 9876.54,
		skills: ["Contract Law", "Compliance", "Negotiation", "Legal Research"],
	},
	{
		id: "6",
		name: "James Lee",
		availability: "away",
		avatar: "6.png",
		status: "active",
		flag: "🇲🇾",
		email: "james@keenthemes.com",
		company: "Keenthemes",
		role: "Director",
		joined: "2018-11-30",
		location: "Kuala Lumpur, MY",
		balance: 6214.22,
		skills: ["Business Strategy", "Operations", "Team Management", "Analytics"],
	},
	{
		id: "7",
		name: "Isabella Martinez",
		availability: "busy",
		avatar: "7.png",
		status: "inactive",
		flag: "🇪🇸",
		email: "isabella@bbva.es",
		company: "BBVA",
		role: "Product Manager",
		joined: "2021-06-14",
		location: "Barcelona, Spain",
		balance: 5321.77,
		skills: ["Product Strategy", "Agile", "User Stories", "Roadmapping"],
	},
	{
		id: "8",
		name: "Benjamin Harris",
		availability: "offline",
		avatar: "8.png",
		status: "active",
		flag: "🇯🇵",
		email: "benjamin@sony.jp",
		company: "Sony",
		role: "Marketing Lead",
		joined: "2020-10-22",
		location: "Tokyo, Japan",
		balance: 8452.39,
		skills: ["Digital Marketing", "SEO", "Content Strategy", "Analytics"],
	},
	{
		id: "9",
		name: "Olivia Brown",
		availability: "online",
		avatar: "9.png",
		status: "active",
		flag: "🇫🇷",
		email: "olivia@lvmh.fr",
		company: "LVMH",
		role: "Data Scientist",
		joined: "2019-09-17",
		location: "Paris, France",
		balance: 7345.1,
		skills: ["Python", "Machine Learning", "SQL", "Data Visualization"],
	},
	{
		id: "10",
		name: "Michael Clark",
		availability: "away",
		avatar: "10.png",
		status: "inactive",
		flag: "🇮🇹",
		email: "michael@eni.it",
		company: "ENI",
		role: "Engineer",
		joined: "2023-02-11",
		location: "Milan, Italy",
		balance: 5214.88,
		skills: ["Mechanical Engineering", "CAD", "Project Management", "Safety"],
	},
	{
		id: "11",
		name: "Ava Wilson",
		availability: "busy",
		avatar: "11.png",
		status: "active",
		flag: "🇧🇷",
		email: "ava@vale.br",
		company: "Vale",
		role: "Software Engineer",
		joined: "2022-12-01",
		location: "Rio de Janeiro, Brazil",
		balance: 9421.5,
		skills: ["Java", "Spring Boot", "Microservices", "AWS"],
	},
	{
		id: "12",
		name: "David Young",
		availability: "offline",
		avatar: "12.png",
		status: "active",
		flag: "🇮🇳",
		email: "david@tata.in",
		company: "Tata",
		role: "Sales Manager",
		joined: "2020-03-27",
		location: "Mumbai, India",
		balance: 4521.67,
		skills: ["Sales Strategy", "CRM", "Negotiation", "Client Relations"],
	},
];

// Availability status component
const AvailabilityStatus = ({ availability }: { availability: string }) => {
	const getStatusColor = (status: string) => {
		switch (status) {
			case "online":
				return "bg-green-500";
			case "away":
				return "bg-yellow-500";
			case "busy":
				return "bg-red-500";
			case "offline":
				return "bg-gray-400";
			default:
				return "bg-gray-400";
		}
	};

	const getStatusLabel = (status: string) => {
		switch (status) {
			case "online":
				return "Online";
			case "away":
				return "Away";
			case "busy":
				return "Busy";
			case "offline":
				return "Offline";
			default:
				return "Unknown";
		}
	};

	return (
		<div className="flex items-center gap-1.5">
			<div className={`size-2 rounded-full ${getStatusColor(availability)}`} />
			<span className="text-sm text-muted-foreground">
				{getStatusLabel(availability)}
			</span>
		</div>
	);
};

export default function DataGridWithFiltersDemo() {
	const [pagination, setPagination] = useState<PaginationState>({
		pageIndex: 0,
		pageSize: 5,
	});
	const [sorting, setSorting] = useState<SortingState>([
		{ id: "name", desc: false },
	]);
	const [filters, setFilters] = useState<Filter[]>([
		createFilter("status", "is", ["active"]),
	]);
	const [expandedSkillsRows, setExpandedSkillsRows] = useState<Set<string>>(
		new Set(),
	);

	// Filter field configurations
	const fields: FilterFieldConfig[] = [
		{
			key: "name",
			label: "Name",
			icon: <User className="size-3.5" />,
			type: "text",
			className: "w-40",
			placeholder: "Search names...",
		},
		{
			key: "email",
			label: "Email",
			icon: <Mail className="size-3.5" />,
			type: "email",
			className: "w-48",
			placeholder: "user@example.com",
		},
		{
			key: "company",
			label: "Company",
			icon: <Building className="size-3.5" />,
			type: "select",
			searchable: true,
			className: "w-[180px]",
			options: [
				{ value: "Apple", label: "Apple" },
				{ value: "OpenAI", label: "OpenAI" },
				{ value: "Meta", label: "Meta" },
				{ value: "Tesla", label: "Tesla" },
				{ value: "SAP", label: "SAP" },
				{ value: "Keenthemes", label: "Keenthemes" },
				{ value: "BBVA", label: "BBVA" },
				{ value: "Sony", label: "Sony" },
				{ value: "LVMH", label: "LVMH" },
				{ value: "ENI", label: "ENI" },
				{ value: "Vale", label: "Vale" },
				{ value: "Tata", label: "Tata" },
			],
		},
		{
			key: "role",
			label: "Role",
			icon: <User className="size-3.5" />,
			type: "select",
			searchable: true,
			className: "w-[160px]",
			options: [
				{ value: "CEO", label: "CEO" },
				{ value: "CTO", label: "CTO" },
				{ value: "Designer", label: "Designer" },
				{ value: "Developer", label: "Developer" },
				{ value: "Lawyer", label: "Lawyer" },
				{ value: "Director", label: "Director" },
				{ value: "Product Manager", label: "Product Manager" },
				{ value: "Marketing Lead", label: "Marketing Lead" },
				{ value: "Data Scientist", label: "Data Scientist" },
				{ value: "Engineer", label: "Engineer" },
				{ value: "Software Engineer", label: "Software Engineer" },
				{ value: "Sales Manager", label: "Sales Manager" },
			],
		},
		{
			key: "status",
			label: "Status",
			icon: <User className="size-3.5" />,
			type: "select",
			searchable: false,
			className: "w-[140px]",
			options: [
				{
					value: "active",
					label: "Active",
					icon: <div className="size-2 bg-green-500 rounded-full"></div>,
				},
				{
					value: "inactive",
					label: "Inactive",
					icon: <div className="size-2 bg-destructive rounded-full"></div>,
				},
				{
					value: "archived",
					label: "Archived",
					icon: <div className="size-2 bg-zinc-400 rounded-full"></div>,
				},
			],
		},
		{
			key: "availability",
			label: "Availability",
			icon: <User className="size-3.5" />,
			type: "select",
			searchable: false,
			className: "w-[160px]",
			options: [
				{
					value: "online",
					label: "Online",
					icon: (
						<div className="flex items-center gap-2">
							<div className="size-2 rounded-full bg-green-500" />
							<span>Online</span>
						</div>
					),
				},
				{
					value: "away",
					label: "Away",
					icon: (
						<div className="flex items-center gap-2">
							<div className="size-2 rounded-full bg-yellow-500" />
							<span>Away</span>
						</div>
					),
				},
				{
					value: "busy",
					label: "Busy",
					icon: (
						<div className="flex items-center gap-2">
							<div className="size-2 rounded-full bg-red-500" />
							<span>Busy</span>
						</div>
					),
				},
				{
					value: "offline",
					label: "Offline",
					icon: (
						<div className="flex items-center gap-2">
							<div className="size-2 rounded-full bg-gray-400" />
							<span>Offline</span>
						</div>
					),
				},
			],
		},
		{
			key: "location",
			label: "Location",
			icon: <MapPin className="size-3.5" />,
			type: "text",
			className: "w-40",
			placeholder: "Search locations...",
		},
		{
			key: "joined",
			label: "Joined Date",
			icon: <Calendar className="size-3.5" />,
			type: "date",
			className: "w-36",
		},
		{
			key: "balance",
			label: "Balance",
			icon: <DollarSign className="size-3.5" />,
			type: "number",
			min: 0,
			max: 10000,
			step: 100,
			className: "w-32",
		},
		{
			key: "skills",
			label: "Skills",
			icon: <User className="size-3.5" />,
			type: "multiselect",
			searchable: true,
			className: "w-48",
			options: Array.from(
				new Set(demoData.flatMap((person) => person.skills)),
			).map((skill) => ({
				value: skill,
				label: skill,
			})),
		},
	];

	// Apply filters to data - only apply filters with non-empty values
	const filteredData = useMemo(() => {
		let filtered = [...demoData];

		// Filter out empty filters before applying
		const activeFilters = filters.filter((filter) => {
			const { values } = filter;

			// Check if filter has meaningful values
			if (!values || values.length === 0) return false;

			// For text/string values, check if they're not empty strings
			if (
				values.every(
					(value) => typeof value === "string" && value.trim() === "",
				)
			)
				return false;

			// For number values, check if they're not null/undefined
			if (values.every((value) => value === null || value === undefined))
				return false;

			// For arrays, check if they're not empty
			if (values.every((value) => Array.isArray(value) && value.length === 0))
				return false;

			return true;
		});

		activeFilters.forEach((filter) => {
			const { field, operator, values } = filter;

			filtered = filtered.filter((item) => {
				const fieldValue = item[field as keyof IData];

				switch (operator) {
					case "is_any_of":
						if (field === "skills" && Array.isArray(fieldValue)) {
							// For multiselect, check if any of the selected skills are in the person's skills
							return values.some((selectedSkill) =>
								fieldValue.includes(String(selectedSkill)),
							);
						}
						return values.some((value) => value === fieldValue);
					case "is_not_any_of":
						if (field === "skills" && Array.isArray(fieldValue)) {
							// For multiselect, check if none of the selected skills are in the person's skills
							return !values.some((selectedSkill) =>
								fieldValue.includes(String(selectedSkill)),
							);
						}
						return !values.some((value) => value === fieldValue);
					case "includes_all":
						if (field === "skills" && Array.isArray(fieldValue)) {
							// Check if person has ALL of the selected skills
							return values.every((selectedSkill) =>
								fieldValue.includes(String(selectedSkill)),
							);
						}
						return values.every((value) => value === fieldValue);
					case "excludes_all":
						if (field === "skills" && Array.isArray(fieldValue)) {
							// Check if person has NONE of the selected skills
							return !values.some((selectedSkill) =>
								fieldValue.includes(String(selectedSkill)),
							);
						}
						return !values.some((value) => value === fieldValue);
					case "is":
						return values.includes(fieldValue);
					case "is_not":
						return !values.includes(fieldValue);
					case "contains":
						if (field === "skills" && Array.isArray(fieldValue)) {
							return values.some((value) =>
								fieldValue.some((skill: string) =>
									skill.toLowerCase().includes(String(value).toLowerCase()),
								),
							);
						}
						return values.some((value) =>
							String(fieldValue)
								.toLowerCase()
								.includes(String(value).toLowerCase()),
						);
					case "not_contains":
						if (field === "skills" && Array.isArray(fieldValue)) {
							return !values.some((value) =>
								fieldValue.some((skill: string) =>
									skill.toLowerCase().includes(String(value).toLowerCase()),
								),
							);
						}
						return !values.some((value) =>
							String(fieldValue)
								.toLowerCase()
								.includes(String(value).toLowerCase()),
						);
					case "equals":
						return fieldValue === values[0];
					case "not_equals":
						return fieldValue !== values[0];
					case "greater_than":
						return Number(fieldValue) > Number(values[0]);
					case "less_than":
						return Number(fieldValue) < Number(values[0]);
					case "greater_than_or_equal":
						return Number(fieldValue) >= Number(values[0]);
					case "less_than_or_equal":
						return Number(fieldValue) <= Number(values[0]);
					case "between":
						if (values.length >= 2) {
							const min = Number(values[0]);
							const max = Number(values[1]);
							return Number(fieldValue) >= min && Number(fieldValue) <= max;
						}
						return true;
					case "not_between":
						if (values.length >= 2) {
							const min = Number(values[0]);
							const max = Number(values[1]);
							return Number(fieldValue) < min || Number(fieldValue) > max;
						}
						return true;
					case "before":
						return new Date(String(fieldValue)) < new Date(String(values[0]));
					case "after":
						return new Date(String(fieldValue)) > new Date(String(values[0]));
					default:
						return true;
				}
			});
		});

		return filtered;
	}, [filters]);

	const handleFiltersChange = useCallback((newFilters: Filter[]) => {
		setFilters(newFilters);
		// Reset pagination when filters change
		setPagination((prev) => ({ ...prev, pageIndex: 0 }));
	}, []);

	const columns = useMemo<ColumnDef<IData>[]>(
		() => [
			{
				accessorKey: "name",
				id: "name",
				header: ({ column }) => (
					<DataGridColumnHeader title="Staff" column={column} />
				),
				cell: ({ row }) => {
					return (
						<div className="flex items-center gap-3">
							<Avatar className="size-8">
								<AvatarImage
									src={`/media/avatars/${row.original.avatar}`}
									alt={row.original.name}
								/>
								<AvatarFallback>{row.original.name?.charAt(0)}</AvatarFallback>
							</Avatar>
							<div className="space-y-px">
								<div className="font-medium text-foreground">
									{row.original.name}
								</div>
								<div className="text-muted-foreground text-xs truncate max-w-[120px]">
									{row.original.email}
								</div>
							</div>
						</div>
					);
				},
				size: 200,
				enableSorting: true,
				enableHiding: false,
			},
			{
				accessorKey: "company",
				id: "company",
				header: ({ column }) => (
					<DataGridColumnHeader title="Company" column={column} />
				),
				cell: (info) => <span>{info.getValue() as string}</span>,
				size: 150,
				enableSorting: true,
				enableHiding: false,
			},
			{
				accessorKey: "role",
				id: "role",
				header: ({ column }) => (
					<DataGridColumnHeader title="Occupation" column={column} />
				),
				cell: (info) => <span>{info.getValue() as string}</span>,
				size: 125,
				enableSorting: true,
				enableHiding: false,
			},
			{
				accessorKey: "status",
				id: "status",
				header: "Status",
				cell: ({ row }) => {
					const status = row.original.status;

					if (status === "active") {
						return <Badge>Active</Badge>;
					} else if (status === "inactive") {
						return <Badge variant="destructive">Inactive</Badge>;
					} else if (status === "archived") {
						return <Badge variant="secondary">Archived</Badge>;
					}
				},
				size: 100,
			},
			{
				accessorKey: "availability",
				id: "availability",
				header: "Availability",
				cell: ({ row }) => (
					<AvailabilityStatus availability={row.original.availability} />
				),
				size: 120,
				enableSorting: true,
			},
			{
				accessorKey: "location",
				id: "location",
				header: ({ column }) => (
					<DataGridColumnHeader title="Location" column={column} />
				),
				cell: ({ row }) => (
					<div className="flex items-center gap-2">
						<span className="text-lg">{row.original.flag}</span>
						<span>{row.original.location}</span>
					</div>
				),
				size: 180,
				enableSorting: true,
			},
			{
				accessorKey: "balance",
				id: "balance",
				header: ({ column }) => (
					<DataGridColumnHeader title="Balance" column={column} />
				),
				cell: ({ row }) => (
					<span className="font-medium">
						${row.original.balance.toLocaleString()}
					</span>
				),
				size: 120,
				enableSorting: true,
			},
			{
				accessorKey: "skills",
				id: "skills",
				header: ({ column }) => (
					<DataGridColumnHeader title="Skills" column={column} />
				),
				cell: ({ row }) => {
					const isExpanded = expandedSkillsRows.has(row.original.id);
					const skillsToShow = isExpanded
						? row.original.skills
						: row.original.skills.slice(0, 2);
					const hasMoreSkills = row.original.skills.length > 2;

					return (
						<div className="flex flex-wrap gap-1">
							{skillsToShow.map((skill, index) => (
								<Badge key={index} variant="secondary" className="text-xs">
									{skill}
								</Badge>
							))}
							{hasMoreSkills && (
								<Badge
									variant="outline"
									className="text-xs cursor-pointer hover:bg-secondary transition-colors"
									onClick={() => {
										setExpandedSkillsRows((prev) => {
											const newSet = new Set(prev);
											if (isExpanded) {
												newSet.delete(row.original.id);
											} else {
												newSet.add(row.original.id);
											}
											return newSet;
										});
									}}
								>
									{isExpanded ? "−" : `+${row.original.skills.length - 2}`}
								</Badge>
							)}
						</div>
					);
				},
				size: 180,
				enableSorting: false,
			},
		],
		[expandedSkillsRows],
	);

	const [columnOrder, setColumnOrder] = useState<string[]>(
		columns.map((column) => column.id as string),
	);

	const table = useReactTable({
		columns,
		data: filteredData,
		pageCount: Math.ceil((filteredData?.length || 0) / pagination.pageSize),
		getRowId: (row: IData) => row.id,
		state: {
			pagination,
			sorting,
			columnOrder,
		},
		onColumnOrderChange: setColumnOrder,
		onPaginationChange: setPagination,
		onSortingChange: setSorting,
		getCoreRowModel: getCoreRowModel(),
		getFilteredRowModel: getFilteredRowModel(),
		getPaginationRowModel: getPaginationRowModel(),
		getSortedRowModel: getSortedRowModel(),
	});
	const handleDragEnd = (event: DragEndEvent) => {
		const { active, over } = event;
		if (active && over && active.id !== over.id) {
			setColumnOrder((columnOrder) => {
				const oldIndex = columnOrder.indexOf(active.id as string);
				const newIndex = columnOrder.indexOf(over.id as string);
				return arrayMove(columnOrder, oldIndex, newIndex);
			});
		}
	};

	return (
		<div className="w-full self-start">
			{/* Filters Section */}
			<div className="flex items-start gap-2.5 mb-3.5">
				<div className="flex-1">
					<Filters
						filters={filters}
						fields={fields}
						onChange={handleFiltersChange}
						variant="outline"
						size="sm"
					/>
				</div>
				{filters.length > 0 && (
					<Button variant="outline" size="sm" onClick={() => setFilters([])}>
						<FunnelX /> Clear
					</Button>
				)}
			</div>

			{/* Data Grid */}
			<DataGrid
				table={table}
				recordCount={filteredData?.length || 0}
				tableLayout={{
					dense: true,
					columnsMovable: true,
					columnsResizable: true,
					columnsVisibility: true,
					columnsPinnable: true,
					columnsDraggable: true,
				}}
			>
				<div className="w-full space-y-2.5">
					<DataGridContainer>
						<ScrollArea>
							{/* <DataGridTable /> */}
							<DataGridTableDnd handleDragEnd={handleDragEnd} />
							<ScrollBar orientation="horizontal" />
						</ScrollArea>
					</DataGridContainer>
					<DataGridPagination />
				</div>
			</DataGrid>
		</div>
	);
}
