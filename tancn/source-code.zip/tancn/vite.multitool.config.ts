import {defineConfig} from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';
import path from 'node:path';
export default defineConfig({root:'multitool',base:'/tancn/',plugins:[react(),tailwindcss()],resolve:{alias:{'@/components/form-components/form-generator':path.resolve('multitool/form-generator.tsx'),'@':path.resolve('src'),'@tanstack/react-start':path.resolve('multitool/start-client.ts')}},build:{outDir:'../dist-multitool',emptyOutDir:true,chunkSizeWarningLimit:1800}});
