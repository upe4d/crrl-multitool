// Behavioural tests for worker/index.ts against a mocked GitHub Pages origin.
//
//   npx wrangler deploy --dry-run --outdir .wrangler-test
//   node scripts/test-worker.mjs [path/to/bundled/index.js]
import assert from "node:assert/strict";
import { pathToFileURL } from "node:url";
import { resolve } from "node:path";

const bundle = resolve(process.argv[2] ?? ".wrangler-test/index.js");
const worker = (await import(pathToFileURL(bundle).href)).default;
const ORIGIN = "https://mahankenway.github.io/PlayChive";

let calls = [];
let upstream = () => new Response("ok");
globalThis.fetch = async (target, init = {}) => {
  calls.push({ target: String(target), init });
  return upstream(String(target), init);
};

const run = (url, init) => worker.fetch(new Request(url, init));
let passed = 0;
async function test(name, fn) {
  calls = [];
  upstream = () => new Response("ok");
  try {
    await fn();
    passed++;
    console.log(`  ok   ${name}`);
  } catch (e) {
    console.error(`  FAIL ${name}\n       ${e.message}`);
    process.exitCode = 1;
  }
}

await test("serves the home page from the Pages path, with hardening headers", async () => {
  upstream = () => new Response("<h1>hi</h1>", { status: 200, headers: { "content-type": "text/html; charset=utf-8" } });
  const r = await run("https://playchive.ir/");
  assert.equal(r.status, 200);
  assert.equal(await r.text(), "<h1>hi</h1>");
  assert.equal(calls[0].target, `${ORIGIN}/`);
  assert.equal(r.headers.get("content-type"), "text/html; charset=utf-8");
  assert.equal(r.headers.get("x-content-type-options"), "nosniff");
  assert.equal(r.headers.get("referrer-policy"), "strict-origin-when-cross-origin");
  assert.equal(r.headers.get("x-robots-tag"), null, "real domain must stay indexable");
});

await test("HTML gets CSP, X-Frame-Options and Permissions-Policy; non-HTML does not", async () => {
  upstream = () => new Response("<h1>x</h1>", { headers: { "content-type": "text/html; charset=utf-8" } });
  let r = await run("https://playchive.ir/");
  assert.match(r.headers.get("content-security-policy"), /default-src 'self'/);
  assert.match(r.headers.get("content-security-policy"), /frame-ancestors 'self'/);
  assert.match(r.headers.get("content-security-policy"), /wasm-unsafe-eval/);
  assert.equal(r.headers.get("x-frame-options"), "SAMEORIGIN");
  assert.match(r.headers.get("permissions-policy"), /camera=\(\)/);
  upstream = () => new Response("{}", { headers: { "content-type": "application/json" } });
  r = await run("https://playchive.ir/data/games.json");
  assert.equal(r.headers.get("content-security-policy"), null);
});

await test("keeps path and query string", async () => {
  await run("https://playchive.ir/assets/a.png?v=3");
  assert.equal(calls[0].target, `${ORIGIN}/assets/a.png?v=3`);
});

await test("301: www -> apex, keeps path and query", async () => {
  const r = await run("https://www.playchive.ir/cdogs.html?x=1");
  assert.equal(r.status, 301);
  assert.equal(r.headers.get("location"), "https://playchive.ir/cdogs.html?x=1");
  assert.equal(calls.length, 0, "must not hit the origin");
});

await test("301: http -> https", async () => {
  const r = await run("http://playchive.ir/fa/");
  assert.equal(r.status, 301);
  assert.equal(r.headers.get("location"), "https://playchive.ir/fa/");
});

await test("301: www + http combined goes straight to https apex", async () => {
  const r = await run("http://www.playchive.ir/");
  assert.equal(r.status, 301);
  assert.equal(r.headers.get("location"), "https://playchive.ir/");
});

await test("301: /index.html and /dir/index.html -> clean URLs", async () => {
  let r = await run("https://playchive.ir/index.html");
  assert.equal(r.status, 301);
  assert.equal(r.headers.get("location"), "https://playchive.ir/");
  r = await run("https://playchive.ir/fa/index.html?a=b");
  assert.equal(r.headers.get("location"), "https://playchive.ir/fa/?a=b");
});

await test("API catalog (RFC 9727): 200, linkset+json, valid entries, served without hitting the origin", async () => {
  const r = await run("https://playchive.ir/.well-known/api-catalog");
  assert.equal(r.status, 200);
  assert.equal(r.headers.get("content-type"), "application/linkset+json");
  assert.equal(calls.length, 0, "must be answered by the Worker itself");
  const body = await r.json();
  assert.ok(Array.isArray(body.linkset) && body.linkset.length >= 1);
  for (const e of body.linkset) {
    assert.match(e.anchor, /^https:\/\/playchive\.ir\//);
    assert.match(e["service-desc"][0].href, /^https:\/\/playchive\.ir\/openapi\.json$/);
    assert.equal(e["service-desc"][0].type, "application/vnd.oai.openapi+json");
    assert.match(e["service-doc"][0].href, /^https:\/\/playchive\.ir\//);
  }
  assert.equal(new Set(body.linkset.map((e) => e.anchor)).size, body.linkset.length, "anchors must be unique");
});

await test("API catalog: HEAD returns headers with an empty body, CORS is open", async () => {
  const r = await run("https://playchive.ir/.well-known/api-catalog", { method: "HEAD" });
  assert.equal(r.status, 200);
  assert.equal(r.headers.get("content-type"), "application/linkset+json");
  assert.equal(r.headers.get("access-control-allow-origin"), "*");
  assert.equal(await r.text(), "");
});

await test("API catalog: www and http still redirect first", async () => {
  const r = await run("http://www.playchive.ir/.well-known/api-catalog");
  assert.equal(r.status, 301);
  assert.equal(r.headers.get("location"), "https://playchive.ir/.well-known/api-catalog");
});

await test("home page advertises the catalog with a Link header; other pages do not", async () => {
  let r = await run("https://playchive.ir/");
  assert.match(r.headers.get("link") ?? "", /<\/\.well-known\/api-catalog>; rel="api-catalog"/);
  r = await run("https://playchive.ir/cdogs.html");
  assert.equal(r.headers.get("link"), null);
});

await test("agent skills: well-known path maps to /agent-skills/, SKILL.md gets text/markdown, CORS open", async () => {
  upstream = () => new Response("---\nname: x\n---\n", { status: 200, headers: { "content-type": "application/octet-stream" } });
  const r = await run("https://playchive.ir/.well-known/agent-skills/browse-playchive-catalog/SKILL.md");
  assert.equal(calls[0].target, `${ORIGIN}/agent-skills/browse-playchive-catalog/SKILL.md`);
  assert.equal(r.status, 200);
  assert.equal(r.headers.get("content-type"), "text/markdown; charset=utf-8");
  assert.equal(r.headers.get("access-control-allow-origin"), "*");
});

await test("agent skills: index.json keeps its JSON type and a missing skill stays 404", async () => {
  upstream = () => new Response("{}", { status: 200, headers: { "content-type": "application/json; charset=utf-8" } });
  let r = await run("https://playchive.ir/.well-known/agent-skills/index.json");
  assert.equal(calls[0].target, `${ORIGIN}/agent-skills/index.json`);
  assert.equal(r.headers.get("content-type"), "application/json; charset=utf-8");
  upstream = () => new Response("nope", { status: 404, headers: { "content-type": "text/html" } });
  r = await run("https://playchive.ir/.well-known/agent-skills/missing/SKILL.md");
  assert.equal(r.status, 404);
  assert.notEqual(r.headers.get("content-type"), "text/markdown; charset=utf-8", "404 must not be relabelled");
});

await test("agent skills: path traversal cannot escape /agent-skills/", async () => {
  await run("https://playchive.ir/.well-known/agent-skills/../../data/games.json");
  assert.ok(!calls[0].target.includes("/agent-skills/../"), calls[0].target);
});

const rpc = (body, headers = {}, url = "https://playchive.ir/mcp") =>
  run(url, { method: "POST", headers: { "content-type": "application/json", ...headers }, body: JSON.stringify(body) });
const call = async (method, params = {}, headers) => (await rpc({ jsonrpc: "2.0", id: 1, method, params }, headers)).json();

await test("MCP: server/discover advertises versions, capabilities and identity, no origin hit", async () => {
  const r = await rpc({ jsonrpc: "2.0", id: 1, method: "server/discover" });
  assert.equal(r.status, 200);
  assert.equal(calls.length, 0);
  const j = await r.json();
  assert.equal(j.id, 1);
  assert.equal(j.result.resultType, "complete");
  assert.ok(j.result.supportedVersions.includes("2026-07-28"));
  assert.ok(j.result.capabilities.tools);
  assert.ok(j.result.serverInfo.name && j.result.serverInfo.version);
  assert.equal(r.headers.get("access-control-allow-origin"), "*");
});

await test("MCP: tools/list is cacheable, deterministic, read-only annotated", async () => {
  const a = await call("tools/list");
  const b = await call("tools/list");
  assert.deepEqual(a, b);
  assert.equal(a.result.resultType, "complete");
  assert.equal(typeof a.result.ttlMs, "number");
  assert.equal(a.result.cacheScope, "public");
  assert.deepEqual(a.result.tools.map((x) => x.name), ["search_games", "get_game", "list_genres"]);
  for (const x of a.result.tools) {
    assert.equal(x.annotations.readOnlyHint, true);
    assert.equal(x.inputSchema.type, "object");
  }
});

await test("MCP: search_games filters, paginates and returns structuredContent", async () => {
  let j = await call("tools/call", { name: "search_games", arguments: { playable: true, limit: 5 } });
  const sc = j.result.structuredContent;
  assert.equal(j.result.isError, false);
  assert.equal(j.result.resultType, "complete");
  assert.equal(sc.games.length, 5);
  assert.ok(sc.total >= 20);
  assert.ok(sc.games.every((g) => g.playable && g.playUrl.startsWith("https://playchive.ir/")));
  assert.deepEqual(JSON.parse(j.result.content[0].text), sc);
  const p2 = (await call("tools/call", { name: "search_games", arguments: { playable: true, limit: 5, offset: 5 } })).result.structuredContent;
  assert.notEqual(p2.games[0].id, sc.games[0].id);
  j = await call("tools/call", { name: "search_games", arguments: { query: "BLASPHEMER" } });
  assert.ok(j.result.structuredContent.games.some((g) => g.id === "blasphemer"));
  j = await call("tools/call", { name: "search_games", arguments: { query: "zzzz-no-such" } });
  assert.equal(j.result.structuredContent.total, 0);
});

await test("MCP: get_game and list_genres", async () => {
  let j = await call("tools/call", { name: "get_game", arguments: { id: "blasphemer" } });
  assert.equal(j.result.structuredContent.name, "Blasphemer");
  assert.equal(j.result.structuredContent.playUrl, "https://playchive.ir/blasphemer.html");
  j = await call("tools/call", { name: "get_game", arguments: { id: "nope" } });
  assert.equal(j.result.isError, true);
  j = await call("tools/call", { name: "list_genres" });
  assert.ok(j.result.structuredContent.genres.length >= 10);
});

await test("MCP: invalid tool arguments are tool errors, unknown tool is a protocol error", async () => {
  for (const args of [{ limit: 0 }, { limit: 51 }, { limit: "x" }, { offset: -1 }, { playable: "yes" }, { query: "x".repeat(101) }, { bogus: 1 }]) {
    const j = await call("tools/call", { name: "search_games", arguments: args });
    assert.equal(j.result.isError, true, JSON.stringify(args));
  }
  assert.equal((await call("tools/call", { name: "get_game", arguments: {} })).result.isError, true);
  assert.equal((await call("tools/call", { name: "delete_everything" })).error.code, -32602);
  assert.equal((await call("tools/call", { name: "search_games", arguments: [] })).error.code, -32602);
});

await test("MCP: protocol version in _meta is checked", async () => {
  const meta = (v) => ({ _meta: { "io.modelcontextprotocol/protocolVersion": v } });
  assert.equal((await call("tools/list", meta("2026-07-28"))).result.tools.length, 3);
  const bad = await call("tools/list", meta("1999-01-01"));
  assert.equal(bad.error.code, -32022);
  assert.ok(bad.error.data.supported.includes("2026-07-28"));
});

await test("MCP: legacy initialize and ping still work; notifications get 202", async () => {
  const j = await call("initialize", { protocolVersion: "2025-06-18", capabilities: {}, clientInfo: { name: "t", version: "1" } });
  assert.equal(j.result.protocolVersion, "2025-06-18");
  assert.ok(j.result.capabilities.tools);
  assert.deepEqual((await call("ping")).result, {});
  const n = await rpc({ jsonrpc: "2.0", method: "notifications/initialized" });
  assert.equal(n.status, 202);
  assert.equal(await n.text(), "");
});

await test("MCP: JSON-RPC errors (parse, shape, method, headers, size)", async () => {
  let r = await run("https://playchive.ir/mcp", { method: "POST", body: "{nope" });
  assert.equal(r.status, 400);
  assert.equal((await r.json()).error.code, -32700);
  r = await rpc([{ jsonrpc: "2.0", id: 1, method: "tools/list" }]);
  assert.equal(r.status, 400);
  r = await rpc({ id: 1, method: "tools/list" });
  assert.equal(r.status, 400);
  assert.equal((await call("resources/list")).error.code, -32601);
  assert.equal((await call("tools/list", {}, { "mcp-method": "tools/call" })).error.code, -32020);
  assert.equal((await call("tools/call", { name: "list_genres" }, { "mcp-name": "get_game" })).error.code, -32020);
  assert.equal((await call("tools/call", { name: "list_genres" }, { "mcp-method": "tools/call", "mcp-name": "list_genres" })).result.isError, false);
  r = await run("https://playchive.ir/mcp", { method: "POST", body: "x".repeat(40000) });
  assert.equal(r.status, 413);
});

await test("MCP: GET is 405 with Allow, OPTIONS is a CORS preflight, http POST keeps method via 308", async () => {
  let r = await run("https://playchive.ir/mcp");
  assert.equal(r.status, 405);
  assert.equal(r.headers.get("allow"), "POST, OPTIONS");
  r = await run("https://playchive.ir/mcp", { method: "OPTIONS" });
  assert.equal(r.status, 204);
  assert.match(r.headers.get("access-control-allow-headers"), /Mcp-Method/i);
  r = await rpc({ jsonrpc: "2.0", id: 1, method: "tools/list" }, {}, "http://playchive.ir/mcp");
  assert.equal(r.status, 308);
  assert.equal(r.headers.get("location"), "https://playchive.ir/mcp");
  assert.equal(calls.length, 0);
});

await test("MCP server card: SEP-2127 shape, compat shape, three paths, HEAD, no origin hit", async () => {
  for (const path of ["/.well-known/mcp-server-card", "/mcp/server-card", "/.well-known/mcp/server-card.json"]) {
    const r = await run(`https://playchive.ir${path}`);
    assert.equal(r.status, 200, path);
    assert.equal(r.headers.get("content-type"), "application/json");
    assert.equal(r.headers.get("access-control-allow-origin"), "*");
    const c = await r.json();
    assert.equal(c.$schema, "https://static.modelcontextprotocol.io/schemas/v1/server-card.schema.json");
    assert.match(c.name, /^[^/]+\/[^/]+$/);
    assert.match(c.version, /^\d+\.\d+\.\d+$/);
    assert.ok(c.description);
    assert.equal(c.remotes[0].type, "streamable-http");
    assert.equal(c.remotes[0].url, "https://playchive.ir/mcp");
    assert.ok(c.remotes[0].supportedProtocolVersions.includes("2026-07-28"));
    assert.equal(c.tools, undefined, "cards must not list tools");
    if (path.endsWith(".json")) {
      assert.equal(c.serverInfo.name, c.name);
      assert.equal(c.transport.endpoint, "/mcp");
      assert.ok(c.capabilities.tools);
    }
  }
  const h = await run("https://playchive.ir/mcp/server-card", { method: "HEAD" });
  assert.equal(h.status, 200);
  assert.equal(await h.text(), "");
  assert.equal(calls.length, 0);
});

await test("MCP card and discover agree on name, version and protocol versions", async () => {
  const card = await (await run("https://playchive.ir/.well-known/mcp-server-card")).json();
  const d = (await call("server/discover")).result;
  assert.equal(d.serverInfo.name, card.name);
  assert.equal(d.serverInfo.version, card.version);
  assert.deepEqual(d.supportedVersions, card.remotes[0].supportedProtocolVersions);
});

await test("Markdown for Agents: Accept text/markdown returns md twin, browsers keep HTML", async () => {
  upstream = (target) =>
    target.includes("/md/")
      ? new Response("# Title\n\ntext here", { status: 200, headers: { "content-type": "application/octet-stream" } })
      : new Response("<h1>hi</h1>", { status: 200, headers: { "content-type": "text/html; charset=utf-8" } });
  const md = (p, accept) => run(`https://playchive.ir${p}`, { headers: { accept } });
  let r = await md("/", "text/markdown");
  assert.equal(calls[0].target, `${ORIGIN}/md/index.md`);
  assert.equal(r.headers.get("content-type"), "text/markdown; charset=utf-8");
  assert.equal(r.headers.get("vary"), "Accept");
  assert.equal(r.headers.get("x-markdown-tokens"), String(Math.ceil("# Title\n\ntext here".length / 4)));
  assert.equal(await r.text(), "# Title\n\ntext here");
  await md("/cdogs.html", "text/markdown, text/html;q=0.5");
  assert.equal(calls.at(-1).target, `${ORIGIN}/md/cdogs.md`);
  await md("/fa/", "text/markdown");
  assert.equal(calls.at(-1).target, `${ORIGIN}/md/fa/index.md`);
  calls = [];
  r = await md("/", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
  assert.equal(calls[0].target, `${ORIGIN}/`);
  assert.match(r.headers.get("content-type"), /text\/html/);
  assert.match(r.headers.get("vary"), /Accept/);
  calls = [];
  await md("/", "*/*");
  assert.equal(calls[0].target, `${ORIGIN}/`);
  await md("/", "text/html, text/markdown;q=0.5");
  assert.equal(calls.at(-1).target, `${ORIGIN}/`);
  await md("/data/games.json", "text/markdown");
  assert.equal(calls.at(-1).target, `${ORIGIN}/data/games.json`);
});

await test("Markdown for Agents: missing twin falls back to HTML; HEAD has no body", async () => {
  upstream = (target) =>
    target.includes("/md/") ? new Response("nope", { status: 404 }) : new Response("<h1>hi</h1>", { headers: { "content-type": "text/html" } });
  let r = await run("https://playchive.ir/", { headers: { accept: "text/markdown" } });
  assert.match(r.headers.get("content-type"), /text\/html/);
  upstream = () => new Response("# x", { status: 200 });
  r = await run("https://playchive.ir/", { method: "HEAD", headers: { accept: "text/markdown" } });
  assert.equal(r.headers.get("content-type"), "text/markdown; charset=utf-8");
  assert.equal(await r.text(), "");
  r = await run("https://playchive.ir/md/index.md");
  assert.equal(r.headers.get("x-robots-tag"), "noindex");
});

await test("A2A agent card: served by the Worker, 1.0 shape, points at the Ikol endpoint", async () => {
  const r = await run("https://playchive.ir/.well-known/agent-card.json");
  assert.equal(r.status, 200);
  assert.equal(r.headers.get("content-type"), "application/json");
  assert.equal(calls.length, 0);
  const c = await r.json();
  assert.equal(c.supportedInterfaces[0].protocolBinding, "JSONRPC");
  assert.equal(c.supportedInterfaces[0].protocolVersion, "1.0");
  assert.match(c.supportedInterfaces[0].url, /^https:\/\/.+\/a2a$/);
  assert.equal(c.protocolVersion, undefined);
  assert.ok(c.skills.length >= 1 && c.skills.every((s) => s.id && s.name && s.description && s.tags.length));
  for (const k of ["name", "description", "version", "capabilities", "defaultInputModes", "defaultOutputModes"]) assert.ok(c[k], k);
  const h = await run("https://playchive.ir/.well-known/agent-card.json", { method: "HEAD" });
  assert.equal(await h.text(), "");
});

await test("PRM (RFC 9728): minimal, truthful, no authorization servers, no origin hit", async () => {
  const r = await run("https://playchive.ir/.well-known/oauth-protected-resource");
  assert.equal(r.status, 200);
  assert.equal(r.headers.get("content-type"), "application/json");
  assert.equal(calls.length, 0);
  const j = await r.json();
  assert.equal(j.resource, "https://playchive.ir");
  assert.equal(j.authorization_servers, undefined);
  assert.deepEqual(j.bearer_methods_supported, []);
  assert.equal(j.resource_documentation, "https://playchive.ir/auth.md");
});

await test("Web Bot Auth directory: JWKS with an Ed25519 public key only", async () => {
  const r = await run("https://playchive.ir/.well-known/http-message-signatures-directory");
  assert.equal(r.status, 200);
  assert.equal(r.headers.get("content-type"), "application/http-message-signatures-directory+json");
  assert.equal(calls.length, 0);
  const j = await r.json();
  assert.ok(j.keys.length >= 1);
  for (const k of j.keys) {
    assert.equal(k.kty, "OKP");
    assert.equal(k.crv, "Ed25519");
    assert.ok(k.x && k.kid);
    assert.equal(k.d, undefined, "private key material must never be served");
  }
});

// ---- OAuth (Cloudflare Access as IdP): everything off until configured, strict verification once on
import { generateKeyPairSync, createSign } from "node:crypto";
const ISSUER = "https://team.cloudflareaccess.com/cdn-cgi/access/sso/oidc/client123";
const AUD = "client123";
const rsa = generateKeyPairSync("rsa", { modulusLength: 2048 });
const jwk = { ...rsa.publicKey.export({ format: "jwk" }), kid: "k1", alg: "RS256", use: "sig" };
const other = generateKeyPairSync("rsa", { modulusLength: 2048 });
const b64url = (o) => Buffer.from(typeof o === "string" ? o : JSON.stringify(o)).toString("base64url");
const mint = (claims = {}, { key = rsa.privateKey, kid = "k1", alg = "RS256" } = {}) => {
  const now = Math.floor(Date.now() / 1000);
  const body = { iss: ISSUER, aud: AUD, sub: "user-1", exp: now + 600, iat: now, ...claims };
  const head = b64url({ alg, kid, typ: "JWT" });
  const data = `${head}.${b64url(body)}`;
  const sig = createSign("RSA-SHA256").update(data).sign(key).toString("base64url");
  return `${data}.${sig}`;
};
const kvStore = new Map();
const KV = { get: async (k) => kvStore.get(k) ?? null, put: async (k, v) => void kvStore.set(k, v) };
const ENV = { ACCESS_ISSUER: ISSUER, ACCESS_AUDIENCE: AUD, FAVORITES: KV };
const idpUpstream = (target) => {
  if (target === `${ISSUER}/.well-known/openid-configuration`)
    return Response.json({ issuer: ISSUER, authorization_endpoint: `${ISSUER}/authorization`, token_endpoint: `${ISSUER}/token`, jwks_uri: `${ISSUER}/jwks`, response_types_supported: ["code"], grant_types_supported: ["authorization_code"] });
  if (target === `${ISSUER}/jwks`) return Response.json({ keys: [jwk] });
  return new Response("x", { status: 404 });
};
const withEnv = (url, init, env) => worker.fetch(new Request(url, init), env);
const fav = (method, token, body, env = ENV) =>
  withEnv("https://playchive.ir/api/favorites", { method, headers: { ...(token ? { authorization: `Bearer ${token}` } : {}), "content-type": "application/json" }, body }, env);

await test("OAuth: unconfigured -> favourites 503, discovery 404, PRM lists no authorization server", async () => {
  assert.equal((await withEnv("https://playchive.ir/api/favorites", {}, {})).status, 503);
  assert.equal((await withEnv("https://playchive.ir/.well-known/openid-configuration", {}, {})).status, 404);
  const prm = await (await withEnv("https://playchive.ir/.well-known/oauth-protected-resource", {}, {})).json();
  assert.equal(prm.authorization_servers, undefined);
  assert.equal(calls.length, 0);
});

await test("OAuth: configured discovery proxies the IdP document, PRM points at it", async () => {
  upstream = idpUpstream;
  const d = await (await withEnv("https://playchive.ir/.well-known/openid-configuration", {}, ENV)).json();
  assert.equal(d.issuer, ISSUER);
  for (const k of ["authorization_endpoint", "token_endpoint", "jwks_uri", "grant_types_supported", "response_types_supported"]) assert.ok(d[k], k);
  const d2 = await (await withEnv("https://playchive.ir/.well-known/oauth-authorization-server", {}, ENV)).json();
  assert.equal(d2.issuer, ISSUER);
  const prm = await (await withEnv("https://playchive.ir/.well-known/oauth-protected-resource", {}, ENV)).json();
  assert.deepEqual(prm.authorization_servers, [ISSUER]);
  assert.deepEqual(prm.bearer_methods_supported, ["header"]);
  assert.ok(prm.scopes_supported.length);
});

await test("OAuth: favourites require a valid token and round-trip per user", async () => {
  upstream = idpUpstream;
  let r = await fav("GET");
  assert.equal(r.status, 401);
  assert.match(r.headers.get("www-authenticate"), /resource_metadata="https:\/\/playchive\.ir\/\.well-known\/oauth-protected-resource"/);
  r = await fav("GET", mint());
  assert.deepEqual(await r.json(), { games: [] });
  r = await fav("PUT", mint(), JSON.stringify({ games: ["cdogs-sdl", "cdogs-sdl", "openttd"] }));
  assert.deepEqual((await r.json()).games, ["cdogs-sdl", "openttd"]);
  assert.deepEqual(await (await fav("GET", mint())).json(), { games: ["cdogs-sdl", "openttd"] });
  assert.deepEqual(await (await fav("GET", mint({ sub: "user-2" }))).json(), { games: [] }, "users are isolated");
});

await test("OAuth: bad tokens are rejected (signature, kid, alg, iss, aud, exp, nbf)", async () => {
  upstream = idpUpstream;
  const now = Math.floor(Date.now() / 1000);
  const bad = [
    mint({}, { key: other.privateKey }),
    mint({}, { kid: "nope" }),
    mint({ iss: "https://evil.example" }),
    mint({ aud: "someone-else" }),
    mint({ exp: now - 3600 }),
    mint({ nbf: now + 3600 }),
    mint({ sub: "" }),
    "not.a.jwt",
    "x",
  ];
  for (const t of bad) assert.equal((await fav("GET", t)).status, 401, t.slice(0, 20));
  const none = `${b64url({ alg: "none", kid: "k1" })}.${b64url({ iss: ISSUER, aud: AUD, sub: "u", exp: now + 99 })}.`;
  assert.equal((await fav("GET", none)).status, 401, "alg none");
  const hs = mint({}, { alg: "HS256" });
  assert.equal((await fav("GET", hs)).status, 401, "wrong alg");
});

await test("OAuth: favourites validate input and limit size", async () => {
  upstream = idpUpstream;
  const t = mint();
  for (const body of [JSON.stringify({ games: ["not-a-game"] }), JSON.stringify({ games: "x" }), "{nope", JSON.stringify({ games: Array(101).fill("cdogs-sdl") })]) {
    assert.equal((await fav("PUT", t, body)).status, 400, body.slice(0, 20));
  }
  assert.equal((await fav("PUT", t, "x".repeat(9000))).status, 413);
  assert.equal((await fav("DELETE", t)).status, 405);
  assert.equal((await withEnv("https://playchive.ir/api/favorites", { method: "OPTIONS" }, ENV)).status, 204);
});

await test("OAuth: IdP outage gives 503, not a pass", async () => {
  upstream = () => new Response("down", { status: 500 });
  const oe = console.error; console.error = () => {};
  const r = await fav("GET", mint(), undefined, { ...ENV, ACCESS_ISSUER: ISSUER + "-down" });
  console.error = oe;
  assert.equal(r.status, 503);
});

await test("workers.dev host is noindex", async () => {
  const r = await run("https://playchive.example.workers.dev/");
  assert.equal(r.status, 200);
  assert.equal(r.headers.get("x-robots-tag"), "noindex, nofollow");
});

await test("Pages directory redirect is rewritten to the public host", async () => {
  upstream = () => new Response(null, { status: 301, headers: { location: `${ORIGIN}/fa/` } });
  const r = await run("https://playchive.ir/fa");
  assert.equal(r.status, 301);
  assert.equal(r.headers.get("location"), "https://playchive.ir/fa/");
});

await test("Pages custom-domain redirect to this host is followed internally (no loop)", async () => {
  upstream = (target) =>
    target === `${ORIGIN}/fa`
      ? new Response(null, { status: 301, headers: { location: "https://playchive.ir/fa/" } })
      : new Response("fa page", { status: 200 });
  const r = await run("https://playchive.ir/fa");
  assert.equal(r.status, 200);
  assert.equal(await r.text(), "fa page");
  assert.deepEqual(calls.map((c) => c.target), [`${ORIGIN}/fa`, `${ORIGIN}/fa/`]);
});

await test("a real redirect loop ends in a clear 502 instead of looping the browser", async () => {
  upstream = () => new Response(null, { status: 301, headers: { location: "https://playchive.ir/" } });
  const r = await run("https://playchive.ir/");
  assert.equal(r.status, 502);
  assert.match(await r.text(), /custom domain/i);
  assert.ok(calls.length <= 5);
});

await test("redirect to a foreign host is passed through", async () => {
  upstream = () => new Response(null, { status: 302, headers: { location: "https://example.org/x" } });
  const r = await run("https://playchive.ir/out");
  assert.equal(r.status, 302);
  assert.equal(r.headers.get("location"), "https://example.org/x");
});

await test("404 from Pages stays a 404 with its body", async () => {
  upstream = () => new Response("There isn't a GitHub Pages site here.", { status: 404 });
  const r = await run("https://playchive.ir/nope");
  assert.equal(r.status, 404);
  assert.match(await r.text(), /GitHub Pages/);
});

await test("cache policy: only successful responses are cached, errors are not", async () => {
  await run("https://playchive.ir/");
  const ttl = calls[0].init.cf?.cacheTtlByStatus;
  assert.ok(ttl, "cacheTtlByStatus must be set");
  assert.equal(ttl["200-299"], 300);
  assert.equal(ttl["400-599"], 0);
  assert.equal(calls[0].init.redirect, "manual");
});

await test("forwards Range and conditional headers only", async () => {
  await run("https://playchive.ir/assets/big.wad", {
    headers: { range: "bytes=0-99", cookie: "secret=1", "if-none-match": '"abc"', "x-evil": "1" },
  });
  const h = new Headers(calls[0].init.headers);
  assert.equal(h.get("range"), "bytes=0-99");
  assert.equal(h.get("if-none-match"), '"abc"');
  assert.equal(h.get("cookie"), null);
  assert.equal(h.get("x-evil"), null);
});

await test("passes 206 partial content through", async () => {
  upstream = () => new Response("abc", { status: 206, headers: { "content-range": "bytes 0-2/10" } });
  const r = await run("https://playchive.ir/assets/big.wad", { headers: { range: "bytes=0-2" } });
  assert.equal(r.status, 206);
  assert.equal(r.headers.get("content-range"), "bytes 0-2/10");
});

await test("HEAD is allowed", async () => {
  const r = await run("https://playchive.ir/", { method: "HEAD" });
  assert.equal(r.status, 200);
  assert.equal(calls[0].init.method, "HEAD");
});

await test("POST is rejected with 405 and Allow header", async () => {
  const r = await run("https://playchive.ir/", { method: "POST", body: "x" });
  assert.equal(r.status, 405);
  assert.equal(r.headers.get("allow"), "GET, HEAD");
  assert.equal(calls.length, 0);
});

await test("security.txt (RFC 9116) is served by the Worker with Contact and a future Expires", async () => {
  const r = await run("https://playchive.ir/.well-known/security.txt");
  assert.equal(r.status, 200);
  assert.match(r.headers.get("content-type"), /^text\/plain/);
  const body = await r.text();
  assert.match(body, /^Contact: https:\/\//m);
  const expires = /^Expires: (.+)$/m.exec(body)?.[1];
  assert.ok(expires && Date.parse(expires) > Date.now(), "Expires must be in the future");
  assert.equal(calls.length, 0);
});

await test("media files get a week-long cache, scripts and styles do not", async () => {
  upstream = () => new Response("img", { status: 200, headers: { "content-type": "image/webp" } });
  let r = await run("https://playchive.ir/assets/screenshots/x.webp");
  assert.match(r.headers.get("cache-control"), /max-age=604800/);
  upstream = () => new Response("css", { status: 200, headers: { "content-type": "text/css", "cache-control": "max-age=600" } });
  r = await run("https://playchive.ir/styles/main.css");
  assert.equal(r.headers.get("cache-control"), "max-age=600");
});

await test("origin failure becomes 502", async () => {
  upstream = () => {
    throw new Error("boom");
  };
  const origError = console.error;
  console.error = () => {};
  const r = await run("https://playchive.ir/");
  console.error = origError;
  assert.equal(r.status, 502);
});

console.log(`\n${passed} passed${process.exitCode ? ", some FAILED" : ""}`);
