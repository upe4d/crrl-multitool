#!/usr/bin/env python3
"""Validate PLAYCHIVE SEO/GEO output. Exit code 1 on any error (warnings never fail).

Checks every indexable HTML page for title, description, canonical, Open Graph,
Twitter, JSON-LD, h1 and hreflang; cross-checks sitemap, robots, llms files and
the static catalog against data/games.json; verifies local files exist.
"""
from __future__ import annotations

import json
import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parent.parent
BASE = "https://playchive.ir"
errors: list[str] = []
warnings: list[str] = []


def err(msg):
    errors.append(msg)


def warn(msg):
    warnings.append(msg)


def local_for(url: str) -> Path | None:
    if not url.startswith(BASE):
        return None
    path = urlparse(url).path.lstrip("/")
    # Worker-served well-known paths: skills map to /agent-skills/, the API catalog is generated in the Worker.
    if path.startswith(".well-known/agent-skills/"):
        path = "agent-skills/" + path[len(".well-known/agent-skills/"):]
    elif path in (".well-known/api-catalog", "mcp", ".well-known/mcp-server-card"):
        path = "worker/index.ts"
    if path == "" or path.endswith("/"):
        path += "index.html"
    return ROOT / path


def attr(tag_re: str, text: str, key: str = "content"):
    m = re.search(tag_re, text)
    if not m:
        return None
    m2 = re.search(key + r'="([^"]*)"', m.group(0))
    return m2.group(1) if m2 else None


def unescape(s):
    import html
    return html.unescape(s) if s is not None else s


pages = sorted(p for p in ROOT.glob("**/*.html")
               if not any(part in {".git", "third_party", "dist", "armawebtron", "docs", "node_modules", "linuxdoom-1.10",
                                   "tuxracer", "neon-rift", "shadow-station", "agent-assets"} for part in p.relative_to(ROOT).parts[:-1])
               and not p.name.startswith("google"))

# directories like neon-rift/ contain game assets, not pages; only top level pages plus these folders matter
pages = [p for p in pages if len(p.relative_to(ROOT).parts) == 1 or p.relative_to(ROOT).parts[0] in {"fa", "agent", "privacy", "about"}]

canonicals: dict[str, Path] = {}
noindex_pages: list[str] = []
for p in pages:
    rel = p.relative_to(ROOT).as_posix()
    t = p.read_text(encoding="utf-8")
    head = re.search(r"<head[^>]*>(.*?)</head>", t, re.S)
    if not head:
        err(f"{rel}: no <head>")
        continue
    h = head.group(1)
    if "noindex" in (attr(r'<meta\s+name="robots"[^>]*>', h) or ""):
        noindex_pages.append(rel)
        continue

    m = re.search(r"<title>(.*?)</title>", h, re.S)
    title = unescape(m.group(1).strip()) if m else None
    if not title:
        err(f"{rel}: missing <title>")
    elif not 25 <= len(title) <= 70:
        warn(f"{rel}: title length {len(title)} (ideal 30-65)")

    desc = unescape(attr(r'<meta\s+name="description"[^>]*>', h))
    if not desc:
        err(f"{rel}: missing meta description")
    elif not 70 <= len(desc) <= 170:
        warn(f"{rel}: description length {len(desc)} (ideal 70-160)")

    canon = attr(r'<link\s+rel="canonical"[^>]*>', h, "href")
    if not canon:
        err(f"{rel}: missing canonical")
    else:
        if not canon.startswith(BASE):
            err(f"{rel}: canonical not on {BASE}: {canon}")
        expected = BASE + "/" + (rel[: -len("index.html")] if rel.endswith("index.html") else rel)
        if canon != expected:
            err(f"{rel}: canonical {canon} != expected {expected}")
        if canon in canonicals:
            err(f"{rel}: duplicate canonical with {canonicals[canon]}")
        canonicals[canon] = p

    for prop in ("og:title", "og:description", "og:url", "og:image", "og:type", "og:site_name"):
        if attr(rf'<meta\s+property="{prop}"[^>]*>', h) is None:
            err(f"{rel}: missing {prop}")
    if attr(r'<meta\s+property="og:url"[^>]*>', h) != canon:
        err(f"{rel}: og:url differs from canonical")
    img = attr(r'<meta\s+property="og:image"[^>]*>', h)
    if img:
        lp = local_for(img)
        if lp is None or not lp.exists():
            err(f"{rel}: og:image does not resolve to a local file: {img}")
    if attr(r'<meta\s+name="twitter:card"[^>]*>', h) is None:
        err(f"{rel}: missing twitter:card")
    if attr(r'<meta\s+name="twitter:image"[^>]*>', h) is None:
        warn(f"{rel}: missing twitter:image")

    if not re.search(r"<html[^>]*\blang=", t):
        err(f"{rel}: <html> has no lang")
    if len(re.findall(r"<h1[\s>]", t)) != 1:
        h1_count = len(re.findall(r"<h1[\s>]", t))
        warn(f"{rel}: expected exactly one <h1>, found {h1_count}")
    if "github.io/PlayChive" in t:
        err(f"{rel}: still references github.io/PlayChive")

    blocks = re.findall(r'<script type="application/ld\+json">(.*?)</script>', t, re.S)
    if not blocks and rel not in ("privacy/index.html", "agent/index.html", "about/index.html"):
        err(f"{rel}: no JSON-LD")
    for b in blocks:
        try:
            data = json.loads(b.replace("<\\/", "</"))
        except Exception as e:  # noqa: BLE001
            err(f"{rel}: invalid JSON-LD ({e})")
            continue
        for node in data.get("@graph", [data]):
            if node.get("@type") == "VideoGame":
                for k in ("name", "url", "description", "image", "gamePlatform"):
                    if not node.get(k):
                        err(f"{rel}: VideoGame missing {k}")
            if node.get("@type") == "FAQPage":
                ents = node.get("mainEntity", [])
                if not ents:
                    err(f"{rel}: empty FAQPage")
                visible = re.sub(r"<[^>]+>", " ", t)
                visible = unescape(" ".join(visible.split()))
                for q in ents:
                    if q["name"] not in visible:
                        err(f"{rel}: FAQ question not visible in page text: {q['name'][:50]}")

    if "hreflang" in h:
        langs = dict(re.findall(r'<link\s+rel="alternate"\s+hreflang="([^"]+)"\s+href="([^"]+)"', h))
        if "x-default" not in langs:
            err(f"{rel}: hreflang without x-default")
        if canon and canon not in langs.values():
            err(f"{rel}: hreflang set does not include itself")

# ----------------------------------------------------------------------- sitemap
sm = ET.parse(ROOT / "sitemap.xml").getroot()
ns = {"s": "http://www.sitemaps.org/schemas/sitemap/0.9",
      "i": "http://www.google.com/schemas/sitemap-image/1.1"}
locs = [u.find("s:loc", ns).text for u in sm.findall("s:url", ns)]
if len(set(locs)) != len(locs):
    err("sitemap: duplicate <loc>")
for u in sm.findall("s:url", ns):
    loc = u.find("s:loc", ns).text
    lp = local_for(loc)
    if lp is None or not lp.exists():
        err(f"sitemap: {loc} has no local file")
    lm = u.find("s:lastmod", ns)
    if lm is None or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", lm.text or ""):
        err(f"sitemap: bad lastmod for {loc}")
    for im in u.findall("i:image", ns):
        ip = local_for(im.find("i:loc", ns).text)
        if ip is None or not ip.exists():
            err(f"sitemap: image missing for {loc}")
for np_ in noindex_pages:
    if any(l.endswith("/" + np_) for l in locs):
        err(f"sitemap: noindex page must not be listed: {np_}")
for c in canonicals:
    if c not in locs:
        err(f"sitemap: indexable page missing from sitemap: {c}")
for loc in locs:
    if loc not in canonicals:
        err(f"sitemap: {loc} is not a checked canonical page")

# ------------------------------------------------------------------ robots / llms
robots = (ROOT / "robots.txt").read_text(encoding="utf-8")
if f"Sitemap: {BASE}/sitemap.xml" not in robots:
    err("robots.txt: missing Sitemap line for playchive.ir")
for bot in ("GPTBot", "ClaudeBot", "PerplexityBot", "OAI-SearchBot", "Google-Extended"):
    if bot not in robots:
        warn(f"robots.txt: {bot} not mentioned")
if not re.search(r"(?mi)^Content-Signal:\s*ai-train=(yes|no),\s*search=(yes|no),\s*ai-input=(yes|no)\s*$", robots):
    err("robots.txt: missing or malformed Content-Signal line (ai-train, search, ai-input)")
if re.search(r"(?mi)^Disallow:\s*/\s*$", robots):
    err("robots.txt: Disallow: / blocks the whole site")

games = json.loads((ROOT / "data/games.json").read_text(encoding="utf-8"))["games"]
llms = (ROOT / "llms.txt").read_text(encoding="utf-8")
llms_full = (ROOT / "llms-full.txt").read_text(encoding="utf-8")
if not llms.startswith("# "):
    err("llms.txt: must start with an H1")
if "\n> " not in llms:
    err("llms.txt: missing blockquote summary")
for url in re.findall(r"\]\((https://playchive\.ir[^)\s]*)\)", llms):
    lp = local_for(url)
    if lp is None or not lp.exists():
        err(f"llms.txt: link does not resolve locally: {url}")
for g in games:
    if f"### {g['name']}" not in llms_full:
        err(f"llms-full.txt: missing {g['name']}")

# ------------------------------------------------- static catalog on the hub page
hub = (ROOT / "index.html").read_text(encoding="utf-8")
sec = re.search(r'id="static-catalog".*?</section>', hub, re.S)
if not sec:
    err("index.html: static catalog missing (non-JS crawlers would see nothing)")
else:
    text = sec.group(0)
    for g in games:
        if g["name"].replace("&", "&amp;").replace("'", "&#x27;") not in text and g["name"] not in text:
            err(f"index.html: static catalog missing {g['name']}")
    for href in re.findall(r'href="([^"#]+)"', text):
        if href.startswith(("http", "mailto:")):
            continue
        if not (ROOT / href.split("?")[0]).exists():
            err(f"index.html: static catalog link not found: {href}")

fa = (ROOT / "fa/index.html").read_text(encoding="utf-8")
for href in re.findall(r'href="(\.\./[^"#]+)"', fa):
    if not (ROOT / "fa" / href).resolve().exists():
        err(f"fa/index.html: broken relative link {href}")
if 'hreflang="fa"' not in hub or 'hreflang="en"' not in fa:
    err("hreflang pair between / and /fa/ is not reciprocal")

# ---------------------------------------------------------------- other files
key_files = list(ROOT.glob("[0-9a-f]" * 32 + ".txt"))
if not key_files:
    err("IndexNow key file missing")
else:
    for kf in key_files:
        if kf.read_text(encoding="utf-8").strip() != kf.stem:
            err(f"{kf.name}: content must equal the key")
for f in ("manifest.json", "agent-manifest.json", "data/games.json", "agent/catalog.json"):
    try:
        json.loads((ROOT / f).read_text(encoding="utf-8"))
    except Exception as e:  # noqa: BLE001
        err(f"{f}: invalid JSON ({e})")
if json.loads((ROOT / "agent/catalog.json").read_text())["games"] != games:
    err("agent/catalog.json is out of sync with data/games.json (run scripts/generate-seo.py)")

# ------------------------------------------------------------ API catalog (RFC 9727)
try:
    oa = json.loads((ROOT / "openapi.json").read_text(encoding="utf-8"))
    if not str(oa.get("openapi", "")).startswith("3."):
        err("openapi.json: not an OpenAPI 3.x document")
    if (oa.get("servers") or [{}])[0].get("url") != BASE:
        err("openapi.json: servers[0].url must be " + BASE)
    for path in oa.get("paths", {}):
        if not (ROOT / path.lstrip("/")).exists():
            err(f"openapi.json: documented path has no file: {path}")
except Exception as e:  # noqa: BLE001
    err(f"openapi.json: {e}")
worker_src = (ROOT / "worker/index.ts").read_text(encoding="utf-8")
if "text/markdown" not in worker_src or "wantsMarkdown" not in worker_src:
    err("worker/index.ts: Markdown for Agents negotiation is missing")
for p in pages:
    rel_md = p.relative_to(ROOT).as_posix()
    if rel_md == "openresident.html":
        continue
    rel_md = rel_md[: -len("index.html")] + "index.md" if rel_md.endswith("index.html") else rel_md[: -len(".html")] + ".md"
    if not (ROOT / "md" / rel_md).is_file():
        err(f"md/{rel_md}: markdown twin missing (run scripts/generate-seo.py)")
mcp_src = (ROOT / "worker/mcp.ts").read_text(encoding="utf-8") if (ROOT / "worker/mcp.ts").exists() else ""
for needle in ('"/mcp"', "CARD_PATHS", "handleMcp"):
    if needle not in worker_src:
        err(f"worker/index.ts: MCP wiring missing {needle}")
for needle in ("server/discover", "tools/list", "tools/call", "readOnlyHint", "streamable-http"):
    if needle not in mcp_src:
        err(f"worker/mcp.ts: missing {needle}")
if "/.well-known/api-catalog" not in worker_src or "application/linkset+json" not in worker_src:
    err("worker/index.ts: RFC 9727 api-catalog route is missing")
for anchor in re.findall(r'"(https://playchive\.ir/[^"]+\.json)"', worker_src):
    if not (ROOT / anchor[len(BASE) + 1:]).exists():
        err(f"worker/index.ts: api-catalog anchor has no file: {anchor}")
if "openapi.json" not in llms:
    err("llms.txt: should link openapi.json (run scripts/generate-seo.py)")
wf = (ROOT / ".github/workflows/build-and-deploy.yml").read_text(encoding="utf-8")
if "openapi.json" not in wf:
    err("workflow does not copy openapi.json into dist")

# ------------------------------------------------------------------- auth.md
am = ROOT / "auth.md"
if not am.exists():
    err("auth.md missing")
else:
    am_text = am.read_text(encoding="utf-8")
    first = next((l for l in am_text.splitlines() if l.strip()), "")
    if not re.match(r"#\s+.*auth\.md", first, re.I):
        err("auth.md: first line must be an H1 containing 'auth.md'")
    for url in re.findall(r"https://playchive\.ir/[^\s)`]+", am_text):
        url = url.rstrip(".,")
        if "/.well-known/" in url:
            continue
        lp = local_for(url)
        if lp is None or not lp.exists():
            err(f"auth.md: link does not resolve locally: {url}")
if "auth.md" not in wf:
    err("workflow does not copy auth.md into dist")
if "auth.md" not in llms:
    err("llms.txt: should link auth.md (run scripts/generate-seo.py)")

# ------------------------------------------------------- agent skills discovery
import hashlib
try:
    idx = json.loads((ROOT / "agent-skills/index.json").read_text(encoding="utf-8"))
    if idx.get("$schema") != "https://schemas.agentskills.io/discovery/0.2.0/schema.json":
        err("agent-skills/index.json: wrong $schema")
    if not idx.get("skills"):
        err("agent-skills/index.json: no skills")
    seen = set()
    for sk in idx.get("skills", []):
        for k in ("name", "type", "description", "url", "digest"):
            if not sk.get(k):
                err(f"agent-skills: skill missing {k}: {sk.get('name')}")
        n = sk.get("name", "")
        if not re.fullmatch(r"[a-z0-9]+(?:-[a-z0-9]+)*", n) or len(n) > 64:
            err(f"agent-skills: invalid skill name {n!r}")
        if n in seen:
            err(f"agent-skills: duplicate skill {n}")
        seen.add(n)
        if sk.get("type") != "skill-md":
            err(f"agent-skills: {n}: unsupported type")
        if len(sk.get("description", "")) > 1024:
            err(f"agent-skills: {n}: description over 1024 chars")
        f = ROOT / "agent-skills" / n / "SKILL.md"
        if not f.exists():
            err(f"agent-skills: {n}: SKILL.md missing")
            continue
        raw = f.read_bytes()
        if sk.get("digest") != "sha256:" + hashlib.sha256(raw).hexdigest():
            err(f"agent-skills: {n}: digest does not match SKILL.md (run scripts/generate-seo.py)")
        if sk.get("url") != f"{BASE}/.well-known/agent-skills/{n}/SKILL.md":
            err(f"agent-skills: {n}: unexpected url {sk.get('url')}")
        fm = re.match(r"---\n(.*?)\n---\n", raw.decode("utf-8"), re.S)
        fmd = dict(re.findall(r"^(\w+):\s*(.+)$", fm.group(1), re.M)) if fm else {}
        if fmd.get("description") != sk.get("description") or fmd.get("name") != n:
            err(f"agent-skills: {n}: frontmatter differs from index entry")
        for link in re.findall(r"https://playchive\.ir/[^\s)`,]*", raw.decode("utf-8")):
            link = link.rstrip(".")
            if "?" in link:
                continue
            lp = local_for(link)
            if lp is None or not lp.exists():
                err(f"agent-skills: {n}: link does not resolve locally: {link}")
except Exception as e:  # noqa: BLE001
    err(f"agent-skills/index.json: {e}")
if "agent-skills" not in wf or "agent-skills" not in worker_src:
    err("agent-skills not wired into workflow and worker")

# ---- bilingual parity and accessibility rules (see CLAUDE.md) ----
try:
    fa_html = (ROOT / "fa/index.html").read_text(encoding="utf-8")
    if '<html lang="fa" dir="rtl">' not in fa_html:
        err("fa/index.html must declare lang=fa and dir=rtl")
    playable = [g for g in games if g["playable"] and str(g.get("runtimeUrl", "")).endswith(".html")
                and (ROOT / g["runtimeUrl"]).exists()]
    # /fa/ is the same app as / (one design, language switched in place), so the shell must match the English page.
    if '<base href="../" />' not in fa_html:
        err('fa/index.html must carry <base href="../"> so it shares every asset with the root app')
    for needle in ('id="pc-lang"', 'id="theme-toggle"', 'id="wad-picker"', 'id="loading-screen"', 'src/main.js'):
        if needle not in fa_html:
            err(f"fa/index.html is missing {needle}: it must be the same app shell as index.html")
    static = re.search(r'<section id="static-catalog".*?</section>', fa_html, re.S)
    static_html = static.group(0) if static else ""
    for g in playable:
        item = re.search(rf'<li><a href="{re.escape(g["runtimeUrl"])}"[^>]*>.*?</li>', static_html, re.S)
        if not item or not re.search(r"[\u0600-\u06FF]", re.sub(r"<[^>]+>", "", item.group(0))):
            err(f"fa/index.html: no Persian entry for playable game {g['id']} (add it to FA_DESC in scripts/generate-seo.py)")
    # every English description needs its Persian twin for the in-page language switch
    fa_desc_js = (ROOT / "src/i18n/fa-descriptions.js").read_text(encoding="utf-8")
    for g in games:
        if json.dumps(g["description"], ensure_ascii=False) not in fa_desc_js:
            err(f"src/i18n/fa-descriptions.js: no Persian description for {g['id']} (FA_DESC or FA_REF in generate-seo.py)")
    ref_items = re.findall(r'<li class="ref">(.*?)</li>', fa_html, re.S)
    n_ref = len([g for g in games if g not in playable])
    if len(ref_items) != n_ref:
        err(f"fa/index.html: {len(ref_items)} reference entries, expected {n_ref} (add Persian text to FA_REF)")
    for it in ref_items:
        if not re.search(r"[\u0600-\u06FF]", re.sub(r"<[^>]+>", "", it).split(":", 1)[-1]):
            err("fa/index.html: a reference entry has no Persian description")
    for page in ["index.html", "fa/index.html"]:
        src = (ROOT / page).read_text(encoding="utf-8")
        for tag in re.findall(r"<img\b[^>]*>", src):
            if " alt=" not in tag:
                err(f"{page}: <img> without alt text: {tag[:80]}")
        for tag in re.findall(r"<button\b[^>]*>\s*</button>", src):
            if "aria-label" in tag or " id=" in tag:  # id: filled in by script at runtime
                continue
            err(f"{page}: empty button without accessible name: {tag[:80]}")
    # every catalog record must appear in the hub's structured data (playable list or reference list)
    hub_ld = [json.loads(b) for b in re.findall(r'<script type="application/ld\+json">(.*?)</script>',
                                                  (ROOT / "index.html").read_text(encoding="utf-8"), re.S)]
    names = {it["item"]["name"] for d in hub_ld for n in d.get("@graph", [d]) if n.get("@type") == "ItemList"
             or isinstance(n.get("mainEntity"), dict) for lst in ([n] if n.get("@type") == "ItemList" else [n["mainEntity"]])
             for it in lst.get("itemListElement", []) if isinstance(it.get("item"), dict)}
    for g in games:
        if g["name"] not in names:
            err(f"index.html JSON-LD: catalog record missing from structured data: {g['id']}")
except Exception as e:  # noqa: BLE001
    err(f"bilingual/accessibility checks failed to run: {e}")

# Persian coverage for the in-page language switch (needs node, which CI and the dev setup already have)
import shutil, subprocess
if shutil.which("node"):
    r = subprocess.run(["node", str(ROOT / "scripts/check-i18n.mjs")], capture_output=True, text=True)
    if r.returncode:
        for line in (r.stderr or r.stdout).strip().splitlines():
            err("i18n: " + line.strip())

print(f"noindex pages (skipped, correctly out of sitemap): {noindex_pages}")
print(f"checked {len(pages)} pages, {len(locs)} sitemap URLs, {len(games)} catalog records")
for w in warnings:
    print("WARN ", w)
for e in errors:
    print("ERROR", e)
print(f"{len(errors)} error(s), {len(warnings)} warning(s)")
sys.exit(1 if errors else 0)
