export * from './lang-assemblyscript';
