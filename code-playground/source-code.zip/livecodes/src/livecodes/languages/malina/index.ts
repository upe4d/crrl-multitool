export * from './lang-malina';
