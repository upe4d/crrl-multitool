export * from './lang-richtext';
