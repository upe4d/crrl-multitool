export * from './lang-prolog';
