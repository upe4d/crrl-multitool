export { languageInfo } from '../html';
