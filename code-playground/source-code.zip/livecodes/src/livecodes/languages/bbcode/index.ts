export * from './lang-bbcode';
