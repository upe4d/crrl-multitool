export * from './lang-dot';
