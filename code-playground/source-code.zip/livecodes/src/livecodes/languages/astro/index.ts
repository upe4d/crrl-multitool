export * from './lang-astro';
