import type { Metadata, Viewport } from "next";
import localFont from "next/font/local";
import Script from "next/script";
import { cookies, headers } from "next/headers";
import "./globals.css";
import { Providers } from "@/providers/providers";
import { MainNavigation } from "@/components/layout/main-navigation";
import {
  type Locale,
  LOCALE_COOKIE,
  LOCALE_HEADER,
  LOCALE_SOURCE_HEADER,
  defaultLocale,
  getDir,
  isLocale,
  ogAlternateLocales,
} from "@/lib/locales";
import { loadMessages } from "@/lib/messages";

// Satoshi (Fontshare/ITF free license, self-hosted) — the wordmark face only.
// Exposed as a variable so exactly one selector opts in (.railWordmark).
const satoshi = localFont({
  src: "../fonts/Satoshi-Bold.woff2",
  weight: "700",
  variable: "--font-satoshi",
  display: "swap",
  preload: false,
});

export const metadata: Metadata = { title: "Инструменты", manifest: "/pwa/manifest.webmanifest" };

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 5,
  colorScheme: "light dark",
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#FCFCFB" },
    { media: "(prefers-color-scheme: dark)", color: "#0E0E0D" },
  ],
};

export default async function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  // The middleware resolves the locale from the URL prefix (`/es/tools/x`) and
  // falls back to the cookie, so `<html lang>`/`dir` and the SSR'd translations
  // are correct for locale-prefixed URLs — which is what makes them indexable.
  // The cookie read stays as a fallback for any request that bypasses the
  // middleware matcher.
  const initialLocale: Locale = "ru";
  const localePinned = true;

  const initialMessages = await loadMessages(initialLocale);

  return (
    <html
      lang={initialLocale}
      dir={getDir(initialLocale)}
      className={satoshi.variable}
      suppressHydrationWarning
    >
      <head>
        <link rel="apple-touch-icon" href="/pwa/icon-192.png" />
        <link rel="stylesheet" href="/pwa/pwa.css" />
      </head>
      <body>
        <MainNavigation />
        <div id="pwa-controls" className="pwa-controls" hidden />
        <Providers
          initialLocale={initialLocale}
          initialMessages={initialMessages}
          localePinned={localePinned}
        >
          {children}
        </Providers>
        <Script src="/pwa/register.js" strategy="afterInteractive" />
      </body>
    </html>
  );
}
