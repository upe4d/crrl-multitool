"use client";

import { modelErrorMessage } from "@/lib/model-host";

import { useCallback, useRef, useState } from "react";
import { ToolShell } from "@/components/template/tool-shell";
import { FileDropzone } from "@/components/shared/FileDropzone";
import { OutputPanel } from "@/components/shared/OutputPanel";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { toast } from "sonner";
import { Upload, InfoIcon } from "lucide-react";
import { useTranslations } from "next-intl";
import { getPipeline, type LoadProgress } from "@/lib/hf-pipeline";

const MODEL = "Xenova/vit-gpt2-image-captioning";

type Captioner = (
  input: string
) => Promise<{ generated_text: string }[]>;

export default function ImageCaptioner() {
  const t = useTranslations("Tools.ImageCaptioner");
  const tc = useTranslations("ToolsConfig");



  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [progress, setProgress] = useState<LoadProgress | null>(null);
  const [caption, setCaption] = useState<string | null>(null);
  const objectUrlRef = useRef<string | null>(null);

  const onDrop = useCallback(
    (acceptedFiles: File[]) => {
      const file = acceptedFiles[0];
      if (!file) return;
      if (file.size > 15 * 1024 * 1024) {
        toast.error(t("imageTooLarge"));
        return;
      }
      if (objectUrlRef.current) URL.revokeObjectURL(objectUrlRef.current);
      const url = URL.createObjectURL(file);
      objectUrlRef.current = url;
      setImageUrl(url);
      setCaption(null);
    },
    [t]
  );

  const generate = useCallback(async () => {
    if (!imageUrl) {
      toast.error(t("noImage"));
      return;
    }
    setBusy(true);
    setCaption(null);
    try {
      const captioner = await getPipeline<Captioner>(
        "image-to-text",
        MODEL,
        { device: "auto", onProgress: setProgress }
      );
      const out = await captioner(imageUrl);
      const text = out?.[0]?.generated_text?.trim();
      if (!text) throw new Error("Empty caption");
      setCaption(text);
    } catch (err) {
      console.error(err);
      toast.error(modelErrorMessage(err, t("failed")));
    } finally {
      setBusy(false);
      setProgress(null);
    }
  }, [imageUrl, t]);

  const altSnippet = caption ? `alt="${caption}"` : "";

  return (
    <ToolShell
      slug="image-captioner"
      title={tc("tools.image-captioner.name")}
      sub={tc("tools.image-captioner.description")}
    >
      <div className="space-y-4">
          <Card className="p-6 shadow-none">
            <FileDropzone
              onFiles={onDrop}
              accept={{
                "image/*": [".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp"],
              }}
              multiple={false}
              className={({ isDragActive }) => `
                h-64 rounded-lg border-2 border-dashed
                flex flex-col items-center justify-center space-y-4 p-8
                cursor-pointer transition-[border-color,background-color] duration-150
                ${
                  isDragActive
                    ? "border-primary bg-primary/10 scale-[0.99]"
                    : "border-muted-foreground hover:border-primary hover:bg-primary/5"
                }
              `}
            >
              {imageUrl ? (
                <img
                  src={imageUrl}
                  alt={t("altPreview")}
                  className="max-h-full max-w-full object-contain"
                />
              ) : (
                <div className="text-center">
                  <div className="w-12 h-12 sm:w-16 sm:h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-3 sm:mb-4">
                    <Upload className="w-6 h-6 sm:w-8 sm:h-8 text-primary" />
                  </div>
                  <h3 className="text-lg font-semibold mb-1">
                    {t("dropImageHere")}
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    {t("supportedFormats")}
                  </p>
                </div>
              )}
            </FileDropzone>
          </Card>

          <Button onClick={generate} disabled={busy || !imageUrl}>
            {busy ? t("generating") : t("generate")}
          </Button>

          {busy && (!progress || progress.status !== "progress") && (
            <p className="text-xs text-muted-foreground" role="status">
              {progress?.status === "ready" ? "Ресурсы готовы, выполняется обработка" : "Подготовка и загрузка ресурсов"}
            </p>
          )}
          {busy && progress && progress.status === "progress" && (
            <div className="space-y-1">
              <Progress value={progress.percent} />
              <p className="text-xs text-muted-foreground">
                {t("loadingModel")} <span dir="ltr">{progress.percent}%</span> (текущий файл)
              </p>
            </div>
          )}

          {caption && (
            <div className="space-y-4" data-testid="caption-result">
              <OutputPanel
                text={caption}
                title={t("captionLabel")}
                copyLabel={t("copyCaption")}
                copySuccessMessage={t("copied")}
                copyErrorMessage={t("copyFailed")}
              >
                <p dir="auto" className="p-3.5 text-sm leading-relaxed">
                  {caption}
                </p>
              </OutputPanel>

              <OutputPanel
                text={altSnippet}
                title={t("altLabel")}
                copyLabel={t("copyAlt")}
                copySuccessMessage={t("copied")}
                copyErrorMessage={t("copyFailed")}
              >
                <pre dir="ltr" className="overflow-x-auto p-3.5 text-xs">
                  <code>{altSnippet}</code>
                </pre>
              </OutputPanel>
              <p className="text-xs text-muted-foreground">{t("altHint")}</p>
            </div>
          )}

          <Card className="p-4">
            <div className="flex items-start gap-3">
              <InfoIcon className="h-4 w-4 shrink-0 text-muted-foreground mt-0.5" />
              <div className="space-y-1">
                <p className="text-sm text-muted-foreground">{t("modelNote")}</p>
              </div>
            </div>
          </Card>
      </div>
    </ToolShell>
  );
}
