"use client";
import CodeScanner from "@/components/CodeScanner";
export default function BarcodeScanner() { return <CodeScanner kind="barcode" />; }
