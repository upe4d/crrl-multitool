"use client";

import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import { Upload, ArrowRightLeft } from "lucide-react";
import { useEffect, useRef } from "react";
import hljs from "highlight.js/lib/core";
import json from "highlight.js/lib/languages/json";
import "@/styles/hljs-theme.css";
import { useTranslations } from "next-intl";
import { ToolShell } from "@/components/template/tool-shell";
import { TwoPane } from "@/components/shared/TwoPane";
import { OutputPanel } from "@/components/shared/OutputPanel";

type ConversionMode = "jsonToCsv" | "csvToJson";
// Register the languages
hljs.registerLanguage("json", json);

export default function JsonCsvConverter() {
  const t = useTranslations("Tools.JsonCsvConverter");
  const tc = useTranslations("ToolsConfig");
  const outputRef = useRef<HTMLPreElement>(null);

  const [input, setInput] = useState("");
  const [output, setOutput] = useState("");
  const [mode, setMode] = useState<ConversionMode>("jsonToCsv");

  const convertJsonToCsv = (jsonString: string) => {
    try {
      const json = JSON.parse(jsonString);
      if (!Array.isArray(json)) {
        throw new Error("Input must be an array of objects");
      }

      // Get headers from all objects
      const headers = Array.from(
        new Set(json.flatMap((obj) => Object.keys(obj)))
      );

      // Create CSV rows
      const csvRows = [
        headers.join(","), // Header row
        ...json.map((obj) =>
          headers
            .map((header) => {
              const value = obj[header];
              // Handle special cases (null, undefined, objects, etc.)
              if (value === null || value === undefined) return "";
              if (typeof value === "object") return JSON.stringify(value);
              return String(value).replace(/,/g, ";").replace(/\n/g, " ");
            })
            .join(",")
        ),
      ];

      return csvRows.join("\n");
    } catch (error) {
      throw new Error(t("invalidJsonFormat"));
    }
  };

  const convertCsvToJson = (csvString: string) => {
    try {
      const rows = csvString.split("\n").filter((row) => row.trim());
      const headers = rows[0].split(",").map((header) => header.trim());

      const jsonArray = rows.slice(1).map((row) => {
        const values = row.split(",").map((value) => value.trim());
        const obj: Record<string, string> = {};
        headers.forEach((header, index) => {
          obj[header] = values[index] || "";
        });
        return obj;
      });

      return JSON.stringify(jsonArray, null, 2);
    } catch (error) {
      throw new Error(t("invalidCsvFormat"));
    }
  };

  const handleConvert = () => {
    if (!input.trim()) {
      toast.error(t("enterSomeInput"));
      return;
    }

    try {
      const result =
        mode === "jsonToCsv"
          ? convertJsonToCsv(input)
          : convertCsvToJson(input);
      setOutput(result);
      toast.success(t("conversionSuccessful"));
    } catch (error) {
      toast.error(error instanceof Error ? error.message : t("conversionSuccessful"));
    }
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      const content = e.target?.result as string;
      setInput(content);
      toast.success(t("fileLoadedSuccessfully"));
    };
    reader.onerror = () => {
      toast.error(t("errorReadingFile"));
    };
    reader.readAsText(file);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const newInput = e.target.value;
    setInput(newInput);

    if (!newInput.trim()) {
      setOutput("");
      return;
    }

    try {
      if (mode === "jsonToCsv") {
        const parsedJson = JSON.parse(newInput);
        const formattedJson = JSON.stringify(parsedJson, null, 2);
        setInput(formattedJson);
        const result = convertJsonToCsv(formattedJson);
        setOutput(result);
      } else {
        const result = convertCsvToJson(newInput);
        setOutput(result);
      }
    } catch (error) {
      setOutput("Invalid format");
    }
  };

  useEffect(() => {
    if (outputRef.current && output) {
      if (mode === "csvToJson") {
        hljs.highlightElement(outputRef.current);
      }
    }
  }, [output, mode]);

  return (
    <ToolShell
      slug="json-csv"
      title={tc("tools.json-csv.name")}
      sub={tc("tools.json-csv.description")}
    >
      <div className="space-y-4">
          <div className="flex items-center justify-between">
            <Select
              value={mode}
              onValueChange={(v) => setMode(v as ConversionMode)}
            >
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder={t("selectMode")} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="jsonToCsv">{t("jsonToCsv")}</SelectItem>
                <SelectItem value="csvToJson">{t("csvToJson")}</SelectItem>
              </SelectContent>
            </Select>

            <div className="flex items-center space-x-2 rtl:space-x-reverse">
              <input
                type="file"
                accept={mode === "jsonToCsv" ? ".json" : ".csv"}
                onChange={handleFileUpload}
                className="hidden"
                id="file-upload"
              />
              <label htmlFor="file-upload">
                <Button variant="outline" asChild>
                  <span>
                    <Upload className="h-4 w-4 me-2" />
                    {mode === "jsonToCsv" ? t("uploadJson") : t("uploadCsv")}
                  </span>
                </Button>
              </label>
              <Button onClick={handleConvert}>
                <ArrowRightLeft className="h-4 w-4 me-2" />
                {t("convert")}
              </Button>
            </div>
          </div>

          <TwoPane
            start={
              <Card className="p-4">
                <Textarea
                  placeholder={mode === "jsonToCsv" ? t("inputPlaceholderJson") : t("inputPlaceholderCsv")}
                  className="min-h-[400px] font-mono text-left"
                  dir="ltr"
                  value={input}
                  onChange={handleInputChange}
                />
              </Card>
            }
            end={
              <OutputPanel
                text={output}
                title={mode === "jsonToCsv" ? "CSV" : "JSON"}
                filename={mode === "jsonToCsv" ? "converted.csv" : "converted.json"}
                mime={mode === "jsonToCsv" ? "text/csv" : "application/json"}
                downloadSuccessMessage={t("fileDownloadedSuccessfully")}
              >
                {mode === "csvToJson" ? (
                  <pre
                    ref={outputRef}
                    className="language-json min-h-[400px] font-mono p-4 overflow-auto text-left"
                    dir="ltr"
                  >
                    <code>{output}</code>
                  </pre>
                ) : (
                  <Textarea
                    placeholder={t("outputPlaceholder")}
                    className="min-h-[400px] rounded-none border-0 bg-transparent font-mono text-left resize-none focus-visible:ring-0"
                    dir="ltr"
                    value={output}
                    readOnly
                  />
                )}
              </OutputPanel>
            }
          />
      </div>
    </ToolShell>
  );
}
