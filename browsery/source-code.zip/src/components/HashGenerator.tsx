"use client";

import { useState } from "react";
import { useLocale, useTranslations } from "next-intl";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Copy, Hash, FileText, Download, RefreshCw } from "lucide-react";
import { toast } from "sonner";
import { ToolShell } from "@/components/template/tool-shell";
import { CopyButton } from "@/components/shared/CopyButton";
import { downloadBlob } from "@/lib/download";
import { SettingsCard, OptionRow } from "@/components/shared/SettingsCard";
import { md5, sha1 } from "@noble/hashes/legacy.js";
import { sha256, sha384, sha512 } from "@noble/hashes/sha2.js";
import { bytesToHex } from "@noble/hashes/utils.js";

interface HashResult {
  algorithm: string;
  hash: string;
  length: number;
}

export default function HashGenerator() {
  const t = useTranslations("Tools.HashGenerator");
  const tc = useTranslations("ToolsConfig");
  const isRu = useLocale() === "ru";
  const [inputText, setInputText] = useState<string>("");
  const [hashResults, setHashResults] = useState<HashResult[]>([]);
  const [isGenerating, setIsGenerating] = useState<boolean>(false);

  const algorithms = [
    { name: "MD5", description: "128-bit hash (deprecated for security)" },
    { name: "SHA-1", description: "160-bit hash (deprecated for security)" },
    { name: "SHA-256", description: "256-bit hash (recommended)" },
    { name: "SHA-384", description: "384-bit hash" },
    { name: "SHA-512", description: "512-bit hash" },
  ];

  const generateHashes = async () => {
    setIsGenerating(true);
    try {
      const bytes = new TextEncoder().encode(inputText);
      const implementations = [md5, sha1, sha256, sha384, sha512];
      const results: HashResult[] = algorithms.map((alg, index) => {
        const hash = bytesToHex(implementations[index](bytes));
        return { algorithm: alg.name, hash, length: hash.length };
      });
      setHashResults(results);
      toast(t("hashesGeneratedToast"));
    } catch {
      setHashResults([]);
      toast.error(isRu ? "Не удалось вычислить хеш" : "Could not calculate hashes");
    } finally {
      setIsGenerating(false);
    }
  };

  const copyAllHashes = async () => {
    const allHashes = hashResults
      .map((result) => `${result.algorithm}: ${result.hash}`)
      .join("\n");

    try {
      await navigator.clipboard.writeText(allHashes);
      toast.success(t("copiedToClipboard"));
    } catch (err) {
      toast.error(t("copyFailed"));
    }
  };

  const downloadHashes = () => {
    const content = hashResults
      .map((result) => `${result.algorithm}: ${result.hash}`)
      .join("\n");

    downloadBlob(new Blob([content], { type: "text/plain" }), "hashes.txt");
  };

  const clearAll = () => {
    setInputText("");
    setHashResults([]);
  };

  const loadSampleText = () => {
    setInputText("Hello, World! This is a sample text for hashing.");
    setHashResults([]);
  };

  return (
    <ToolShell
      slug="hash-generator"
      title={tc("tools.hash-generator.name")}
      sub={tc("tools.hash-generator.description")}
    >
      <div className="max-w-4xl mx-auto">
      <Tabs defaultValue="text" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="text">{t("textInputTab")}</TabsTrigger>
          <TabsTrigger value="results">{t("resultsTab")}</TabsTrigger>
        </TabsList>

        <TabsContent value="text" className="space-y-6">
          <SettingsCard
            title={
              <span className="flex items-center gap-2">
                <FileText className="h-4 w-4" />
                {t("inputTitle")}
              </span>
            }
            description={t("inputDesc")}
          >
              <OptionRow label={t("textToHashLabel")} htmlFor="input-text">
                <Textarea
                  id="input-text"
                  value={inputText}
                  onChange={(e) => { setInputText(e.target.value); setHashResults([]); }}
                  placeholder={t("textToHashPlaceholder")}
                  className="min-h-[120px]"
                />
              </OptionRow>

              <div className="flex gap-2">
                <Button
                  onClick={generateHashes}
                  disabled={isGenerating}
                  className="flex-1"
                >
                  {isGenerating ? (
                    <>
                      <RefreshCw className="h-4 w-4 me-2 animate-spin" />
                      {t("generating")}
                    </>
                  ) : (
                    <>
                      <Hash className="h-4 w-4 me-2" />
                      {t("generateHashes")}
                    </>
                  )}
                </Button>
                <Button onClick={loadSampleText} variant="outline">
                  {t("loadSample")}
                </Button>
                <Button onClick={clearAll} variant="outline">
                  {t("clear")}
                </Button>
              </div>

              {inputText && (
                <div className="text-sm text-muted-foreground">
                  <div>{t("characters")} {inputText.length}</div>
                  <div>
                    {t("words")}{" "}
                    {
                      inputText
                        .trim()
                        .split(/\s+/)
                        .filter((word) => word.length > 0).length
                    }
                  </div>
                  <div>{t("lines")} {inputText.split("\n").length}</div>
                </div>
              )}
          </SettingsCard>
        </TabsContent>

        <TabsContent value="results" className="space-y-6">
          <SettingsCard
            title={t("generatedHashesTitle")}
            description={hashResults.length > 0
                  ? t("hashesGenerated", { count: hashResults.length })
                  : t("noHashesYet")}
          >
              {hashResults.length > 0 ? (
                <div className="space-y-4">
                  <div className="flex gap-2">
                    <Button onClick={copyAllHashes} variant="outline" size="sm">
                      <Copy className="h-4 w-4 me-2" />
                      {t("copyAll")}
                    </Button>
                    <Button
                      onClick={downloadHashes}
                      variant="outline"
                      size="sm"
                    >
                      <Download className="h-4 w-4 me-2" />
                      {t("download")}
                    </Button>
                  </div>

                  <div className="space-y-3">
                    {hashResults.map((result, index) => (
                      <div key={index} className="p-4 border rounded-lg">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <Badge variant="outline">{result.algorithm}</Badge>
                            <span className="text-sm text-muted-foreground">
                              {t("hashLength", { count: result.length })}
                            </span>
                          </div>
                          <CopyButton
                            text={result.hash}
                            size="icon"
                            successMessage={t("copiedToClipboard")}
                            errorMessage={t("copyFailed")}
                          />
                        </div>
                        <div className="font-mono text-sm bg-muted p-2 rounded break-all" dir="ltr">
                          {result.hash}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <Hash className="h-16 w-16 mx-auto mb-4 opacity-50" />
                  <p>{t("generateToSeeResults")}</p>
                </div>
              )}
          </SettingsCard>
        </TabsContent>
      </Tabs>

      {/* Algorithm Information */}
      <SettingsCard title={t("algorithmInfo")} className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-semibold mb-2">{t("algorithmDetails")}</h4>
              <div className="space-y-2">
                {algorithms.map((alg) => (
                  <div
                    key={alg.name}
                    className="flex items-center justify-between p-2 border rounded"
                  >
                    <div>
                      <div className="font-medium">{alg.name}</div>
                      <div className="text-sm text-muted-foreground">
                        {alg.description}
                      </div>
                    </div>
                    <Badge variant="outline">
                      {alg.name === "MD5"
                        ? "32 chars"
                        : alg.name === "SHA-1"
                        ? "40 chars"
                        : alg.name === "SHA-256"
                        ? "64 chars"
                        : alg.name === "SHA-384"
                        ? "96 chars"
                        : "128 chars"}
                    </Badge>
                  </div>
                ))}
              </div>
            </div>
            <div>
              <h4 className="font-semibold mb-2">{t("securityRecommendations")}</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li className="flex items-start gap-2">
                  <Badge variant="destructive" className="text-xs">
                    {t("avoid")}
                  </Badge>
                  <span>{t("avoidDesc")}</span>
                </li>
                <li className="flex items-start gap-2">
                  <Badge variant="default" className="text-xs bg-green-500">
                    {t("recommended")}
                  </Badge>
                  <span>{t("recommendedDesc")}</span>
                </li>
                <li className="flex items-start gap-2">
                  <Badge variant="secondary" className="text-xs">
                    {t("highSecurity")}
                  </Badge>
                  <span>{t("highSecurityDesc")}</span>
                </li>
                <li className="flex items-start gap-2">
                  <Badge variant="outline" className="text-xs">
                    {t("note")}
                  </Badge>
                  <span>{t("noteDesc")}</span>
                </li>
              </ul>
            </div>
          </div>
      </SettingsCard>
      </div>
    </ToolShell>
  );
}
