"use client";

import { useState } from "react";
import { useTranslations } from "next-intl";
import { encode } from "gpt-tokenizer";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { ToolShell } from "@/components/template/tool-shell";
import { SettingsCard } from "@/components/shared/SettingsCard";
import { StatStrip } from "@/components/shared/StatStrip";
import { AI_MODELS } from "@/lib/ai-models";

const MULTIPLIERS: Record<string, number> = {
  "claude-opus-4-6": 1.05,
  "claude-sonnet-4-6": 1.05,
  "claude-haiku-4-5": 1.05,
  "llama-3-3-70b": 1.02,
};

const SAMPLE_TEXT =
  "You are a helpful AI assistant specializing in software engineering.\n\nUser: Can you help me write a fibonacci function in TypeScript?\n\nAssistant: Here's an efficient memoized implementation...";

export default function ContextWindowCalculator() {
  const t = useTranslations("Tools.ContextWindow");
  const tc = useTranslations("ToolsConfig");
  const [text, setText] = useState("");
  const [selectedModelId, setSelectedModelId] = useState(AI_MODELS[0].id);

  const selectedModel =
    AI_MODELS.find((m) => m.id === selectedModelId) ?? AI_MODELS[0];
  const multiplier = MULTIPLIERS[selectedModelId] ?? 1.0;
  const tokenCount = text ? Math.round(encode(text).length * multiplier) : 0;
  const contextWindow = selectedModel.contextWindow;
  const usagePercent = Math.min((tokenCount / contextWindow) * 100, 100);
  const remaining = Math.max(contextWindow - tokenCount, 0);

  const getBarColor = () => {
    if (usagePercent < 50) return "bg-green-500";
    if (usagePercent < 80) return "bg-yellow-500";
    if (usagePercent < 95) return "bg-orange-500";
    return "bg-red-500";
  };

  const getStatusBadge = () => {
    if (usagePercent < 50) return { label: "OK", className: "bg-green-500 text-white" };
    if (usagePercent < 80) return { label: t("dangerZone").split(":")[0], className: "bg-yellow-500 text-white" };
    return { label: t("criticalZone").split(":")[0], className: "bg-red-500 text-white" };
  };

  const status = getStatusBadge();

  return (
    <ToolShell
      slug="context-window"
      title={tc("tools.context-window.name")}
      sub={tc("tools.context-window.description")}
      controls={
        <>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setText(SAMPLE_TEXT)}
          >
            {t("loadSample")}
          </Button>
          <Button variant="outline" size="sm" onClick={() => setText("")}>
            {t("clearAll")}
          </Button>
        </>
      }
    >
      <div className="space-y-4">
        <div className="space-y-2">
          <Label>{t("modelLabel")}</Label>
          <Select value={selectedModelId} onValueChange={setSelectedModelId}>
            <SelectTrigger className="w-full sm:w-80">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {AI_MODELS.map((model) => (
                <SelectItem key={model.id} value={model.id}>
                  {model.name} ({model.provider})
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label>{t("inputLabel")}</Label>
          <Textarea
            dir="auto"
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder={t("inputPlaceholder")}
            className="min-h-[200px] font-mono text-sm resize-y"
          />
        </div>

        <SettingsCard
          title={`${selectedModel.name} — ${selectedModel.provider}`}
          action={
            text ? <Badge className={status.className}>{status.label}</Badge> : undefined
          }
        >
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">{t("tokenCount")}</span>
              <span className="font-medium tabular-nums">
                {tokenCount.toLocaleString()} /{" "}
                {contextWindow.toLocaleString()}
              </span>
            </div>
            <div className="w-full bg-muted rounded-full h-3 overflow-hidden">
              <div
                className={`h-full rounded-full transition-[width] ${getBarColor()}`}
                style={{ width: `${usagePercent}%` }}
              />
            </div>
            <p className="text-xs text-muted-foreground text-right">
              {usagePercent.toFixed(1)}% {t("percentFilled")}
            </p>
          </div>

          <StatStrip
            items={[
              { label: t("tokenCount"), value: tokenCount.toLocaleString() },
              { label: t("contextWindow"), value: contextWindow.toLocaleString() },
              { label: t("contextUsed"), value: `${usagePercent.toFixed(1)}%` },
              { label: t("tokensRemaining"), value: remaining.toLocaleString() },
            ]}
          />

          {usagePercent >= 80 && (
            <p className="text-sm text-orange-600 dark:text-orange-400 font-medium">
              {usagePercent >= 95 ? t("criticalZone") : t("dangerZone")}
            </p>
          )}
        </SettingsCard>
      </div>
    </ToolShell>
  );
}
