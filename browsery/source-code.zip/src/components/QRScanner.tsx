"use client";
import CodeScanner from "@/components/CodeScanner";
export default function QRScanner() { return <CodeScanner kind="qr" />; }
