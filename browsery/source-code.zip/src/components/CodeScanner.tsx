"use client";

import { useCallback, useEffect, useRef, useState, type ChangeEvent } from "react";
import { useLocale, useTranslations } from "next-intl";
import { BrowserCodeReader, BrowserMultiFormatOneDReader, BrowserQRCodeReader } from "@zxing/browser";
import { BarcodeFormat, DecodeHintType, ChecksumException, FormatException, NotFoundException } from "@zxing/library";
import { ToolShell } from "@/components/template/tool-shell";
import { Button } from "@/components/ui/button";

type ScannerKind = "qr" | "barcode";
type Result = { text: string; format: string };
const MAX_IMAGE_BYTES = 20 * 1024 * 1024;
const MAX_IMAGE_SIDE = 2400;
const SCAN_INTERVAL_MS = 250;

function makeReader(kind: ScannerKind): BrowserCodeReader {
  const hints = new Map<DecodeHintType, unknown>();
  hints.set(DecodeHintType.POSSIBLE_FORMATS, kind === "qr" ? [BarcodeFormat.QR_CODE] : [
    BarcodeFormat.CODE_128, BarcodeFormat.CODE_39, BarcodeFormat.CODE_93,
    BarcodeFormat.EAN_13, BarcodeFormat.EAN_8, BarcodeFormat.UPC_A,
    BarcodeFormat.UPC_E, BarcodeFormat.ITF, BarcodeFormat.CODABAR,
  ]);
  hints.set(DecodeHintType.TRY_HARDER, true);
  return kind === "qr" ? new BrowserQRCodeReader(hints) : new BrowserMultiFormatOneDReader(hints);
}

function isMissingCode(error: unknown): boolean {
  return error instanceof NotFoundException || error instanceof ChecksumException || error instanceof FormatException;
}

function drawImage(canvas: HTMLCanvasElement, source: CanvasImageSource, width: number, height: number): void {
  if (!width || !height) throw new Error("image");
  const scale = Math.min(1, MAX_IMAGE_SIDE / Math.max(width, height));
  canvas.width = Math.max(1, Math.round(width * scale));
  canvas.height = Math.max(1, Math.round(height * scale));
  const context = canvas.getContext("2d", { willReadFrequently: true });
  if (!context) throw new Error("canvas");
  context.drawImage(source, 0, 0, canvas.width, canvas.height);
}

export default function CodeScanner({ kind }: { kind: ScannerKind }) {
  const tc = useTranslations("ToolsConfig");
  const ru = useLocale() === "ru";
  const slug = kind === "qr" ? "qr-scanner" : "barcode-scanner";
  const [result, setResult] = useState<Result | null>(null);
  const [error, setError] = useState("");
  const [status, setStatus] = useState("");
  const [scanning, setScanning] = useState(false);
  const [working, setWorking] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const epochRef = useRef(0);
  const mountedRef = useRef(true);
  const readerRef = useRef<BrowserCodeReader | null>(null);

  const stopCamera = useCallback((update = true) => {
    epochRef.current++;
    if (timerRef.current !== null) clearTimeout(timerRef.current);
    timerRef.current = null;
    streamRef.current?.getTracks().forEach((track) => track.stop());
    streamRef.current = null;
    if (videoRef.current) videoRef.current.srcObject = null;
    if (update && mountedRef.current) { setScanning(false); setWorking(false); }
  }, []);

  useEffect(() => {
    mountedRef.current = true;
    return () => { mountedRef.current = false; stopCamera(false); };
  }, [stopCamera]);

  const reader = () => (readerRef.current ||= makeReader(kind));
  const readCanvas = (): Result | null => {
    try {
      const canvas = canvasRef.current;
      if (!canvas) throw new Error("canvas");
      const found = reader().decodeFromCanvas(canvas);
      return { text: found.getText(), format: BarcodeFormat[found.getBarcodeFormat()] || "" };
    } catch (err) {
      if (isMissingCode(err)) return null;
      throw err;
    }
  };

  const startCamera = async () => {
    if (working || streamRef.current) return;
    setError(""); setStatus(""); setResult(null); setWorking(true);
    const epoch = ++epochRef.current;
    try {
      if (!navigator.mediaDevices?.getUserMedia) throw new Error("unsupported");
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: "environment" } }, audio: false });
      if (!mountedRef.current || epoch !== epochRef.current) { stream.getTracks().forEach((track) => track.stop()); return; }
      streamRef.current = stream;
      const video = videoRef.current;
      if (!video) throw new Error("camera");
      video.srcObject = stream;
      await video.play();
      if (!mountedRef.current || epoch !== epochRef.current) return;
      setScanning(true); setWorking(false);
      const tick = () => {
        if (!mountedRef.current || epoch !== epochRef.current || !streamRef.current) return;
        try {
          if (video.readyState >= HTMLMediaElement.HAVE_CURRENT_DATA && video.videoWidth && canvasRef.current) {
            drawImage(canvasRef.current, video, video.videoWidth, video.videoHeight);
            const found = readCanvas();
            if (found) { setResult(found); setStatus(ru ? "Код распознан" : "Code recognized"); stopCamera(); return; }
          }
        } catch {
          setError(ru ? "Не удалось обработать изображение с камеры." : "Could not process the camera image.");
          stopCamera(); return;
        }
        timerRef.current = setTimeout(tick, SCAN_INTERVAL_MS);
      };
      timerRef.current = setTimeout(tick, 0);
    } catch (err) {
      if (!mountedRef.current || epoch !== epochRef.current) return;
      const name = err instanceof Error ? err.name : "";
      setError(name === "NotAllowedError" ? (ru ? "Доступ к камере запрещён. Разрешите его в настройках браузера." : "Camera access denied. Allow it in browser settings.")
        : name === "NotFoundError" ? (ru ? "Камера не найдена." : "No camera was found.")
        : (ru ? "Не удалось открыть камеру. Проверьте подключение и доступ к ней; вне localhost требуется HTTPS." : "Could not open the camera. Check access; HTTPS is required outside localhost."));
      stopCamera();
    }
  };

  const upload = async (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    event.target.value = "";
    if (!file) return;
    stopCamera(); setError(""); setStatus(""); setResult(null);
    if (!file.type.startsWith("image/") || file.size > MAX_IMAGE_BYTES) {
      setError(ru ? "Выберите изображение размером не более 20 МБ." : "Choose an image no larger than 20 MB."); return;
    }
    setWorking(true);
    const epoch = ++epochRef.current;
    const url = URL.createObjectURL(file);
    try {
      const image = new Image();
      await new Promise<void>((resolve, reject) => { image.onload = () => resolve(); image.onerror = () => reject(new Error("image")); image.src = url; });
      if (!mountedRef.current || epoch !== epochRef.current) return;
      if (!canvasRef.current) throw new Error("canvas");
      drawImage(canvasRef.current, image, image.naturalWidth, image.naturalHeight);
      const found = readCanvas();
      if (found) { setResult(found); setStatus(ru ? "Код распознан" : "Code recognized"); }
      else setError(ru ? "Код на изображении не найден. Попробуйте другое фото." : "No code found. Try another image.");
    } catch {
      if (mountedRef.current && epoch === epochRef.current) setError(ru ? "Не удалось обработать изображение." : "Could not process the image.");
    } finally {
      URL.revokeObjectURL(url);
      if (mountedRef.current && epoch === epochRef.current) setWorking(false);
    }
  };

  const copy = async () => {
    if (!result) return;
    try { await navigator.clipboard.writeText(result.text); setStatus(ru ? "Скопировано" : "Copied"); }
    catch { setError(ru ? "Не удалось скопировать. Выделите текст вручную." : "Could not copy. Select the text manually."); }
  };

  return <ToolShell slug={slug} title={tc(`tools.${slug}.name`)} sub={tc(`tools.${slug}.description`)}>
    <div className="space-y-5">
      <p className="text-sm text-muted-foreground">{kind === "qr" ? (ru ? "Распознайте QR-код на фото или через камеру." : "Read a QR code from an image or camera.") : (ru ? "Распознайте штрихкод на фото или через камеру: EAN, UPC, Code 128, Code 39 и другие." : "Read EAN, UPC, Code 128, Code 39 and other barcodes from an image or camera.")}</p>
      <div className="flex flex-wrap items-center gap-3">
        <Button type="button" onClick={scanning ? () => stopCamera() : startCamera} disabled={working}>{scanning ? (ru ? "Остановить камеру" : "Stop camera") : (ru ? "Включить камеру" : "Start camera")}</Button>
        <label className="inline-flex min-h-10 cursor-pointer items-center rounded-md border px-4 py-2 text-sm hover:bg-accent">{ru ? "Выбрать изображение" : "Choose an image"}<input type="file" accept="image/*" className="sr-only" onChange={upload} disabled={working} /></label>
      </div>
      <video ref={videoRef} className="max-h-80 w-full rounded-md bg-black object-contain" hidden={!scanning} muted playsInline />
      <canvas ref={canvasRef} hidden />
      {working && <p role="status" className="text-sm text-muted-foreground">{ru ? "Обработка…" : "Processing…"}</p>}
      {error && <p role="alert" className="text-sm text-red-400">{error}</p>}
      {status && <p role="status" className="text-sm text-muted-foreground">{status}</p>}
      {result && <div className="space-y-2"><label htmlFor="scanner-result" className="text-sm font-medium">{ru ? "Результат" : "Result"}{kind === "barcode" && result.format ? ` · ${result.format}` : ""}</label><textarea id="scanner-result" readOnly value={result.text} rows={3} className="w-full rounded-md border bg-background p-3" /><Button type="button" variant="outline" onClick={copy}>{ru ? "Копировать" : "Copy"}</Button></div>}
    </div>
  </ToolShell>;
}
