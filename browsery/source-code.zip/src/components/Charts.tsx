"use client";

import { useState, useRef } from "react";
import {
  ChartType,
  ChartDataPoint,
  ChartSettings,
  DEFAULT_CHART_SETTINGS,
  SAMPLE_DATA,
} from "@/types/chart";
import { ChartTypeSelector } from "./ChartTypeSelector";
import { ChartDataEditor } from "./ChartDataEditor";
import { ChartCustomizationPanel } from "./ChartCustomizationPanel";
import { ChartRenderer } from "./ChartRenderer";
import { ChartExport } from "./ChartExport";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import {
  BarChart3,
  Settings,
  Download,
  RotateCcw,
  Eye,
} from "lucide-react";
import { useTranslations } from "next-intl";
import { ToolShell } from "@/components/template/tool-shell";
import { SettingsCard } from "@/components/shared/SettingsCard";

export function Charts() {
  const t = useTranslations("Tools.Charts");
  const tc = useTranslations("ToolsConfig");
  const [chartType, setChartType] = useState<ChartType>("bar");
  const [data, setData] = useState<ChartDataPoint[]>(SAMPLE_DATA.bar);
  const [settings, setSettings] = useState<ChartSettings>(
    DEFAULT_CHART_SETTINGS
  );
  const [activeTab, setActiveTab] = useState("preview");
  const chartRef = useRef<HTMLDivElement>(null);

  const handleChartTypeChange = (type: ChartType) => {
    setChartType(type);
    // deep copy to avoid reference reuse issues
    const sample = JSON.parse(JSON.stringify(SAMPLE_DATA[type]));
    setData(sample);
  };

  const handleDataChange = (newData: ChartDataPoint[]) => {
    setData(newData);
  };

  const handleSettingsChange = (newSettings: ChartSettings) => {
    setSettings(newSettings);
  };

  const resetToDefaults = () => {
    setChartType("bar");
    setData(SAMPLE_DATA.bar);
    setSettings(DEFAULT_CHART_SETTINGS);
  };

  const getDataKeys = () => {
    if (data.length === 0) return [];
    return Object.keys(data[0]).slice(1);
  };

  return (
    <ToolShell
      slug="charts"
      title={tc("tools.charts.name")}
      sub={tc("tools.charts.description")}
      width="wide"
    >
      <div className="flex flex-col lg:flex-row gap-4 min-h-screen">
        {/* Left Sidebar - Controls */}
        <div className="w-full lg:w-[40%] overflow-y-auto space-y-4 pe-4 scrollbar-hide max-h-screen">
          {/* Chart Type Selection */}
          <SettingsCard
            title={
              <span className="inline-flex items-center gap-2">
                <BarChart3 className="h-4 w-4" />
                {t("chartTypeTitle")}
              </span>
            }
          >
            <ChartTypeSelector
              selectedType={chartType}
              onTypeChange={handleChartTypeChange}
            />
          </SettingsCard>

          {/* Data Editor */}
          <SettingsCard>
            <ChartDataEditor
              chartType={chartType}
              data={data}
              onDataChange={handleDataChange}
            />
          </SettingsCard>

          {/* Customization Panel */}
          <SettingsCard
            title={
              <span className="inline-flex items-center gap-2">
                <Settings className="h-4 w-4" />
                {t("customizationTitle")}
              </span>
            }
          >
            <ChartCustomizationPanel
              settings={settings}
              onSettingsChange={handleSettingsChange}
              dataKeys={getDataKeys()}
              chartType={chartType}
            />
          </SettingsCard>

          {/* Export Panel */}
          <SettingsCard
            title={
              <span className="inline-flex items-center gap-2">
                <Download className="h-4 w-4" />
                {t("exportTitle")}
              </span>
            }
          >
            <ChartExport
              chartRef={chartRef}
              data={data}
              settings={settings}
              chartType={chartType}
            />
          </SettingsCard>
        </div>

        {/* Right Side - Chart Preview */}
        <div className="w-full lg:w-[60%] lg:sticky lg:top-4 lg:self-start">
          <Card className="h-fit max-h-[calc(100vh-2rem)] shadow-none">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <Eye className="h-5 w-5" />
                    {t("chartPreviewTitle")}
                  </CardTitle>
                  <p className="text-sm text-muted-foreground mt-1">
                    {t("chartPreviewDesc")}
                  </p>
                </div>
                <Tabs value={activeTab} onValueChange={setActiveTab}>
                  <TabsList>
                    <TabsTrigger value="preview">{t("preview")}</TabsTrigger>
                    <TabsTrigger value="code">{t("code")}</TabsTrigger>
                  </TabsList>
                </Tabs>
              </div>
            </CardHeader>
            <CardContent>
              <Tabs value={activeTab} onValueChange={setActiveTab}>
                <TabsContent value="preview" className="space-y-4">
                  <div ref={chartRef}>
                    <ChartRenderer
                      chartType={chartType}
                      data={data}
                      settings={settings}
                    />
                  </div>
                </TabsContent>

                <TabsContent value="code" className="space-y-4">
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-medium mb-2">{t("chartConfig")}</h4>
                      <pre className="bg-muted p-4 rounded-lg overflow-x-auto text-sm" dir="ltr">
                        <code>{JSON.stringify(settings, null, 2)}</code>
                      </pre>
                    </div>

                    <div>
                      <h4 className="font-medium mb-2">{t("chartData")}</h4>
                      <pre className="bg-muted p-4 rounded-lg overflow-x-auto text-sm" dir="ltr">
                        <code>{JSON.stringify(data, null, 2)}</code>
                      </pre>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>

          {/* Reset Button */}
          <div className="mt-4">
            <Button
              variant="outline"
              onClick={resetToDefaults}
              className="w-full"
            >
              <RotateCcw className="h-4 w-4 me-2" />
              {t("resetToDefaults")}
            </Button>
          </div>
        </div>
      </div>
    </ToolShell>
  );
}
