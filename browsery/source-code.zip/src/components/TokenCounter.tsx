"use client";

import { useState } from "react";
import { useTranslations } from "next-intl";
import { encode } from "gpt-tokenizer";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ToolShell } from "@/components/template/tool-shell";
import { CopyButton } from "@/components/shared/CopyButton";
import { SettingsCard } from "@/components/shared/SettingsCard";
import { StatStrip } from "@/components/shared/StatStrip";
import { AI_MODELS } from "@/lib/ai-models";

interface ModelOption {
  id: string;
  label: string;
  multiplier: number;
}

const MODEL_OPTIONS: ModelOption[] = [
  { id: "gpt-4o", label: "GPT-4o", multiplier: 1.0 },
  { id: "gpt-4o-mini", label: "GPT-4o mini", multiplier: 1.0 },
  { id: "claude-sonnet-4-6", label: "Claude Sonnet 4.6", multiplier: 1.05 },
  { id: "claude-haiku-4-5", label: "Claude Haiku 4.5", multiplier: 1.05 },
  { id: "llama-3-3-70b", label: "Llama 3.3 70B", multiplier: 1.02 },
  { id: "gemini-2-0-flash", label: "Gemini 2.0 Flash", multiplier: 1.0 },
];

const SAMPLE_TEXT =
  "The quick brown fox jumps over the lazy dog. This is a sample text to demonstrate token counting across different AI models. Token counts can vary slightly between models due to differences in their tokenization algorithms. GPT-4 uses the cl100k_base tokenizer, while Claude uses its own tokenizer with slightly different behavior.";

export default function TokenCounter() {
  const t = useTranslations("Tools.TokenCounter");
  const tc = useTranslations("ToolsConfig");
  const [text, setText] = useState("");
  const [selectedModelId, setSelectedModelId] = useState("gpt-4o");

  const selectedOption =
    MODEL_OPTIONS.find((m) => m.id === selectedModelId) ?? MODEL_OPTIONS[0];
  const aiModel = AI_MODELS.find((m) => m.id === selectedModelId);

  const rawTokens = text ? encode(text).length : 0;
  const tokens = Math.round(rawTokens * selectedOption.multiplier);
  const characters = text.length;
  const words = text.trim() ? text.trim().split(/\s+/).length : 0;

  const inputCost = aiModel ? (tokens / 1_000_000) * aiModel.inputPricePer1M : 0;
  const outputCost = aiModel
    ? (tokens / 1_000_000) * aiModel.outputPricePer1M
    : 0;

  const formatCost = (cost: number) => {
    if (cost === 0) return "$0.00";
    if (cost < 0.000001) return `$${cost.toExponential(2)}`;
    if (cost < 0.01) return `$${cost.toFixed(6)}`;
    return `$${cost.toFixed(4)}`;
  };

  return (
    <ToolShell
      slug="token-counter"
      title={tc("tools.token-counter.name")}
      sub={tc("tools.token-counter.description")}
      controls={
        <>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setText(SAMPLE_TEXT)}
          >
            {t("loadSample")}
          </Button>
          <Button variant="outline" size="sm" onClick={() => setText("")}>
            {t("clearAll")}
          </Button>
          {text && (
            <CopyButton
              text={tokens.toString()}
              label={`${t("totalTokens")}: ${tokens.toLocaleString()}`}
              successMessage={t("copiedToClipboard")}
            />
          )}
        </>
      }
    >
      <div className="space-y-4">
        <div className="space-y-2">
          <Label>{t("modelLabel")}</Label>
          <Select value={selectedModelId} onValueChange={setSelectedModelId}>
            <SelectTrigger className="w-full sm:w-64">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {MODEL_OPTIONS.map((m) => (
                <SelectItem key={m.id} value={m.id}>
                  {m.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label>{t("inputLabel")}</Label>
          <Textarea
            dir="auto"
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder={t("inputPlaceholder")}
            className="min-h-[200px] font-mono text-sm resize-y"
          />
        </div>

        {text ? (
          <StatStrip
            items={[
              { label: t("totalTokens"), value: tokens.toLocaleString() },
              { label: t("characters"), value: characters.toLocaleString() },
              { label: t("words"), value: words.toLocaleString() },
              {
                label: t("estimatedCost"),
                value: formatCost(inputCost),
                sub: t("inputCost"),
              },
            ]}
          />
        ) : (
          <Card>
            <CardContent className="py-8 text-center text-muted-foreground">
              {t("noText")}
            </CardContent>
          </Card>
        )}

        {text && aiModel && (
          <SettingsCard title={`${aiModel.name} — ${aiModel.provider}`}>
            <StatStrip
              items={[
                {
                  label: t("inputCost"),
                  value: formatCost(inputCost),
                  sub: `$${aiModel.inputPricePer1M}/1M tokens`,
                },
                {
                  label: t("outputCost"),
                  value: formatCost(outputCost),
                  sub: `$${aiModel.outputPricePer1M}/1M tokens`,
                },
              ]}
            />
            <p className="text-xs text-muted-foreground">
              {t("assumingOutputLabel")}
            </p>
          </SettingsCard>
        )}
      </div>
    </ToolShell>
  );
}
