export function JsonLdScript(_props: {data: Record<string, unknown>}) { return null; }
