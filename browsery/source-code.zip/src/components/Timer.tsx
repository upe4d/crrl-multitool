"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useTranslations } from "next-intl";
import NumberFlow from "@number-flow/react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ToolShell } from "@/components/template/tool-shell";
import {
  Play,
  Pause,
  RotateCcw,
  Maximize2,
  Minimize2,
  Bell,
} from "lucide-react";
import { playBeep } from "@/lib/time-format";
import { SettingsCard, OptionRow } from "@/components/shared/SettingsCard";

type Mode = "countdown" | "stopwatch";

function formatTime(totalMs: number): {
  hh: number;
  mm: number;
  ss: number;
  ms: number;
} {
  const clamped = Math.max(0, Math.floor(totalMs));
  const ms = clamped % 1000;
  const totalSeconds = Math.floor(clamped / 1000);
  const ss = totalSeconds % 60;
  const totalMinutes = Math.floor(totalSeconds / 60);
  const mm = totalMinutes % 60;
  const hh = Math.floor(totalMinutes / 60);
  return { hh, mm, ss, ms };
}

export default function Timer({
  slug = "timer",
  preset,
}: {
  slug?: string;
  preset?: { mode?: "countdown"; seconds?: number; autoFullscreenHint?: boolean };
} = {}) {
  const t = useTranslations("Tools.Timer");
  const tc = useTranslations("ToolsConfig");
  const [mode, setMode] = useState<Mode>(preset?.mode ?? "countdown");
  const [isRunning, setIsRunning] = useState(false);
  const [initialMs, setInitialMs] = useState(
    preset?.seconds != null ? preset.seconds * 1000 : 5 * 60 * 1000,
  ); // default 5 min
  const [elapsedMs, setElapsedMs] = useState(0);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showControls, setShowControls] = useState(true);
  const requestRef = useRef<number | null>(null);
  const lastTickRef = useRef<number | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const hideControlsTimeoutRef = useRef<number | null>(null);

  // Remaining or elapsed display value in ms
  const displayMs = useMemo(() => {
    if (mode === "countdown") {
      return Math.max(0, initialMs - elapsedMs);
    }
    return elapsedMs;
  }, [mode, initialMs, elapsedMs]);

  const { hh, mm, ss } = formatTime(displayMs);

  const tick = useCallback(
    (now: number) => {
      if (!isRunning) return;
      if (lastTickRef.current == null) {
        lastTickRef.current = now;
      }
      const delta = now - lastTickRef.current;
      lastTickRef.current = now;

      setElapsedMs((prev) => {
        const next = prev + delta;
        if (mode === "countdown" && next >= initialMs) {
          // completion
          cancelAnimationFrame(requestRef.current ?? 0);
          requestRef.current = null;
          lastTickRef.current = null;
          setIsRunning(false);
          // play sound
          playBeep(880, 600);
          return initialMs;
        }
        return next;
      });

      requestRef.current = requestAnimationFrame(tick);
    },
    [isRunning, mode, initialMs]
  );

  useEffect(() => {
    if (isRunning) {
      requestRef.current = requestAnimationFrame(tick);
      return () => {
        if (requestRef.current) cancelAnimationFrame(requestRef.current);
      };
    }
  }, [isRunning, tick]);

  const handleStartPause = () => {
    if (isRunning) {
      setIsRunning(false);
      lastTickRef.current = null;
      // manual pause cue: lower pitch
      playBeep(440, 150);
    } else {
      setIsRunning(true);
      // manual start cue: higher pitch
      playBeep(880, 150);
    }
  };

  const handleReset = () => {
    setIsRunning(false);
    lastTickRef.current = null;
    setElapsedMs(0);
  };

  const handleApplyCountdown = (h: number, m: number, s: number) => {
    const msValue = Math.max(0, (h * 3600 + m * 60 + s) * 1000);
    setInitialMs(msValue);
    setElapsedMs(0);
    setIsRunning(false);
  };

  const enterFullscreen = async () => {
    if (!containerRef.current) return;
    try {
      await containerRef.current.requestFullscreen();
      setIsFullscreen(true);
      setShowControls(true);
      if (hideControlsTimeoutRef.current) {
        clearTimeout(hideControlsTimeoutRef.current);
      }
      hideControlsTimeoutRef.current = window.setTimeout(() => {
        setShowControls(false);
      }, 3000);
    } catch (_e) {}
  };

  const exitFullscreen = async () => {
    try {
      if (document.fullscreenElement) await document.exitFullscreen();
      setIsFullscreen(false);
      setShowControls(true);
      if (hideControlsTimeoutRef.current) {
        clearTimeout(hideControlsTimeoutRef.current);
        hideControlsTimeoutRef.current = null;
      }
    } catch (_e) {}
  };

  useEffect(() => {
    const onChange = () => setIsFullscreen(Boolean(document.fullscreenElement));
    document.addEventListener("fullscreenchange", onChange);
    return () => document.removeEventListener("fullscreenchange", onChange);
  }, []);

  // Auto-hide controls on inactivity while in fullscreen
  useEffect(() => {
    if (!isFullscreen) return;

    const handleActivity = () => {
      setShowControls(true);
      if (hideControlsTimeoutRef.current) {
        clearTimeout(hideControlsTimeoutRef.current);
      }
      hideControlsTimeoutRef.current = window.setTimeout(() => {
        setShowControls(false);
      }, 3000);
    };

    const target = containerRef.current || document;
    target.addEventListener("mousemove", handleActivity);
    target.addEventListener(
      "touchstart",
      handleActivity as any,
      {
        passive: true,
      } as any
    );
    target.addEventListener("keydown", handleActivity as any);

    return () => {
      target.removeEventListener("mousemove", handleActivity);
      target.removeEventListener("touchstart", handleActivity as any);
      target.removeEventListener("keydown", handleActivity as any);
    };
  }, [isFullscreen]);

  // Inputs for countdown
  const presetSeconds = preset?.seconds;
  const [hInput, setHInput] = useState(
    presetSeconds != null ? Math.floor(presetSeconds / 3600) : 0,
  );
  const [mInput, setMInput] = useState(
    presetSeconds != null ? Math.floor((presetSeconds % 3600) / 60) : 5,
  );
  const [sInput, setSInput] = useState(
    presetSeconds != null ? presetSeconds % 60 : 0,
  );

  return (
    <ToolShell
      slug={slug}
      title={tc(`tools.${slug}.name` as never)}
      sub={tc(`tools.${slug}.description` as never)}
      controls={
        <>
          <Button variant="outline" onClick={handleReset}>
            <RotateCcw className="w-4 h-4" />
          </Button>
          <Button variant="outline" onClick={enterFullscreen}>
            <Maximize2 className="w-4 h-4" />
          </Button>
          <Button variant="ghost" onClick={() => playBeep(880, 600)} title={t("testSound")}>
            <Bell className="w-4 h-4" />
          </Button>
        </>
      }
      primaryAction={{
        label: isRunning ? t("pause") : t("start"),
        onClick: handleStartPause,
      }}
    >
      <div
        ref={containerRef}
        className={isFullscreen ? "fixed inset-0 z-50 bg-background" : ""}
      >
        {isFullscreen ? (
          <div className="h-full w-full flex flex-col">
            <div className="flex-1 flex items-center justify-center">
              <div dir="ltr" className="text-7xl md:text-[180px] font-mono flex items-center gap-6 select-none">
                <NumberFlow value={hh} format={{ minimumIntegerDigits: 2 }} />
                <span>:</span>
                <NumberFlow value={mm} format={{ minimumIntegerDigits: 2 }} />
                <span>:</span>
                <NumberFlow value={ss} format={{ minimumIntegerDigits: 2 }} />
              </div>
            </div>
            <div
              className={`pb-10 flex justify-center transition-opacity duration-300 ${
                showControls ? "opacity-100" : "opacity-0 pointer-events-none"
              }`}
            >
              <div className="flex items-center gap-4">
                <Button onClick={handleStartPause} className="min-w-32">
                  {isRunning ? (
                    <span className="inline-flex items-center gap-2">
                      <Pause className="w-5 h-5" /> {t("pause")}
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-2">
                      <Play className="w-5 h-5" /> {t("start")}
                    </span>
                  )}
                </Button>
                <Button variant="outline" onClick={handleReset}>
                  <RotateCcw className="w-5 h-5" />
                </Button>
                <Button variant="outline" onClick={exitFullscreen}>
                  <Minimize2 className="w-5 h-5" />
                </Button>
              </div>
            </div>
          </div>
        ) : (
          <div>
            <Tabs
              value={mode}
              onValueChange={(v) => {
                setMode(v as Mode);
                handleReset();
              }}
            >
              <TabsList>
                <TabsTrigger value="countdown">{t("countdown")}</TabsTrigger>
                <TabsTrigger value="stopwatch">{t("stopwatch")}</TabsTrigger>
              </TabsList>
              <TabsContent value="countdown" className="space-y-4">
                <SettingsCard className="max-w-md">
                  <div className="grid grid-cols-3 gap-3">
                    <OptionRow label={t("hours")}>
                      <Input
                        type="number"
                        min={0}
                        value={hInput}
                        onChange={(e) =>
                          setHInput(Math.max(0, Number(e.target.value)))
                        }
                      />
                    </OptionRow>
                    <OptionRow label={t("minutes")}>
                      <Input
                        type="number"
                        min={0}
                        value={mInput}
                        onChange={(e) =>
                          setMInput(Math.max(0, Number(e.target.value)))
                        }
                      />
                    </OptionRow>
                    <OptionRow label={t("seconds")}>
                      <Input
                        type="number"
                        min={0}
                        value={sInput}
                        onChange={(e) =>
                          setSInput(Math.max(0, Number(e.target.value)))
                        }
                      />
                    </OptionRow>
                  </div>
                  <div>
                    <Button
                      variant="outline"
                      onClick={() => handleApplyCountdown(hInput, mInput, sInput)}
                    >
                      {t("apply")}
                    </Button>
                  </div>
                </SettingsCard>
              </TabsContent>
              <TabsContent value="stopwatch">
                <p className="text-sm text-muted-foreground">
                  {t("countsUpFrom0")}
                </p>
              </TabsContent>
            </Tabs>

            <div className="mt-8 flex flex-col items-center gap-6">
              <div dir="ltr" className="text-6xl md:text-8xl font-mono flex items-center gap-4 select-none">
                <NumberFlow value={hh} format={{ minimumIntegerDigits: 2 }} />
                <span>:</span>
                <NumberFlow value={mm} format={{ minimumIntegerDigits: 2 }} />
                <span>:</span>
                <NumberFlow value={ss} format={{ minimumIntegerDigits: 2 }} />
              </div>
              {preset?.autoFullscreenHint && (
                <p className="text-xs text-muted-foreground text-center">
                  {t("fullscreenHint")}
                </p>
              )}
            </div>
          </div>
        )}
      </div>
    </ToolShell>
  );
}
