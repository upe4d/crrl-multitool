"use client";

import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import {
  ArrowRightLeft,
  Upload,
  Download,
  FileText,
} from "lucide-react";
import { useLocale, useTranslations } from "next-intl";
import { ToolShell } from "@/components/template/tool-shell";
import { CopyButton } from "@/components/shared/CopyButton";
import { TwoPane } from "@/components/shared/TwoPane";
import { downloadBlob } from "@/lib/download";
import { decodeBase64Bytes, encodeBase64Bytes, encodeBase64Text, readableBase64Text } from "@/lib/base64-codec";

type ConversionMode = "encode" | "decode";

export default function Base64Converter() {
  const t = useTranslations("Tools.Base64Converter");
  const tc = useTranslations("ToolsConfig");
  const isRu = useLocale() === "ru";
  const [input, setInput] = useState("");
  const [output, setOutput] = useState("");
  const [mode, setMode] = useState<ConversionMode>("encode");
  const [fileInfo, setFileInfo] = useState<{
    name: string;
    type: string;
  } | null>(null);
  const [fileBytes, setFileBytes] = useState<Uint8Array | null>(null);
  const [decodedBytes, setDecodedBytes] = useState<Uint8Array | null>(null);
  const [binaryOutput, setBinaryOutput] = useState(false);
  const fileLimit = 20 * 1024 * 1024;

  const showDecoded = (bytes: Uint8Array) => {
    const decoded = readableBase64Text(bytes);
    setDecodedBytes(bytes);
    setBinaryOutput(decoded === null);
    setOutput(decoded === null ? (isRu ? `Бинарные данные: ${bytes.length} байт` : `Binary data: ${bytes.length} bytes`) : decoded);
  };

  const changeMode = (next: ConversionMode) => {
    if (next === mode) return;
    setMode(next);
    try {
      if (next === "decode" && output && !binaryOutput) {
        setInput(output);
        setFileBytes(null);
        showDecoded(decodeBase64Bytes(output));
      } else if (next === "encode" && decodedBytes && fileInfo) {
        setInput("");
        setFileBytes(decodedBytes);
        setDecodedBytes(null);
        setBinaryOutput(false);
        setOutput(encodeBase64Bytes(decodedBytes));
      } else {
        setDecodedBytes(null);
        setFileBytes(null);
        setFileInfo(null);
        setBinaryOutput(false);
        setOutput(next === "encode" ? encodeBase64Text(input) : "");
      }
    } catch {
      setOutput("");
      setDecodedBytes(null);
      setBinaryOutput(false);
    }
  };

  const handleTextConversion = () => {
    if (!input && !fileBytes) {
      toast.error(t("enterSomeInput"));
      return;
    }

    try {
      if (mode === "encode") {
        setDecodedBytes(null);
        setBinaryOutput(false);
        setOutput(fileBytes ? encodeBase64Bytes(fileBytes) : encodeBase64Text(input));
      } else {
        showDecoded(decodeBase64Bytes(input));
      }
      toast.success(t("conversionSuccessful"));
    } catch (error) {
      setOutput("");
      setDecodedBytes(null);
      setBinaryOutput(false);
      toast.error(
        mode === "decode" ? t("invalidBase64") : t("conversionFailed")
      );
    }
  };

  const handleFileUpload = async (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = event.target.files?.[0];
    if (!file) return;

    try {
      if (file.size > fileLimit) throw new Error("size");
      const buffer = await file.arrayBuffer();
      if (mode === "encode") {
        const bytes = new Uint8Array(buffer);
        setInput("");
        setFileBytes(bytes);
        setDecodedBytes(null);
        setBinaryOutput(false);
        setOutput(encodeBase64Bytes(bytes));
        setFileInfo({ name: file.name, type: file.type });
      } else {
        const text = new TextDecoder("utf-8", { fatal: true }).decode(buffer);
        const bytes = decodeBase64Bytes(text);
        setInput(text);
        setFileBytes(null);
        setFileInfo(null);
        showDecoded(bytes);
      }
      toast.success(t("fileLoadedSuccessfully"));
    } catch (error) {
      setOutput("");
      setFileBytes(null);
      setDecodedBytes(null);
      setFileInfo(null);
      setBinaryOutput(false);
      toast.error(error instanceof Error && error.message === "size" ? (isRu ? "Файл должен быть не больше 20 МБ" : "The file must be 20 MB or less") : t("errorProcessingFile"));
    } finally {
      event.target.value = "";
    }
  };

  const handleDownload = () => {
    if (!output) {
      toast.error(t("noOutputToDownload"));
      return;
    }

    try {
      let blob: Blob;
      if (mode === "decode" && decodedBytes) {
        blob = new Blob([Uint8Array.from(decodedBytes)], { type: fileInfo?.type || (binaryOutput ? "application/octet-stream" : "text/plain;charset=utf-8") });
      } else {
        // Download as text file
        blob = new Blob([output], { type: "text/plain" });
      }

      const filename = mode === "decode"
        ? fileInfo ? `decoded_${fileInfo.name}` : binaryOutput ? "decoded.bin" : "decoded_text.txt"
        : fileInfo ? `encoded_${fileInfo.name}.txt` : "encoded_text.txt";
      downloadBlob(blob, filename);
      toast.success(t("fileDownloadedSuccessfully"));
    } catch (error) {
      toast.error(t("errorDownloadingFile"));
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const newInput = e.target.value;
    setInput(newInput);
    setFileBytes(null);
    setFileInfo(null);
    setDecodedBytes(null);
    setBinaryOutput(false);

    if (!newInput.trim()) {
      setOutput("");
      return;
    }

    try {
      if (mode === "encode") setOutput(encodeBase64Text(newInput));
      else showDecoded(decodeBase64Bytes(newInput));
    } catch (error) {
      // Don't show error toast for real-time conversion
      setOutput("");
    }
  };

  return (
    <ToolShell
      slug="base64"
      title={tc("tools.base64.name")}
      sub={tc("tools.base64.description")}
    >
      <div className="space-y-4">
        <div className="flex items-center justify-between">
            <Select
              value={mode}
              onValueChange={(v) => changeMode(v as ConversionMode)}
            >
              <SelectTrigger className="w-[220px]">
                <SelectValue placeholder={t("selectMode")} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="encode">{t("encodeToBase64")}</SelectItem>
                <SelectItem value="decode">{t("decodeFromBase64")}</SelectItem>
              </SelectContent>
            </Select>

            <div className="flex items-center space-x-2 rtl:space-x-reverse">
              <input
                type="file"
                onChange={handleFileUpload}
                className="hidden"
                id="file-upload"
              />
              <label htmlFor="file-upload">
                <Button variant="outline" asChild>
                  <span>
                    <Upload className="h-4 w-4 me-2" />
                    {t("uploadFile")}
                  </span>
                </Button>
              </label>
              <Button onClick={handleTextConversion}>
                <ArrowRightLeft className="h-4 w-4 me-2" />
                {t("convert")}
              </Button>
            </div>
          </div>

          <TwoPane
            start={
              <Card className="p-4">
                <Textarea
                  placeholder={mode === "encode" ? t("inputPlaceholderEncode") : t("inputPlaceholderDecode")}
                  className="min-h-[400px] font-mono text-left"
                  dir="ltr"
                  value={input}
                  onChange={handleInputChange}
                />
                {fileInfo && (
                  <div className="flex items-center mt-2 text-sm text-muted-foreground">
                    <FileText className="h-4 w-4 me-2" />
                    {fileInfo.name}
                  </div>
                )}
              </Card>
            }
            end={
              /* Bespoke output pane kept: the download reconstructs the ORIGINAL
                 binary file (atob → Uint8Array → Blob w/ fileInfo.type), which
                 OutputPanel's text-only downloadText cannot reproduce. */
              <Card className="p-4">
                <div className="relative">
                  <Textarea
                    placeholder={t("outputPlaceholder")}
                    className="min-h-[400px] font-mono text-left"
                    dir="ltr"
                    value={output}
                    readOnly
                  />
                  {output && (
                    <div className="absolute top-2 end-2 flex space-x-2 rtl:space-x-reverse">
                      {!binaryOutput && <CopyButton
                        text={output}
                        size="icon"
                        successMessage={t("copiedToClipboard")}
                        errorMessage={t("failedToCopy")}
                      />}
                      <Button size="icon" onClick={handleDownload} aria-label="Download">
                        <Download className="h-4 w-4" />
                      </Button>
                    </div>
                  )}
                </div>
              </Card>
            }
          />
        </div>
    </ToolShell>
  );
}
