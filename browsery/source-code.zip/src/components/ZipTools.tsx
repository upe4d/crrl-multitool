"use client";

import { useState, useCallback, useRef } from "react";
import { useLocale, useTranslations } from "next-intl";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import {
  Upload,
  File,
  Folder,
  FileArchive,
  FileOutput,
  Loader2,
  XCircle,
  Download,
} from "lucide-react";
import { toast } from "sonner";
import JSZip from "jszip";
import { ToolShell } from "@/components/template/tool-shell";
import { FileDropzone } from "@/components/shared/FileDropzone";
import { downloadBlob } from "@/lib/download";
import { formatBytes } from "@/lib/format";

interface FileEntry {
  name: string;
  size: number;
  type: string;
  path?: string;
  data?: Blob | File;
}

interface ArchiveEntry { name: string; index: number; size?: number }
interface ZipWorkerResult { ok: boolean; error?: string; entries?: ArchiveEntry[]; blob?: Blob }
const MAX_FILES = 500;
const MAX_CREATE_BYTES = 100 * 1024 * 1024;
const MAX_ZIP_BYTES = 50 * 1024 * 1024;
const ZIP_WORKER_TIMEOUT = 30000;

async function runZipWorker(file: File, mode: "list" | "extract", index?: number): Promise<ZipWorkerResult> {
  const buffer = await file.arrayBuffer();
  return new Promise((resolve, reject) => {
    const worker = new Worker(new URL("../workers/zip-worker.ts", import.meta.url));
    const timer = window.setTimeout(() => { worker.terminate(); reject(new Error("timeout")); }, ZIP_WORKER_TIMEOUT);
    worker.onmessage = (event: MessageEvent<ZipWorkerResult>) => {
      window.clearTimeout(timer);
      worker.terminate();
      if (event.data.ok) resolve(event.data);
      else reject(new Error(event.data.error || "archive"));
    };
    worker.onerror = () => {
      window.clearTimeout(timer);
      worker.terminate();
      reject(new Error("archive"));
    };
    worker.postMessage({ mode, buffer, index }, [buffer]);
  });
}

// ZIP entries are keyed by their path; without unique names JSZip silently
// replaces the previous file when two selected files share a filename.
function uniqueArchiveName(name: string, taken: Set<string>): string {
  const key = (value: string) => value.normalize("NFC").toLocaleLowerCase("en-US");
  if (!taken.has(key(name))) {
    taken.add(key(name));
    return name;
  }
  const extensionAt = name.lastIndexOf(".");
  const stem = extensionAt > 0 ? name.slice(0, extensionAt) : name;
  const extension = extensionAt > 0 ? name.slice(extensionAt) : "";
  let number = 2;
  let candidate = `${stem} (${number})${extension}`;
  while (taken.has(key(candidate))) candidate = `${stem} (${++number})${extension}`;
  taken.add(key(candidate));
  return candidate;
}

export default function ZipTool() {
  const t = useTranslations("Tools.ZipTools");
  const tc = useTranslations("ToolsConfig");
  const isRu = useLocale() === "ru";
  const [files, setFiles] = useState<FileEntry[]>([]);
  const filesRef = useRef<FileEntry[]>([]);
  const busyRef = useRef(false);
  const [zipContent, setZipContent] = useState<ArchiveEntry[]>([]);
  const [zipFile, setZipFile] = useState<File | null>(null);
  const [extractingIndex, setExtractingIndex] = useState<number | null>(null);
  const [loading, setLoading] = useState(false);
  const [progress, setProgress] = useState(0);

  const onDropCompress = useCallback(async (acceptedFiles: File[]) => {
    if (busyRef.current) return;
    try {
      const prev = filesRef.current;
      if (prev.length + acceptedFiles.length > MAX_FILES ||
          prev.reduce((sum, file) => sum + file.size, 0) + acceptedFiles.reduce((sum, file) => sum + file.size, 0) > MAX_CREATE_BYTES) {
        toast.error(isRu ? "Для создания ZIP выберите не более 500 файлов общим размером до 100 МБ." : "Select at most 500 files totalling 100 MB to create a ZIP.");
        return;
      }
      const taken = new Set(prev.map((file) => file.name.normalize("NFC").toLocaleLowerCase("en-US")));
      const next = [...prev, ...acceptedFiles.map((file) => ({
        name: uniqueArchiveName(file.name, taken), size: file.size, type: file.type, data: file,
      }))];
      filesRef.current = next;
      setFiles(next);
      toast.success(t("filesAddedSuccess"));
    } catch (error) {
      toast.error(t("errorAddingFiles"));
    }
  }, [isRu, t]);

  const zipError = useCallback((error: unknown) => {
    const code = error instanceof Error ? error.message : "archive";
    if (code === "entries") return isRu ? "В архиве больше 500 записей." : "The archive contains more than 500 entries.";
    if (code === "output") return isRu ? "Файл превышает лимит распаковки 50 МБ." : "The extracted file exceeds the 50 MB limit.";
    if (code === "timeout") return isRu ? "Обработка архива заняла слишком много времени." : "Archive processing timed out.";
    if (code === "integrity") return isRu ? "Файл повреждён: контрольная сумма или размер не совпадают." : "The file is damaged: checksum or size does not match.";
    if (code === "unsupported") return isRu ? "Этот тип сжатия, зашифрованный или многотомный архив либо ZIP64 не поддерживается." : "This compression type, encrypted archive, multi-volume archive or ZIP64 is not supported.";
    return isRu ? "Не удалось прочитать ZIP-файл." : "The ZIP file could not be read.";
  }, [isRu]);

  const onDropExtract = useCallback(async (acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (!file || busyRef.current) return;

    busyRef.current = true;
    setLoading(true);
    setProgress(0);
    setZipContent([]);
    setZipFile(null);
    try {
      if (file.size > MAX_ZIP_BYTES) throw new Error("input");
      const result = await runZipWorker(file, "list");
      setZipContent(result.entries || []);
      setZipFile(file);
      toast.success(result.entries?.length ? (isRu ? "Список файлов загружен" : "Archive contents loaded") : (isRu ? "Архив пуст" : "The archive is empty"));
    } catch (error) {
      toast.error(error instanceof Error && error.message === "input" ? (isRu ? "ZIP-файл должен быть не больше 50 МБ." : "The ZIP file must be 50 MB or less.") : zipError(error));
    } finally {
      busyRef.current = false;
      setLoading(false);
    }
  }, [loading, extractingIndex, isRu, zipError]);

  const extractAccept = {
    "application/zip": [".zip"],
    "application/x-zip-compressed": [".zip"],
  };

  const createZip = async () => {
    if (busyRef.current) return;
    if (files.length === 0) {
      toast.error(t("addFilesToCreate"));
      return;
    }

    busyRef.current = true;
    setLoading(true);
    setProgress(0);
    try {
      const zip = new JSZip();
      let processed = 0;

      for (const file of files) {
        if (file.data) {
          zip.file(file.name, file.data);
        }
        processed++;
        setProgress((processed / files.length) * 100);
      }

      const content = await zip.generateAsync(
        {
          type: "blob",
          compression: "DEFLATE",
          compressionOptions: { level: 9 },
        },
        (metadata) => {
          setProgress(metadata.percent);
        }
      );

      downloadBlob(content, "archive.zip");

      toast.success(t("zipCreatedSuccess"));
    } catch (error) {
      toast.error(t("errorCreatingZip"));
    } finally {
      busyRef.current = false;
      setLoading(false);
      setProgress(0);
    }
  };

  const downloadFile = async (file: ArchiveEntry) => {
    if (!zipFile || busyRef.current) return;
    busyRef.current = true;
    setExtractingIndex(file.index);
    try {
      const result = await runZipWorker(zipFile, "extract", file.index);
      if (!result.blob) throw new Error("archive");
      const filename = file.name.replace(/\\/g, "/").split("/").pop() || "file";
      downloadBlob(result.blob, filename);
    } catch (error) {
      toast.error(zipError(error));
    } finally {
      busyRef.current = false;
      setExtractingIndex(null);
    }
  };

  const removeFile = (index: number) => {
    const next = filesRef.current.filter((_, i) => i !== index);
    filesRef.current = next;
    setFiles(next);
  };

  return (
    <ToolShell
      slug="zip"
      title={tc("tools.zip.name")}
      sub={tc("tools.zip.description")}
    >
      <div className="space-y-6">
          <Tabs defaultValue="compress" className="space-y-6">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="compress">
                <FileArchive className="w-4 h-4 me-2" />
                {t("createZip")}
              </TabsTrigger>
              <TabsTrigger value="extract">
                <FileOutput className="w-4 h-4 me-2" />
                {t("extractZip")}
              </TabsTrigger>
            </TabsList>

            <TabsContent value="compress" className="space-y-4">
              <Card className="p-6">
                <FileDropzone
                  onFiles={onDropCompress}
                  multiple
                  className={({ isDragActive }) => `
                    min-h-32 rounded-lg border-2 border-dashed
                    flex flex-col items-center justify-center space-y-4 px-4 py-5
                    cursor-pointer transition-[border-color,background-color] duration-150
                    ${
                      isDragActive
                        ? "border-primary bg-primary/10 scale-[0.99]"
                        : "border-muted-foreground hover:border-primary hover:bg-primary/5"
                    }
                  `}
                >
                  <div className="flex items-center space-x-4">
                    <Upload className="w-8 h-8 text-muted-foreground" />
                    <div>
                      <h3 className="font-semibold">
                        {t("dropFilesCompress")}
                      </h3>
                      <p className="text-sm text-muted-foreground">
                        {t("addFilesDesc")}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {isRu ? "До 500 файлов, всего до 100 МБ" : "Up to 500 files, 100 MB total"}
                      </p>
                    </div>
                  </div>
                </FileDropzone>
              </Card>

              {files.length > 0 && (
                <Card>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>{t("tableFileName")}</TableHead>
                        <TableHead>{t("tableSize")}</TableHead>
                        <TableHead className="w-[100px]">{t("tableActions")}</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {files.map((file, index) => (
                        <TableRow key={index}>
                          <TableCell className="font-medium">
                            <div className="flex items-center space-x-2">
                              <File className="w-4 h-4" />
                              <span>{file.name}</span>
                            </div>
                          </TableCell>
                          <TableCell>{formatBytes(file.size)}</TableCell>
                          <TableCell>
                            <Button
                              variant="ghost"
                              size="icon"
                              aria-label={isRu ? `Убрать ${file.name}` : `Remove ${file.name}`}
                              onClick={() => removeFile(index)}
                            >
                              <XCircle className="w-4 h-4" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>

                  <div className="p-4 border-t space-y-4">
                    {loading && (
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>{t("creatingZip")}</span>
                          <span>{Math.round(progress)}%</span>
                        </div>
                        <Progress value={progress} />
                      </div>
                    )}

                    <Button
                      onClick={createZip}
                      disabled={loading}
                      className="w-full"
                    >
                      {loading ? (
                        <>
                          <Loader2 className="w-4 h-4 me-2 animate-spin" />
                          {t("creatingZipBtn")}
                        </>
                      ) : (
                        <>
                          <FileArchive className="w-4 h-4 me-2" />
                          {t("createZipBtn")}
                        </>
                      )}
                    </Button>
                  </div>
                </Card>
              )}
            </TabsContent>

            <TabsContent value="extract" className="space-y-4">
              <Card className="p-6">
                <FileDropzone
                  onFiles={onDropExtract}
                  accept={extractAccept}
                  className={({ isDragActive }) => `
                    min-h-32 rounded-lg border-2 border-dashed
                    flex flex-col items-center justify-center space-y-4 px-4 py-5
                    cursor-pointer transition-[border-color,background-color] duration-150
                    ${
                      isDragActive
                        ? "border-primary bg-primary/10 scale-[0.99]"
                        : "border-muted-foreground hover:border-primary hover:bg-primary/5"
                    }
                  `}
                >
                  <div className="flex items-center space-x-4">
                    <Folder className="w-8 h-8 text-muted-foreground" />
                    <div>
                      <h3 className="font-semibold">
                        {t("dropFileExtract")}
                      </h3>
                      <p className="text-sm text-muted-foreground">
                        {t("extractContents")}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {isRu ? "Архив до 50 МБ и 500 записей; каждый файл до 50 МБ" : "Archive up to 50 MB and 500 entries; each file up to 50 MB"}
                      </p>
                    </div>
                  </div>
                </FileDropzone>
              </Card>

              {loading && (
                <Card className="p-4">
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>{t("extractingZip")}</span>
                      <span>{Math.round(progress)}%</span>
                    </div>
                    <Progress value={progress} />
                  </div>
                </Card>
              )}

              {zipContent.length > 0 && (
                <Card>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>{t("tableFileName")}</TableHead>
                        <TableHead>{t("tableSize")}</TableHead>
                        <TableHead className="w-[100px]">{t("tableActions")}</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {zipContent.map((file, index) => (
                        <TableRow key={index}>
                          <TableCell className="font-medium">
                            <div className="flex items-center space-x-2">
                              <File className="w-4 h-4" />
                              <span>{file.name}</span>
                            </div>
                          </TableCell>
                            <TableCell>{typeof file.size === "number" ? formatBytes(file.size) : (isRu ? "Не определён" : "Unknown")}</TableCell>
                          <TableCell>
                            <Button
                              variant="ghost"
                              size="icon"
                                disabled={extractingIndex !== null || loading}
                                aria-label={isRu ? `Скачать ${file.name}` : `Download ${file.name}`}
                              onClick={() => downloadFile(file)}
                            >
                                {extractingIndex === file.index ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </Card>
              )}
            </TabsContent>
          </Tabs>
      </div>
    </ToolShell>
  );
}
