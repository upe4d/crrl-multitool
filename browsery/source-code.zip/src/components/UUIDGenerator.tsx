"use client";

import { useState } from "react";
import { useTranslations } from "next-intl";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Copy, Hash, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { ToolShell } from "@/components/template/tool-shell";
import { SettingsCard, OptionRow } from "@/components/shared/SettingsCard";
import { SliderRow } from "@/components/shared/SliderRow";
import { OutputPanel } from "@/components/shared/OutputPanel";
import { DNS_NAMESPACE, generateUuid, validateUuid, type UuidFormat } from "@/lib/uuid-generator";

interface UUIDFormat {
  value: UuidFormat;
  label: string;
  description: string;
}

export default function UUIDGenerator() {
  const t = useTranslations("Tools.UUIDGenerator");
  const tc = useTranslations("ToolsConfig");
  const [count, setCount] = useState<number>(1);
  const [format, setFormat] = useState<UuidFormat>("v4");
  const [generatedUUIDs, setGeneratedUUIDs] = useState<string[]>([]);
  const [customNamespace, setCustomNamespace] = useState<string>("");
  const [customName, setCustomName] = useState<string>("");

  const formats: UUIDFormat[] = [
    {
      value: "v4",
      label: t("formatV4Label"),
      description: t("formatV4Desc"),
    },
    {
      value: "v1",
      label: t("formatV1Label"),
      description: "На основе времени и случайного идентификатора узла",
    },
    {
      value: "v3",
      label: t("formatV3Label"),
      description: t("formatV3Desc"),
    },
    {
      value: "v5",
      label: t("formatV5Label"),
      description: t("formatV5Desc"),
    },
    {
      value: "nil",
      label: t("formatNilLabel"),
      description: t("formatNilDesc"),
    },
  ];

  const generateUUIDs = () => {
    try {
      const namespace = customNamespace.trim() || DNS_NAMESPACE;
      const uuids = Array.from({ length: count }, () => generateUuid(format, namespace, customName));
      setGeneratedUUIDs(uuids);
    } catch (error) {
      setGeneratedUUIDs([]);
      toast.error(error instanceof Error ? error.message : "Не удалось создать UUID");
    }
  };

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast.success(t("copiedToClipboard"));
    } catch (err) {
      toast.error(t("copyFailed"));
    }
  };

  const clearUUIDs = () => {
    setGeneratedUUIDs([]);
  };

  const getUUIDVersion = (uuid: string): string => {
    if (uuid === "00000000-0000-0000-0000-000000000000") return "Nil";
    const version = uuid.charAt(14);
    switch (version) {
      case "1":
        return "v1";
      case "3":
        return "v3";
      case "4":
        return "v4";
      case "5":
        return "v5";
      default:
        return "Unknown";
    }
  };

  return (
    <ToolShell
      slug="uuid-generator"
      title={tc("tools.uuid-generator.name")}
      sub={tc("tools.uuid-generator.description")}
      primaryAction={{ label: t("generateUUIDs"), onClick: generateUUIDs }}
    >
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Generator Controls */}
        <SettingsCard
          title={
            <span className="flex items-center gap-2">
              <Hash className="h-4 w-4" />
              {t("generatorSettingsTitle")}
            </span>
          }
          description={t("generatorSettingsDesc")}
        >
          <div className="space-y-2">
            <Label>{t("uuidVersionLabel")}</Label>
            <div className="grid grid-cols-1 gap-2">
              {formats.map((fmt) => (
                <button
                  key={fmt.value}
                  type="button"
                  aria-pressed={format === fmt.value}
                  className={`w-full text-left p-3 border rounded-lg cursor-pointer transition-colors ${
                    format === fmt.value
                      ? "border-primary bg-primary/5"
                      : "hover:bg-muted"
                  }`}
                  onClick={() => setFormat(fmt.value)}
                >
                  <div className="font-medium">{fmt.label}</div>
                  <div className="text-sm text-muted-foreground">
                    {fmt.description}
                  </div>
                </button>
              ))}
            </div>
          </div>

          <SliderRow
            label={t("uuidCountLabel", { count })}
            value={count}
            onChange={setCount}
            min={1}
            max={100}
            display=""
          />

          {(format === "v3" || format === "v5") && (
            <>
              <OptionRow label={t("namespaceLabel")} htmlFor="namespace" hint={t("namespaceHint")}>
                <Input
                  id="namespace"
                  value={customNamespace}
                  onChange={(e) => setCustomNamespace(e.target.value)}
                  placeholder={t("namespacePlaceholder")}
                  dir="ltr"
                />
              </OptionRow>
              <OptionRow label={t("nameLabel")} htmlFor="name">
                <Input
                  id="name"
                  value={customName}
                  onChange={(e) => setCustomName(e.target.value)}
                  placeholder={t("namePlaceholder")}
                />
              </OptionRow>
            </>
          )}
        </SettingsCard>

        {/* Generated UUIDs */}
        {generatedUUIDs.length > 0 ? (
          <div className="space-y-4">
            <OutputPanel
              title={t("generatedUUIDsTitle")}
              text={generatedUUIDs.join("\n")}
              filename={`uuids-${format}-${count}.txt`}
              copyLabel={t("copyAll")}
              copySuccessMessage={t("copiedToClipboard")}
              copyErrorMessage={t("copyFailed")}
            >
              <div>
                <p className="text-xs text-muted-foreground mb-2">
                  {t("uuidsGenerated", { count: generatedUUIDs.length })}
                </p>
                <pre className="font-mono text-sm min-h-[200px] whitespace-pre-wrap break-all" dir="ltr">
                  {generatedUUIDs.join("\n")}
                </pre>
              </div>
            </OutputPanel>

            <div className="flex flex-wrap gap-2">
              <Button onClick={clearUUIDs} variant="outline" size="sm">
                <Trash2 className="h-4 w-4 me-2" />
                {t("clear")}
              </Button>
            </div>

            <div className="space-y-2">
              <h4 className="font-semibold">{t("individualUUIDs")}</h4>
              <div className="space-y-2 max-h-60 overflow-y-auto">
                {generatedUUIDs.map((uuid, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between p-2 border rounded"
                  >
                    <div className="flex-1">
                      <div className="font-mono text-sm" dir="ltr">{uuid}</div>
                      <div className="flex gap-2 mt-1">
                        <Badge variant="outline" className="text-xs">
                          {getUUIDVersion(uuid)}
                        </Badge>
                        {validateUuid(uuid) ? (
                          <Badge
                            variant="default"
                            className="text-xs bg-green-500"
                          >
                            {t("valid")}
                          </Badge>
                        ) : (
                          <Badge variant="destructive" className="text-xs">
                            {t("invalid")}
                          </Badge>
                        )}
                      </div>
                    </div>
                    <Button
                      onClick={() => copyToClipboard(uuid)}
                      variant="ghost"
                      size="sm"
                    >
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        ) : (
          <SettingsCard title={t("generatedUUIDsTitle")} description={t("noUUIDsYet")}>
            <div className="text-center py-8 text-muted-foreground">
              <Hash className="h-16 w-16 mx-auto mb-4 opacity-50" />
              <p>{t("clickToGenerate")}</p>
            </div>
          </SettingsCard>
        )}
      </div>

      {/* UUID Information */}
      <SettingsCard title={t("uuidInformation")} className="mt-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h4 className="font-semibold mb-2">{t("uuidVersionsTitle")}</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><strong>v1:</strong> по времени со случайным идентификатором узла</li>
              <li><strong>v3:</strong> {t("versionV3").replace("v3: ", "")}</li>
              <li><strong>v4:</strong> {t("versionV4").replace("v4: ", "")}</li>
              <li><strong>v5:</strong> {t("versionV5").replace("v5: ", "")}</li>
              <li><strong>Nil:</strong> {t("versionNil").replace("Nil: ", "")}</li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold mb-2">{t("commonUseCasesTitle")}</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>• {t("useCase1")}</li>
              <li>• {t("useCase2")}</li>
              <li>• {t("useCase3")}</li>
              <li>• {t("useCase4")}</li>
              <li>• {t("useCase5")}</li>
            </ul>
          </div>
        </div>
      </SettingsCard>
    </ToolShell>
  );
}
