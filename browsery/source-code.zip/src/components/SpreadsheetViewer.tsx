"use client";

import { useState, useCallback, useRef } from "react";
import { useTranslations } from "next-intl";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table as TableIcon,
  Search,
  BarChart3,
  Download,
  ArrowUpDown,
  FileSpreadsheet,
  RefreshCw,
} from "lucide-react";
import { toast } from "sonner";
import { ToolShell } from "@/components/template/tool-shell";
import { FileDropzone } from "@/components/shared/FileDropzone";
import { downloadBlob } from "@/lib/download";
import { formatBytes } from "@/lib/format";
import Papa from "papaparse";
import * as XLSX from "xlsx";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

interface DataRow {
  [key: string]: string | number;
}

interface Column {
  key: string;
  type: "string" | "number";
  sortable: boolean;
}

export default function SpreadsheetViewer() {
  const t = useTranslations("Tools.SpreadsheetViewer");
  const tc = useTranslations("ToolsConfig");
  const [data, setData] = useState<DataRow[]>([]);
  const [fileName, setFileName] = useState<string | null>(null);
  const [fileSize, setFileSize] = useState(0);
  const [columns, setColumns] = useState<Column[]>([]);
  const [filteredData, setFilteredData] = useState<DataRow[]>([]);
  const [search, setSearch] = useState("");
  const [selectedColumn, setSelectedColumn] = useState<string | null>(null);
  const [showChart, setShowChart] = useState(false);
  const [sortConfig, setSortConfig] = useState<{
    key: string;
    direction: "asc" | "desc";
  } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (!file) return;

    try {
      let parsedData: DataRow[] = [];

      if (file.name.endsWith(".csv")) {
        // Parse CSV
        const text = await file.text();
        const result = Papa.parse(text, {
          header: true,
          dynamicTyping: true,
          skipEmptyLines: true,
        });
        parsedData = result.data as DataRow[];
      } else {
        // Parse Excel
        const arrayBuffer = await file.arrayBuffer();
        const workbook = XLSX.read(arrayBuffer);
        const worksheet = workbook.Sheets[workbook.SheetNames[0]];
        parsedData = XLSX.utils.sheet_to_json(worksheet);
      }

      // Detect column types
      const cols: Column[] = Object.keys(parsedData[0]).map((key) => ({
        key,
        type: typeof parsedData[0][key] === "number" ? "number" : "string",
        sortable: true,
      }));

      // Swapping files must clear every result derived from the previous
      // sheet — search text, sort order, and the selected chart column all
      // reference the old columns/rows and would otherwise silently persist
      // (or point at a column that no longer exists) over the new sheet.
      setColumns(cols);
      setData(parsedData);
      setFilteredData(parsedData);
      setFileName(file.name);
      setFileSize(file.size);
      setSelectedColumn(cols[0].key);
      setSearch("");
      setSortConfig(null);
      setShowChart(false);
      toast.success(t("fileLoadedSuccess"));
    } catch (error) {
      console.error(error);
      toast.error(t("errorLoadingFile"));
    }
  }, []);

  const dropzoneAccept = {
    "text/csv": [".csv"],
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": [
      ".xlsx",
    ],
    "application/vnd.ms-excel": [".xls"],
  };

  const handleSearch = (value: string) => {
    setSearch(value);
    if (!value.trim()) {
      setFilteredData(data);
      return;
    }

    const filtered = data.filter((row) =>
      Object.values(row).some((cell) =>
        String(cell).toLowerCase().includes(value.toLowerCase())
      )
    );
    setFilteredData(filtered);
  };

  const handleSort = (key: string) => {
    const column = columns.find((col) => col.key === key);
    if (!column?.sortable) return;

    const direction =
      sortConfig?.key === key && sortConfig.direction === "asc"
        ? "desc"
        : "asc";

    setSortConfig({ key, direction });

    const sorted = [...filteredData].sort((a, b) => {
      if (a[key] === b[key]) return 0;
      if (direction === "asc") {
        return a[key] < b[key] ? -1 : 1;
      } else {
        return a[key] > b[key] ? -1 : 1;
      }
    });

    setFilteredData(sorted);
  };

  const downloadCSV = () => {
    const csv = Papa.unparse(filteredData);
    downloadBlob(new Blob([csv], { type: "text/csv" }), "exported_data.csv");
  };

  const prepareChartData = () => {
    if (!selectedColumn) return [];

    const column = columns.find((col) => col.key === selectedColumn);
    if (column?.type !== "number") {
      // For string columns, count occurrences
      const counts: { [key: string]: number } = {};
      filteredData.forEach((row) => {
        const value = String(row[selectedColumn]);
        counts[value] = (counts[value] || 0) + 1;
      });
      return Object.entries(counts).map(([name, value]) => ({ name, value }));
    } else {
      // For number columns, use values directly
      return filteredData.map((row) => ({
        name: row[Object.keys(row)[0]], // Use first column as label
        value: row[selectedColumn],
      }));
    }
  };

  const chartData = prepareChartData();

  return (
    <ToolShell
      slug="spreadsheet"
      title={tc("tools.spreadsheet.name")}
      sub={tc("tools.spreadsheet.description")}
      width="wide"
      controls={
        data.length > 0 ? (
          <>
            <Button variant="outline" size="sm" onClick={() => setShowChart(!showChart)}>
              <BarChart3 className="w-4 h-4 me-2" />
              {showChart ? t("hideChart") : t("showChart")}
            </Button>
            <Button variant="outline" size="sm" onClick={downloadCSV}>
              <Download className="w-4 h-4 me-2" />
              {t("exportCsv")}
            </Button>
          </>
        ) : undefined
      }
    >
      <div className="space-y-6">
          {!data.length ? (
            <Card className="p-6">
              <FileDropzone
                onFiles={onDrop}
                accept={dropzoneAccept}
                className={({ isDragActive }) => `
                  h-48 rounded-lg border-2 border-dashed
                  flex flex-col items-center justify-center space-y-4 p-8
                  cursor-pointer transition-[border-color,background-color] duration-150
                  ${
                    isDragActive
                      ? "border-primary bg-primary/10 scale-[0.99]"
                      : "border-muted-foreground hover:border-primary hover:bg-primary/5"
                  }
                `}
              >
                <div className="flex flex-col items-center space-y-4">
                  <div className="p-4 rounded-full bg-primary/10">
                    <TableIcon className="w-8 h-8 text-primary" />
                  </div>
                  <div className="text-center">
                    <h3 className="text-lg font-semibold">
                      {t("dropHere")}
                    </h3>
                    <p className="text-sm text-muted-foreground mt-1">
                      {t("supportedFormats")}
                    </p>
                  </div>
                </div>
              </FileDropzone>
            </Card>
          ) : (
            <>
              <div className="flex items-center gap-4 p-4 bg-muted/30 rounded-lg border">
                <FileSpreadsheet className="w-8 h-8 text-primary shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="font-medium truncate">{fileName}</p>
                  <p className="text-sm text-muted-foreground" dir="ltr">
                    {formatBytes(fileSize)}
                  </p>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => fileInputRef.current?.click()}
                >
                  <RefreshCw className="w-4 h-4 me-1" />
                  {t("change")}
                </Button>
              </div>
              <input
                ref={fileInputRef}
                type="file"
                accept=".csv,.xlsx,.xls"
                className="hidden"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) onDrop([file]);
                  e.target.value = "";
                }}
              />
              <Card className="p-4">
                <div className="flex items-center space-x-4">
                  <div className="relative flex-1">
                    <Search className="absolute left-2 rtl:left-auto rtl:right-2 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder={t("searchPlaceholder")}
                      value={search}
                      onChange={(e) => handleSearch(e.target.value)}
                      className="pl-8 rtl:pl-3 rtl:pr-8"
                    />
                  </div>
                  {showChart && (
                    <Select
                      value={selectedColumn || ""}
                      onValueChange={setSelectedColumn}
                    >
                      <SelectTrigger className="w-[200px]">
                        <SelectValue placeholder={t("selectColumnChart")} />
                      </SelectTrigger>
                      <SelectContent>
                        {columns.map((column) => (
                          <SelectItem key={column.key} value={column.key}>
                            {column.key}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  )}
                </div>
              </Card>

              {showChart && selectedColumn && (
                <Card className="p-4">
                  <div className="h-[400px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={chartData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="name" />
                        <YAxis />
                        <Tooltip />
                        {/* content value: chart data-series fill, no --bt-chart token exists */}
                        <Bar dataKey="value" fill="#4f46e5" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </Card>
              )}

              <Card>
                <div className="max-h-[600px] overflow-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        {columns.map((column) => (
                          <TableHead
                            key={column.key}
                            className={
                              column.sortable
                                ? "cursor-pointer hover:bg-muted"
                                : ""
                            }
                            onClick={() => handleSort(column.key)}
                          >
                            <div className="flex items-center space-x-2">
                              <span>{column.key}</span>
                              {column.sortable && (
                                <ArrowUpDown className="w-4 h-4" />
                              )}
                            </div>
                          </TableHead>
                        ))}
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredData.map((row, index) => (
                        <TableRow key={index}>
                          {columns.map((column) => (
                            <TableCell key={column.key}>
                              {String(row[column.key])}
                            </TableCell>
                          ))}
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </Card>
            </>
          )}
      </div>
    </ToolShell>
  );
}
