"use client";

import { useState, useMemo, useCallback } from "react";
import { useTranslations } from "next-intl";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { RotateCcw } from "lucide-react";
import { ToolShell } from "@/components/template/tool-shell";
import { SettingsCard, OptionRow } from "@/components/shared/SettingsCard";
import { StatStrip } from "@/components/shared/StatStrip";
import { ModePicker } from "@/components/shared/ModePicker";

// ── BMI Categories ─────────────────────────────────────────────────────────────
// status color, no bt token: BMI severity needs 6 distinct categorical hues
// (underweight → normal → overweight → obese I/II/III); --bt-success/error only
// cover a 2-3-level semantic scale, so the raw hex + Tailwind palette classes
// below are genuine content (the category's identity), not decoration.

interface BmiCategory {
  labelKey: string;
  min: number;
  max: number;
  color: string;
  bgColor: string;
  textColor: string;
  badgeClass: string;
}

const CATEGORIES: BmiCategory[] = [
  {
    labelKey: "categoryUnderweight",
    min: 0,
    max: 18.5,
    color: "#3b82f6",
    bgColor: "bg-blue-500",
    textColor: "text-blue-700 dark:text-blue-400",
    badgeClass: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200",
  },
  {
    labelKey: "categoryNormal",
    min: 18.5,
    max: 25,
    color: "#22c55e",
    bgColor: "bg-green-500",
    textColor: "text-green-700 dark:text-green-400",
    badgeClass: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200",
  },
  {
    labelKey: "categoryOverweight",
    min: 25,
    max: 30,
    color: "#f59e0b",
    bgColor: "bg-amber-500",
    textColor: "text-amber-700 dark:text-amber-400",
    badgeClass: "bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-200",
  },
  {
    labelKey: "categoryObeseI",
    min: 30,
    max: 35,
    color: "#f97316",
    bgColor: "bg-orange-500",
    textColor: "text-orange-700 dark:text-orange-400",
    badgeClass: "bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200",
  },
  {
    labelKey: "categoryObeseII",
    min: 35,
    max: 40,
    color: "#ef4444",
    bgColor: "bg-red-500",
    textColor: "text-red-700 dark:text-red-400",
    badgeClass: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200",
  },
  {
    labelKey: "categoryObeseIII",
    min: 40,
    max: 60,
    color: "#7f1d1d",
    bgColor: "bg-red-900",
    textColor: "text-red-900 dark:text-red-300",
    badgeClass: "bg-red-200 text-red-900 dark:bg-red-950 dark:text-red-300",
  },
];

const GAUGE_MIN = 10;
const GAUGE_MAX = 50;

function getBmiCategory(bmi: number): BmiCategory {
  return CATEGORIES.find((c) => bmi >= c.min && bmi < c.max) ?? CATEGORIES[CATEGORIES.length - 1];
}

function bmiToGaugePercent(bmi: number): number {
  const pct = ((bmi - GAUGE_MIN) / (GAUGE_MAX - GAUGE_MIN)) * 100;
  return Math.max(0, Math.min(100, pct));
}

// ── Gauge segments (for the colour bar) ──────────────────────────────────────

const SEGMENTS = CATEGORIES.map((c) => {
  const start = Math.max(c.min, GAUGE_MIN);
  const end = Math.min(c.max, GAUGE_MAX);
  const width = ((end - start) / (GAUGE_MAX - GAUGE_MIN)) * 100;
  return { ...c, width: Math.max(0, width) };
});

// ── Component ─────────────────────────────────────────────────────────────────

type UnitSystem = "metric" | "imperial";

export default function BmiCalculator() {
  const t = useTranslations("Tools.BmiCalculator");
  const tc = useTranslations("ToolsConfig");
  const [unit, setUnit] = useState<UnitSystem>("metric");

  // Metric
  const [weightKg, setWeightKg] = useState("");
  const [heightCm, setHeightCm] = useState("");

  // Imperial
  const [weightLbs, setWeightLbs] = useState("");
  const [heightFt, setHeightFt] = useState("");
  const [heightIn, setHeightIn] = useState("");

  const handleClear = useCallback(() => {
    setWeightKg("");
    setHeightCm("");
    setWeightLbs("");
    setHeightFt("");
    setHeightIn("");
  }, []);

  const result = useMemo(() => {
    let kg = 0;
    let heightM = 0;

    if (unit === "metric") {
      kg = parseFloat(weightKg);
      heightM = parseFloat(heightCm) / 100;
    } else {
      kg = parseFloat(weightLbs) * 0.453592;
      const totalInches = parseFloat(heightFt || "0") * 12 + parseFloat(heightIn || "0");
      heightM = totalInches * 0.0254;
    }

    if (!kg || !heightM || kg <= 0 || heightM <= 0) return null;

    const bmi = kg / (heightM * heightM);
    const category = getBmiCategory(bmi);
    const gaugePos = bmiToGaugePercent(bmi);

    // Healthy weight range (BMI 18.5–24.9) for this height
    const minHealthyKg = 18.5 * heightM * heightM;
    const maxHealthyKg = 24.9 * heightM * heightM;

    const healthyMin =
      unit === "metric"
        ? `${minHealthyKg.toFixed(1)} kg`
        : `${(minHealthyKg / 0.453592).toFixed(1)} lbs`;
    const healthyMax =
      unit === "metric"
        ? `${maxHealthyKg.toFixed(1)} kg`
        : `${(maxHealthyKg / 0.453592).toFixed(1)} lbs`;

    return { bmi, category, gaugePos, healthyMin, healthyMax };
  }, [unit, weightKg, heightCm, weightLbs, heightFt, heightIn]);

  return (
    <ToolShell
      slug="bmi-calculator"
      title={tc("tools.bmi-calculator.name")}
      sub={tc("tools.bmi-calculator.description")}
      controls={
        <Button variant="outline" size="sm" onClick={handleClear}>
          <RotateCcw className="w-4 h-4 me-1.5" /> {t("reset")}
        </Button>
      }
    >
      <div className="space-y-6">
        {/* Unit toggle — a trivial two-option mode switch. */}
        <ModePicker
          aria-label={tc("tools.bmi-calculator.name")}
          value={unit}
          onChange={setUnit}
          options={[
            { value: "metric", label: t("metric") },
            { value: "imperial", label: t("imperial") },
          ]}
        />

        {/* Inputs */}
        <SettingsCard title={t("enterMeasurements")}>
          {unit === "metric" ? (
            <>
              <OptionRow label={t("weightKg")} htmlFor="weight-kg">
                <Input
                  id="weight-kg"
                  type="number"
                  min="1"
                  max="500"
                  step="0.1"
                  placeholder="e.g. 70"
                  value={weightKg}
                  onChange={(e) => setWeightKg(e.target.value)}
                  dir="ltr"
                />
              </OptionRow>
              <OptionRow label={t("heightCm")} htmlFor="height-cm">
                <Input
                  id="height-cm"
                  type="number"
                  min="50"
                  max="300"
                  step="0.1"
                  placeholder="e.g. 175"
                  value={heightCm}
                  onChange={(e) => setHeightCm(e.target.value)}
                  dir="ltr"
                />
              </OptionRow>
            </>
          ) : (
            <>
              <OptionRow label={t("weightLbs")} htmlFor="weight-lbs">
                <Input
                  id="weight-lbs"
                  type="number"
                  min="1"
                  max="1000"
                  step="0.1"
                  placeholder="e.g. 154"
                  value={weightLbs}
                  onChange={(e) => setWeightLbs(e.target.value)}
                  dir="ltr"
                />
              </OptionRow>
              {/* Feet+inches stay paired in one row — splitting into two
                  OptionRows would break the inline "ft / in" affordance. */}
              <OptionRow label={t("height")}>
                <div className="flex gap-2">
                  <Input
                    type="number"
                    min="0"
                    max="10"
                    placeholder={t("feet")}
                    value={heightFt}
                    onChange={(e) => setHeightFt(e.target.value)}
                    dir="ltr"
                  />
                  <Input
                    type="number"
                    min="0"
                    max="11"
                    placeholder={t("inches")}
                    value={heightIn}
                    onChange={(e) => setHeightIn(e.target.value)}
                    dir="ltr"
                  />
                </div>
              </OptionRow>
            </>
          )}
        </SettingsCard>

        {/* Result */}
        <SettingsCard title={t("yourBmiResult")}>
          {result ? (
            <>
              {/* BMI number + category badge stays bespoke — a hero readout
                  paired inline with the categorical status badge, not a
                  generic stat tile. */}
              <div className="flex items-center gap-4">
                <div className="text-5xl font-bold tabular-nums">{result.bmi.toFixed(1)}</div>
                <div>
                  <Badge className={result.category.badgeClass + " text-sm px-3 py-1"}>
                    {t(result.category.labelKey as Parameters<typeof t>[0])}
                  </Badge>
                </div>
              </div>

              {/* Gauge bar: embedded data visualization, stays bespoke —
                  no molecule fits a segmented gauge + position marker. */}
              <div className="space-y-1">
                <div className="relative h-5 rounded-full overflow-hidden flex">
                  {SEGMENTS.map((seg, idx) => (
                    <div
                      key={idx}
                      className={seg.bgColor}
                      style={{ width: `${seg.width}%` }}
                    />
                  ))}
                  {/* Marker */}
                  <div
                    className="absolute top-0 bottom-0 w-0.5 bg-white shadow-md transition-[left] duration-500"
                    style={{ left: `${result.gaugePos}%` }}
                  >
                    <div className="absolute -top-1 left-1/2 -translate-x-1/2 w-3 h-3 bg-white rounded-full border-2 border-border shadow" />
                  </div>
                </div>
                {/* Gauge labels */}
                <div className="flex justify-between text-xs text-muted-foreground px-0.5">
                  <span>{GAUGE_MIN}</span>
                  <span>18.5</span>
                  <span>25</span>
                  <span>30</span>
                  <span>35</span>
                  <span>40</span>
                  <span>{GAUGE_MAX}+</span>
                </div>
              </div>

              {/* Category legend: color-coded, stays bespoke alongside the
                  gauge above. */}
              <div className="grid grid-cols-2 gap-1.5 sm:grid-cols-3">
                {CATEGORIES.map((cat) => (
                  <div
                    key={cat.labelKey}
                    className={`flex items-center gap-1.5 text-xs rounded-md px-2 py-1 ${
                      cat.labelKey === result.category.labelKey ? cat.badgeClass : "text-muted-foreground"
                    }`}
                  >
                    <span
                      className="inline-block w-2 h-2 rounded-full flex-shrink-0"
                      style={{ backgroundColor: cat.color }}
                    />
                    <span className="font-medium">{t(cat.labelKey as Parameters<typeof t>[0])}</span>
                    <span className="ms-auto opacity-70">
                      {cat.min}
                      {cat.max < 60 ? `–${cat.max}` : "+"}
                    </span>
                  </div>
                ))}
              </div>

              {/* Healthy weight range — a single computed result. */}
              <StatStrip
                items={[
                  {
                    label: t("healthyWeightRange"),
                    value: <span dir="ltr">{result.healthyMin} &ndash; {result.healthyMax}</span>,
                    sub: "(BMI 18.5 – 24.9)",
                  },
                ]}
              />

              {/* Disclaimer */}
              <p className="text-xs text-muted-foreground border-t pt-3">
                {t("disclaimer")}
              </p>
            </>
          ) : (
            <div className="py-4 text-center text-muted-foreground">
              {t("enterWeightHeight")}
            </div>
          )}
        </SettingsCard>
      </div>
    </ToolShell>
  );
}
