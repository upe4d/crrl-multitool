"use client";

import { useState } from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Checkbox } from "@/components/ui/checkbox";
import { Copy, Dices, Hash, Coins, ListChecks, RefreshCw, ArrowRight } from "lucide-react";
import { toast } from "sonner";
import { useLocale, useTranslations } from "next-intl";
import { ToolShell } from "@/components/template/tool-shell";
import { SettingsCard, OptionRow } from "@/components/shared/SettingsCard";
import { MAX_RANDOM_COUNT, MAX_RANDOM_RANGE, pickRandomNumbers } from "@/lib/random-picker";
import { secureRandomInt } from "@/lib/secure-password";

// ── Randomness ────────────────────────────────────────────────────────────────
function randomInt(min: number, max: number): number {
  const range = max - min + 1;
  if (!Number.isSafeInteger(min) || !Number.isSafeInteger(max) || range < 1 || range > MAX_RANDOM_RANGE) throw new Error("range");
  return min + secureRandomInt(range);
}

type DieSize = 4 | 6 | 8 | 10 | 12 | 20;
const DIE_SIZES: DieSize[] = [4, 6, 8, 10, 12, 20];

export default function RandomPicker() {
  const t = useTranslations("Tools.RandomPicker");
  const tc = useTranslations("ToolsConfig");
  const isRu = useLocale() === "ru";

  // ── Random Number state ───────────────────────────────────────────────────
  const [min, setMin] = useState("1");
  const [max, setMax] = useState("100");
  const [count, setCount] = useState("1");
  const [allowDuplicates, setAllowDuplicates] = useState(true);
  const [numbers, setNumbers] = useState<number[]>([]);

  // ── Dice state ──────────────────────────────────────────────────────────────
  const [diceCount, setDiceCount] = useState("2");
  const [dieSides, setDieSides] = useState<DieSize>(6);
  const [diceResults, setDiceResults] = useState<number[]>([]);

  // ── Coin state ────────────────────────────────────────────────────────────
  const [coin, setCoin] = useState<"heads" | "tails" | null>(null);
  const [flipping, setFlipping] = useState(false);
  const [headsTally, setHeadsTally] = useState(0);
  const [tailsTally, setTailsTally] = useState(0);

  // ── Random Number ──────────────────────────────────────────────────────────
  const generateNumbers = () => {
    setNumbers([]);
    const lo = Number(min);
    const hi = Number(max);
    const n = Number(count);

    if (!min.trim() || !max.trim() || !Number.isSafeInteger(lo) || !Number.isSafeInteger(hi) || hi - lo + 1 > MAX_RANDOM_RANGE) {
      toast.error(t("errorInvalidRange"));
      return;
    }
    if (lo > hi) {
      toast.error(t("errorMinGreaterMax"));
      return;
    }
    if (!count.trim() || !Number.isSafeInteger(n) || n < 1 || n > MAX_RANDOM_COUNT) {
      toast.error(isRu ? "Количество должно быть от 1 до 10 000." : "Choose between 1 and 10,000 results.");
      return;
    }

    const rangeSize = hi - lo + 1;
    if (!allowDuplicates && n > rangeSize) {
      toast.error(t("errorCountTooLarge"));
      return;
    }

    try {
      setNumbers(pickRandomNumbers(lo, hi, n, !allowDuplicates));
    } catch {
      setNumbers([]);
      toast.error(isRu ? "Не удалось получить безопасные случайные числа." : "Secure random numbers are unavailable.");
    }
  };

  // ── Dice ──────────────────────────────────────────────────────────────────
  const rollDice = () => {
    const n = Math.floor(Number(diceCount));
    if (!Number.isFinite(n) || n < 1 || n > 100) {
      toast.error(t("errorInvalidDiceCount"));
      return;
    }
    try {
      const rolls: number[] = [];
      for (let i = 0; i < n; i++) rolls.push(randomInt(1, dieSides));
      setDiceResults(rolls);
    } catch {
      toast.error(isRu ? "Не удалось получить безопасные случайные числа." : "Secure random numbers are unavailable.");
    }
  };

  const diceTotal = diceResults.reduce((a, b) => a + b, 0);

  // ── Coin ────────────────────────────────────────────────────────────────────
  const flipCoin = () => {
    if (flipping) return;
    let result: "heads" | "tails";
    try {
      result = randomInt(0, 1) === 0 ? "heads" : "tails";
    } catch {
      toast.error(isRu ? "Не удалось получить безопасные случайные числа." : "Secure random numbers are unavailable.");
      return;
    }
    setFlipping(true);
    // Brief animation window before revealing the result.
    window.setTimeout(() => {
      setCoin(result);
      if (result === "heads") setHeadsTally((h) => h + 1);
      else setTailsTally((tl) => tl + 1);
      setFlipping(false);
    }, 600);
  };

  const resetCoin = () => {
    setCoin(null);
    setHeadsTally(0);
    setTailsTally(0);
  };

  // ── Copy helper ───────────────────────────────────────────────────────────
  const copyText = async (text: string) => {
    if (!text) return;
    try {
      await navigator.clipboard.writeText(text);
      toast.success(t("copied"));
    } catch {
      toast.error(t("copyFailed"));
    }
  };

  return (
    <ToolShell
      slug="random-picker"
      title={tc("tools.random-picker.name")}
      sub={tc("tools.random-picker.description")}
    >
      <div className="max-w-3xl mx-auto">
      <Tabs defaultValue="number" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="number">{t("tabNumber")}</TabsTrigger>
          <TabsTrigger value="dice">{t("tabDice")}</TabsTrigger>
          <TabsTrigger value="coin">{t("tabCoin")}</TabsTrigger>
          <TabsTrigger value="list">{t("tabList")}</TabsTrigger>
        </TabsList>

        {/* ── Random Number ── */}
        <TabsContent value="number" className="space-y-6">
          <SettingsCard
            title={
              <span className="flex items-center gap-2">
                <Hash className="h-4 w-4" />
                {t("numberTitle")}
              </span>
            }
            description={t("numberDesc")}
          >
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <OptionRow label={t("minLabel")} htmlFor="rp-min">
                  <Input
                    id="rp-min"
                    type="number"
                    inputMode="numeric"
                    dir="ltr"
                    value={min}
                    onChange={(e) => setMin(e.target.value)}
                  />
                </OptionRow>
                <OptionRow label={t("maxLabel")} htmlFor="rp-max">
                  <Input
                    id="rp-max"
                    type="number"
                    inputMode="numeric"
                    dir="ltr"
                    value={max}
                    onChange={(e) => setMax(e.target.value)}
                  />
                </OptionRow>
                <OptionRow label={t("countLabel")} htmlFor="rp-count">
                  <Input
                    id="rp-count"
                    type="number"
                    inputMode="numeric"
                    dir="ltr"
                    min={1}
                    max={MAX_RANDOM_COUNT}
                    value={count}
                    onChange={(e) => setCount(e.target.value)}
                  />
                </OptionRow>
              </div>

              <div className="flex items-center gap-2">
                <Checkbox
                  id="rp-dupes"
                  data-testid="rp-allow-duplicates"
                  checked={allowDuplicates}
                  onCheckedChange={(c) => setAllowDuplicates(Boolean(c))}
                />
                <Label htmlFor="rp-dupes" className="cursor-pointer">
                  {t("allowDuplicates")}
                </Label>
              </div>

              <p className="text-sm text-muted-foreground">{isRu ? "Целые числа; размер диапазона до 4 294 967 296, до 10 000 результатов." : "Whole numbers; range size up to 4,294,967,296, up to 10,000 results."}</p>
              <Button onClick={generateNumbers} className="w-full">
                <RefreshCw className="h-4 w-4 me-2" />
                {t("generate")}
              </Button>

              {numbers.length > 0 && (
                <div className="space-y-3">
                  <div
                    className="flex flex-wrap gap-2 justify-center p-4 border rounded-lg bg-muted/40"
                    dir="ltr"
                    data-testid="rp-number-results"
                  >
                    {numbers.map((num, i) => (
                      <span
                        key={`${num}-${i}`}
                        className="text-2xl font-bold text-primary px-3 py-1"
                      >
                        {num}
                      </span>
                    ))}
                  </div>
                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={() => copyText(numbers.join(", "))}
                  >
                    <Copy className="h-4 w-4 me-2" />
                    {t("copyResult")}
                  </Button>
                </div>
              )}
          </SettingsCard>
        </TabsContent>

        {/* ── Dice ── */}
        <TabsContent value="dice" className="space-y-6">
          <SettingsCard
            title={
              <span className="flex items-center gap-2">
                <Dices className="h-4 w-4" />
                {t("diceTitle")}
              </span>
            }
            description={t("diceDesc")}
          >
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <OptionRow label={t("diceCountLabel")} htmlFor="rp-dice-count">
                  <Input
                    id="rp-dice-count"
                    type="number"
                    inputMode="numeric"
                    dir="ltr"
                    min={1}
                    max={100}
                    value={diceCount}
                    onChange={(e) => setDiceCount(e.target.value)}
                  />
                </OptionRow>
                <OptionRow label={t("dieSidesLabel")}>
                  <div className="flex flex-wrap gap-2">
                    {DIE_SIZES.map((s) => (
                      <Button
                        key={s}
                        type="button"
                        size="sm"
                        variant={dieSides === s ? "default" : "outline"}
                        onClick={() => setDieSides(s)}
                      >
                        d{s}
                      </Button>
                    ))}
                  </div>
                </OptionRow>
              </div>

              <Button onClick={rollDice} className="w-full">
                <Dices className="h-4 w-4 me-2" />
                {t("roll")}
              </Button>

              {diceResults.length > 0 && (
                <div className="space-y-3">
                  <div
                    className="flex flex-wrap gap-3 justify-center p-4 border rounded-lg bg-muted/40"
                    dir="ltr"
                    data-testid="rp-dice-results"
                  >
                    {diceResults.map((d, i) => (
                      <span
                        key={`${d}-${i}`}
                        className="flex items-center justify-center h-12 w-12 rounded-lg border bg-background text-xl font-bold"
                        data-testid="rp-die"
                      >
                        {d}
                      </span>
                    ))}
                  </div>
                  <div
                    className="text-center text-lg font-semibold"
                    dir="ltr"
                  >
                    {t("total")}:{" "}
                    <span className="text-primary" data-testid="rp-dice-total">
                      {diceTotal}
                    </span>
                  </div>
                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={() =>
                      copyText(
                        `${diceResults.join(", ")} (${t("total")}: ${diceTotal})`
                      )
                    }
                  >
                    <Copy className="h-4 w-4 me-2" />
                    {t("copyResult")}
                  </Button>
                </div>
              )}
          </SettingsCard>
        </TabsContent>

        {/* ── Coin ── */}
        <TabsContent value="coin" className="space-y-6">
          <SettingsCard
            title={
              <span className="flex items-center gap-2">
                <Coins className="h-4 w-4" />
                {t("coinTitle")}
              </span>
            }
            description={t("coinDesc")}
          >
              <div className="flex flex-col items-center gap-4">
                <div
                  className={`flex items-center justify-center h-32 w-32 rounded-full border-4 border-primary/40 bg-muted text-2xl font-bold transition-transform duration-500 ${
                    flipping ? "animate-spin" : ""
                  }`}
                  data-testid="rp-coin"
                  aria-live="polite"
                >
                  {flipping
                    ? "…"
                    : coin === "heads"
                      ? t("heads")
                      : coin === "tails"
                        ? t("tails")
                        : t("coinPrompt")}
                </div>

                <Button
                  onClick={flipCoin}
                  disabled={flipping}
                  className="w-full"
                >
                  <Coins className="h-4 w-4 me-2" />
                  {t("flip")}
                </Button>

                <div className="grid grid-cols-2 gap-4 w-full">
                  <div className="text-center p-3 border rounded-lg">
                    <div
                      className="text-2xl font-bold text-primary"
                      data-testid="rp-heads-tally"
                    >
                      {headsTally}
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {t("heads")}
                    </div>
                  </div>
                  <div className="text-center p-3 border rounded-lg">
                    <div
                      className="text-2xl font-bold text-primary"
                      data-testid="rp-tails-tally"
                    >
                      {tailsTally}
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {t("tails")}
                    </div>
                  </div>
                </div>

                {(headsTally > 0 || tailsTally > 0) && (
                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={resetCoin}
                  >
                    <RefreshCw className="h-4 w-4 me-2" />
                    {t("resetTally")}
                  </Button>
                )}
              </div>
          </SettingsCard>
        </TabsContent>

        {/* ── List picker (now a pointer to Wheel of Names) ── */}
        <TabsContent value="list" className="space-y-6">
          <SettingsCard
            title={
              <span className="flex items-center gap-2">
                <ListChecks className="h-4 w-4" />
                {t("listTitle")}
              </span>
            }
            description={t("listPointerDesc")}
          >
              <Button asChild className="w-full">
                <Link href="/tools/wheel-of-names">
                  {t("listPointerCta")}
                  <ArrowRight className="h-4 w-4 ms-2" />
                </Link>
              </Button>
          </SettingsCard>
        </TabsContent>
      </Tabs>
      </div>
    </ToolShell>
  );
}
