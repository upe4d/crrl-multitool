"use client";

import { useState, useMemo, useCallback, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { RotateCcw, ArrowLeftRight } from "lucide-react";
import { useTranslations } from "next-intl";
import { ToolShell } from "@/components/template/tool-shell";
import { ModePicker } from "@/components/shared/ModePicker";
import { TwoPane } from "@/components/shared/TwoPane";
import { OutputPanel as SharedOutputPanel } from "@/components/shared/OutputPanel";
import { formatPercent } from "@/lib/format";

// content value: sample CSS source text loaded into the input on demand
const SAMPLE_CSS = `/* Main layout styles */
.container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 16px;
}

/* Navigation */
nav .menu-item {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 12px 16px;
  color: #333333;
  background-color: #ffffff;
  border-radius: 4px;
  transition: background-color 0.2s ease;
}

nav .menu-item:hover {
  background-color: #f5f5f5;
}

/* Typography */
h1, h2, h3 {
  font-family: "Inter", sans-serif;
  font-weight: 700;
  line-height: 1.2;
  margin-bottom: 16px;
}

@media (max-width: 768px) {
  .container {
    padding: 0 8px;
  }
}`;

// ── Minifier ──────────────────────────────────────────────────────────────────

function minifyCss(css: string): string {
  let result = "";
  let i = 0;
  const len = css.length;

  while (i < len) {
    // Multi-line comment
    if (css[i] === "/" && css[i + 1] === "*") {
      const end = css.indexOf("*/", i + 2);
      if (end === -1) {
        i = len;
      } else {
        i = end + 2;
      }
      continue;
    }

    // Single-line comment (not standard in CSS but often tolerated)
    if (css[i] === "/" && css[i + 1] === "/") {
      const nl = css.indexOf("\n", i + 2);
      i = nl === -1 ? len : nl + 1;
      continue;
    }

    // String literals — preserve content
    if (css[i] === '"' || css[i] === "'") {
      const quote = css[i];
      result += quote;
      i++;
      while (i < len && css[i] !== quote) {
        if (css[i] === "\\") {
          result += css[i];
          i++;
        }
        if (i < len) {
          result += css[i];
          i++;
        }
      }
      if (i < len) {
        result += css[i]; // closing quote
        i++;
      }
      continue;
    }

    // Whitespace collapsing
    if (/\s/.test(css[i])) {
      // Peek: if previous non-ws and next non-ws are chars that need a space between them, keep one
      const prev = result[result.length - 1];
      let j = i;
      while (j < len && /\s/.test(css[j])) j++;
      const next = css[j];
      // Remove space around structural chars
      const structural = new Set(["{", "}", ";", ":", ",", ">", "+", "~"]);
      if (prev && structural.has(prev)) {
        i = j;
        continue;
      }
      if (next && structural.has(next)) {
        i = j;
        continue;
      }
      // Otherwise keep a single space
      if (prev && next && prev !== " ") {
        result += " ";
      }
      i = j;
      continue;
    }

    // Remove space before structural chars already in result
    if (new Set(["{", "}", ";", ":", ","]).has(css[i])) {
      if (result.endsWith(" ")) {
        result = result.slice(0, -1);
      }
    }

    result += css[i];
    i++;
  }

  // Final cleanup
  result = result
    .replace(/\s*\{\s*/g, "{")
    .replace(/\s*\}\s*/g, "}")
    .replace(/\s*;\s*/g, ";")
    .replace(/\s*:\s*/g, ":")
    .replace(/\s*,\s*/g, ",")
    .replace(/;;+/g, ";")
    .replace(/;}/g, "}")
    .trim();

  return result;
}

// ── Beautifier ────────────────────────────────────────────────────────────────

function beautifyCss(css: string): string {
  // First strip comments and collapse whitespace
  const stripped = css
    .replace(/\/\*[\s\S]*?\*\//g, "")
    .replace(/\/\/[^\n]*/g, "")
    .replace(/\s+/g, " ")
    .trim();

  let result = "";
  let indent = 0;
  let i = 0;
  const len = stripped.length;

  const pad = () => "  ".repeat(indent);

  while (i < len) {
    // String literals
    if (stripped[i] === '"' || stripped[i] === "'") {
      const quote = stripped[i];
      let str = quote;
      i++;
      while (i < len && stripped[i] !== quote) {
        if (stripped[i] === "\\") {
          str += stripped[i];
          i++;
        }
        if (i < len) {
          str += stripped[i];
          i++;
        }
      }
      str += quote;
      i++;
      result += str;
      continue;
    }

    if (stripped[i] === "{") {
      result = result.trimEnd() + " {\n";
      indent++;
      i++;
      // skip whitespace after {
      while (i < len && stripped[i] === " ") i++;
      continue;
    }

    if (stripped[i] === "}") {
      indent = Math.max(0, indent - 1);
      result = result.trimEnd() + "\n" + pad() + "}\n\n";
      i++;
      while (i < len && stripped[i] === " ") i++;
      continue;
    }

    if (stripped[i] === ";") {
      result = result.trimEnd() + ";\n";
      i++;
      while (i < len && stripped[i] === " ") i++;
      if (i < len && stripped[i] !== "}") {
        result += pad();
      }
      continue;
    }

    if (stripped[i] === ",") {
      // Could be selector list or value list
      // Heuristic: if we're not inside {}, it's a selector separator
      result += ",\n" + pad();
      i++;
      while (i < len && stripped[i] === " ") i++;
      continue;
    }

    if (stripped[i] === " " && result.endsWith("\n")) {
      i++;
      continue;
    }

    // Start of a new declaration line
    if (!result || result.endsWith("\n")) {
      result += pad();
    }

    result += stripped[i];
    i++;
  }

  return result.replace(/\n{3,}/g, "\n\n").trim();
}

// ── Component ─────────────────────────────────────────────────────────────────

export default function CssMinifier() {
  const t = useTranslations("Tools.CssMinifier");
  const tCommon = useTranslations("Common");
  const tc = useTranslations("ToolsConfig");
  const [tab, setTab] = useState<"minify" | "beautify">("minify");
  const [input, setInput] = useState("");
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const [debouncedInput, setDebouncedInput] = useState("");

  useEffect(() => {
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => setDebouncedInput(input), 300);
    return () => {
      if (debounceRef.current) clearTimeout(debounceRef.current);
    };
  }, [input]);

  const output = useMemo(() => {
    if (!debouncedInput.trim()) return "";
    try {
      return tab === "minify" ? minifyCss(debouncedInput) : beautifyCss(debouncedInput);
    } catch {
      return "";
    }
  }, [debouncedInput, tab]);

  const stats = useMemo(() => {
    if (!debouncedInput.trim() || !output) return null;
    const before = new Blob([debouncedInput]).size;
    const after = new Blob([output]).size;
    const reductionRatio = before > 0 ? (before - after) / before : 0;
    return { before, after, reductionRatio };
  }, [debouncedInput, output]);

  const lineCount = useMemo(() => input.split("\n").length, [input]);

  const handleSwap = useCallback(() => {
    if (!output) return;
    setInput(output);
  }, [output]);

  const handleClear = useCallback(() => {
    setInput("");
  }, []);

  return (
    <ToolShell
      slug="css-minifier"
      title={tc("tools.css-minifier.name")}
      sub={tc("tools.css-minifier.description")}
    >
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <ModePicker
            aria-label={t("inputCss")}
            value={tab}
            onChange={(v) => setTab(v)}
            options={[
              { value: "minify", label: t("tabMinify") },
              { value: "beautify", label: t("tabBeautify") },
            ]}
          />
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={() => setInput(SAMPLE_CSS)}>
              {t("sampleCss")}
            </Button>
            <Button variant="outline" size="sm" onClick={handleSwap} disabled={!output}>
              <ArrowLeftRight className="w-4 h-4 me-1.5" /> {t("swap")}
            </Button>
            <Button variant="outline" size="sm" onClick={handleClear}>
              <RotateCcw className="w-4 h-4 me-1.5" /> {tCommon("clear")}
            </Button>
          </div>
        </div>

        {/* Stats bar */}
        {stats && (
          <div className="flex flex-wrap gap-2 items-center">
            <Badge variant="secondary">{t("before")} {stats.before} {t("bytes")}</Badge>
            <Badge variant="secondary">{t("after")} {stats.after} {t("bytes")}</Badge>
            {tab === "minify" && (
              <Badge
                className={
                  stats.reductionRatio > 0
                    ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200"
                    : "bg-muted text-muted-foreground"
                }
              >
                {stats.reductionRatio > 0 ? `-${formatPercent(stats.reductionRatio, 1)}` : t("noReduction")}
              </Badge>
            )}
          </div>
        )}

        <TwoPane
          start={
            <InputPanel
              value={input}
              onChange={setInput}
              lineCount={lineCount}
              placeholder={t("inputPlaceholder")}
              inputLabel={t("inputCss")}
              linesLabel={t("lines")}
              charsLabel={t("chars")}
            />
          }
          end={
            <SharedOutputPanel
              title={tab === "minify" ? t("minifiedCss") : t("beautifiedCss")}
              text={output}
              filename={`styles-${tab}.css`}
              mime="text/css"
              downloadSuccessMessage={t("downloaded")}
            >
              <textarea
                value={output}
                readOnly
                placeholder={tab === "minify" ? t("minifiedPlaceholder") : t("beautifiedPlaceholder")}
                className="w-full min-h-[50vh] font-mono text-sm resize-none bg-transparent outline-none leading-5 pt-2"
                aria-label="CSS output"
              />
            </SharedOutputPanel>
          }
        />
      </div>
    </ToolShell>
  );
}

// ── Sub-components ─────────────────────────────────────────────────────────────

function InputPanel({
  value,
  onChange,
  lineCount,
  placeholder,
  inputLabel,
  linesLabel,
  charsLabel,
}: {
  value: string;
  onChange: (v: string) => void;
  lineCount: number;
  placeholder: string;
  inputLabel: string;
  linesLabel: string;
  charsLabel: string;
}) {
  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-medium flex items-center justify-between">
          {inputLabel}
          <div className="flex gap-2">
            <Badge variant="secondary">{lineCount} {linesLabel}</Badge>
            <Badge variant="secondary">{value.length} {charsLabel}</Badge>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="relative flex">
          {/* Line numbers */}
          <div
            className="select-none text-right pr-3 pt-2 font-mono text-xs text-muted-foreground border-r mr-3 min-w-[2.5rem] leading-5"
            aria-hidden="true"
          >
            {Array.from({ length: Math.max(lineCount, 1) }, (_, i) => (
              <div key={i}>{i + 1}</div>
            ))}
          </div>
          <textarea
            value={value}
            onChange={(e) => onChange(e.target.value)}
            placeholder={placeholder}
            className="flex-1 min-h-[50vh] font-mono text-sm resize-none bg-transparent outline-none leading-5 pt-2 text-left rtl:text-left"
            spellCheck={false}
            aria-label="CSS input"
          />
        </div>
      </CardContent>
    </Card>
  );
}

