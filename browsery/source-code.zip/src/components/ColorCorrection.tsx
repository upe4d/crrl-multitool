"use client";

import { useState, useCallback, useRef, useEffect } from "react";
import { useTranslations } from "next-intl";
import { ToolShell } from "@/components/template/tool-shell";
import { FileDropzone } from "@/components/shared/FileDropzone";
import { downloadDataUrl } from "@/lib/download";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { SliderRow } from "@/components/shared/SliderRow";
import { Upload, Undo, Redo, Image as ImageIcon, RefreshCw } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface Adjustment {
  brightness: number;
  contrast: number;
  saturation: number;
  temperature: number;
  tint: number;
  vibrance: number;
  exposure: number;
  highlights: number;
  shadows: number;
}

const defaultAdjustments: Adjustment = {
  brightness: 100,
  contrast: 0,
  saturation: 100,
  temperature: 0,
  tint: 0,
  vibrance: 0,
  exposure: 0,
  highlights: 0,
  shadows: 0,
};

export default function ColorCorrection() {
  const t = useTranslations("Tools.ColorCorrection");
  const tCommon = useTranslations("Common");
  const tc = useTranslations("ToolsConfig");

  const [image, setImage] = useState<string | null>(null);
  const [fileName, setFileName] = useState<string | null>(null);
  const [adjustments, setAdjustments] =
    useState<Adjustment>(defaultAdjustments);
  const [history, setHistory] = useState<Adjustment[]>([defaultAdjustments]);
  const [historyIndex, setHistoryIndex] = useState(0);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        // Swapping the file must also clear every adjustment derived from the
        // previous image — otherwise the new photo loads under old
        // brightness/contrast/etc. sliders and a stale undo history.
        setImage(reader.result as string);
        setFileName(file.name);
        setAdjustments(defaultAdjustments);
        setHistory([defaultAdjustments]);
        setHistoryIndex(0);
      };
      reader.readAsDataURL(file);
    }
  }, []);

  const applyAdjustments = useCallback(() => {
    if (!image || !canvasRef.current) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const img = new Image();
    img.onload = () => {
      canvas.width = img.width;
      canvas.height = img.height;

      // Reset transform and clear
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // Draw original image
      ctx.drawImage(img, 0, 0);

      // Get image data
      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const data = imageData.data;

      // Apply adjustments
      for (let i = 0; i < data.length; i += 4) {
        // RGB values
        let r = data[i];
        let g = data[i + 1];
        let b = data[i + 2];

        // Brightness
        r *= adjustments.brightness / 100;
        g *= adjustments.brightness / 100;
        b *= adjustments.brightness / 100;

        // Contrast
        const factor =
          (259 * (adjustments.contrast + 255)) /
          (255 * (259 - adjustments.contrast));
        r = factor * (r - 128) + 128;
        g = factor * (g - 128) + 128;
        b = factor * (b - 128) + 128;

        // Saturation
        const gray = 0.2989 * r + 0.587 * g + 0.114 * b;
        r = gray + (r - gray) * (adjustments.saturation / 100);
        g = gray + (g - gray) * (adjustments.saturation / 100);
        b = gray + (b - gray) * (adjustments.saturation / 100);

        // Temperature
        r += adjustments.temperature;
        b -= adjustments.temperature;

        // Tint
        g += adjustments.tint;

        // Clamp values
        data[i] = Math.max(0, Math.min(255, r));
        data[i + 1] = Math.max(0, Math.min(255, g));
        data[i + 2] = Math.max(0, Math.min(255, b));
      }

      // Put the modified data back
      ctx.putImageData(imageData, 0, 0);
    };
    img.src = image;
  }, [image, adjustments]);

  useEffect(() => {
    applyAdjustments();
  }, [applyAdjustments]);

  const handleAdjustmentChange = (key: keyof Adjustment, value: number) => {
    const newAdjustments = { ...adjustments, [key]: value };
    setAdjustments(newAdjustments);

    // Add to history
    const newHistory = history.slice(0, historyIndex + 1);
    newHistory.push(newAdjustments);
    setHistory(newHistory);
    setHistoryIndex(newHistory.length - 1);
  };

  const handleUndo = () => {
    if (historyIndex > 0) {
      setHistoryIndex(historyIndex - 1);
      setAdjustments(history[historyIndex - 1]);
    }
  };

  const handleRedo = () => {
    if (historyIndex < history.length - 1) {
      setHistoryIndex(historyIndex + 1);
      setAdjustments(history[historyIndex + 1]);
    }
  };

  const handleDownload = () => {
    if (!canvasRef.current) return;
    downloadDataUrl(canvasRef.current.toDataURL(), "corrected-image.png");
  };

  const adjustmentControls = [
    { key: "brightness", label: t("brightness"), min: 0, max: 200, step: 1 },
    { key: "contrast", label: t("contrast"), min: -100, max: 100, step: 1 },
    { key: "saturation", label: t("saturation"), min: 0, max: 200, step: 1 },
    { key: "temperature", label: t("temperature"), min: -100, max: 100, step: 1 },
    { key: "tint", label: t("tint"), min: -100, max: 100, step: 1 },
    { key: "vibrance", label: t("vibrance"), min: -100, max: 100, step: 1 },
    { key: "exposure", label: t("exposure"), min: -100, max: 100, step: 1 },
    { key: "highlights", label: t("highlights"), min: -100, max: 100, step: 1 },
    { key: "shadows", label: t("shadows"), min: -100, max: 100, step: 1 },
  ];

  return (
    <ToolShell
      slug="color-correction"
      title={tc("tools.color-correction.name")}
      sub={tc("tools.color-correction.description")}
      primaryAction={{
        label: tCommon("download"),
        onClick: handleDownload,
        disabled: !image,
      }}
    >
      <div className="flex gap-6">
        <div className="flex-1 min-w-0 space-y-4">
          {image && (
            <div className="flex items-center gap-4 p-4 bg-muted/30 rounded-lg border">
              <ImageIcon className="w-8 h-8 text-primary shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="font-medium truncate">{fileName}</p>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => fileInputRef.current?.click()}
              >
                <RefreshCw className="w-4 h-4 me-1" />
                {t("change")}
              </Button>
            </div>
          )}
          <Card className="h-[28rem]">
            {!image ? (
              <FileDropzone
                onFiles={onDrop}
                accept={{
                  "image/*": [".png", ".jpg", ".jpeg"],
                }}
                multiple={false}
                className={({ isDragActive }) => `
                  h-full rounded-lg border-2 border-dashed
                  flex flex-col items-center justify-center space-y-4 p-8
                  cursor-pointer transition-colors
                  ${
                    isDragActive
                      ? "border-primary bg-primary/10"
                      : "border-muted-foreground"
                  }
                `}
              >
                <div className="w-12 h-12 sm:w-16 sm:h-16 rounded-full bg-primary/10 flex items-center justify-center">
                  <Upload className="w-6 h-6 sm:w-8 sm:h-8 text-primary" />
                </div>
                <div className="text-center">
                  <h3 className="text-lg font-semibold mb-1">
                    {t("dropImageHere")}
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    {t("supportedFormats")}
                  </p>
                </div>
              </FileDropzone>
            ) : (
              <div className="relative h-full overflow-hidden rounded-lg">
                <canvas
                  ref={canvasRef}
                  className="max-w-full max-h-full object-contain"
                />
              </div>
            )}
          </Card>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/png,image/jpeg"
            className="hidden"
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) onDrop([file]);
              e.target.value = "";
            }}
          />
        </div>

        <Card className="w-80 p-4 overflow-y-auto max-h-[28rem]">
          <div className="flex gap-2 items-center mb-4 justify-center">
            <Button
              variant="outline"
              onClick={handleUndo}
              disabled={historyIndex === 0}
              data-testid="cc-undo"
            >
              <Undo className="w-4 h-4" />
            </Button>
            <Button
              variant="outline"
              onClick={handleRedo}
              disabled={historyIndex === history.length - 1}
              data-testid="cc-redo"
            >
              <Redo className="w-4 h-4" />
            </Button>
          </div>
          <Tabs defaultValue="basic">
            <TabsList className="w-full">
              <TabsTrigger value="basic" className="flex-1">
                {t("tabBasic")}
              </TabsTrigger>
              <TabsTrigger value="advanced" className="flex-1">
                {t("tabAdvanced")}
              </TabsTrigger>
            </TabsList>
            <TabsContent value="basic" className="space-y-4">
              {adjustmentControls.slice(0, 5).map((control) => (
                <SliderRow
                  key={control.key}
                  label={control.label}
                  value={adjustments[control.key as keyof Adjustment]}
                  min={control.min}
                  max={control.max}
                  step={control.step}
                  onChange={(value) =>
                    handleAdjustmentChange(
                      control.key as keyof Adjustment,
                      value
                    )
                  }
                />
              ))}
            </TabsContent>
            <TabsContent value="advanced" className="space-y-4">
              {adjustmentControls.slice(5).map((control) => (
                <SliderRow
                  key={control.key}
                  label={control.label}
                  value={adjustments[control.key as keyof Adjustment]}
                  min={control.min}
                  max={control.max}
                  step={control.step}
                  onChange={(value) =>
                    handleAdjustmentChange(
                      control.key as keyof Adjustment,
                      value
                    )
                  }
                />
              ))}
            </TabsContent>
          </Tabs>
        </Card>
      </div>
    </ToolShell>
  );
}
