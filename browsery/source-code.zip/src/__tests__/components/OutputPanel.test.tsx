import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { OutputPanel } from "@/components/shared/OutputPanel";

describe("OutputPanel", () => {
  it("renders the text in a mono block and a title", () => {
    render(<OutputPanel title="Result" text="hello world" />);
    expect(screen.getByText("Result")).toBeInTheDocument();
    expect(screen.getByText("hello world")).toBeInTheDocument();
  });

  it("renders children as the body instead of the default mono block", () => {
    render(
      <OutputPanel text="raw payload">
        <span data-testid="structured">structured body</span>
      </OutputPanel>
    );
    expect(screen.getByTestId("structured")).toBeInTheDocument();
    expect(screen.queryByText("raw payload")).not.toBeInTheDocument();
  });

  it("disables the copy button when text is empty", () => {
    render(<OutputPanel text="" />);
    expect(screen.getByRole("button", { name: "Copy" })).toBeDisabled();
  });

  it("shows no download button unless filename is given", () => {
    render(<OutputPanel text="x" />);
    expect(screen.queryByRole("button", { name: "Download" })).not.toBeInTheDocument();
  });

  describe("with a filename", () => {
    let clicked: HTMLAnchorElement[] = [];
    beforeEach(() => {
      clicked = [];
      vi.spyOn(HTMLAnchorElement.prototype, "click").mockImplementation(function (
        this: HTMLAnchorElement
      ) {
        clicked.push(this);
      });
      vi.spyOn(URL, "createObjectURL").mockReturnValue("blob:mock");
      vi.spyOn(URL, "revokeObjectURL").mockImplementation(() => {});
    });
    afterEach(() => vi.restoreAllMocks());

    it("downloads text to the given filename on click", () => {
      render(<OutputPanel text="content" filename="out.txt" />);
      fireEvent.click(screen.getByRole("button", { name: "Download" }));
      expect(clicked).toHaveLength(1);
      expect(clicked[0].download).toBe("out.txt");
    });

    it("disables download when text is empty", () => {
      render(<OutputPanel text="" filename="out.txt" />);
      expect(screen.getByRole("button", { name: "Download" })).toBeDisabled();
    });

    it("does not toast on download when downloadSuccessMessage is omitted", async () => {
      const { toast } = await import("sonner");
      render(<OutputPanel text="content" filename="out.txt" />);
      fireEvent.click(screen.getByRole("button", { name: "Download" }));
      expect(toast.success).not.toHaveBeenCalled();
    });

    it("fires toast.success(downloadSuccessMessage) after the download click when provided", async () => {
      const { toast } = await import("sonner");
      render(
        <OutputPanel
          text="content"
          filename="converted.json"
          downloadSuccessMessage="Downloaded as .json"
        />
      );
      fireEvent.click(screen.getByRole("button", { name: "Download" }));
      expect(clicked).toHaveLength(1);
      expect(toast.success).toHaveBeenCalledWith("Downloaded as .json");
    });
  });

  describe("copy toast parity (API-friction #2)", () => {
    it("uses the default translated copy label/message when no overrides are given", async () => {
      const user = userEvent.setup();
      render(<OutputPanel text="hello" />);
      expect(screen.getByRole("button", { name: "Copy" })).toBeInTheDocument();

      const { toast } = await import("sonner");
      const writeText = vi.spyOn(navigator.clipboard, "writeText").mockResolvedValue(undefined);
      await user.click(screen.getByRole("button", { name: "Copy" }));
      await waitFor(() => expect(writeText).toHaveBeenCalledWith("hello"));
      expect(toast.success).toHaveBeenCalledWith("Copied!");
    });

    it("forwards copyLabel/copySuccessMessage/copyErrorMessage to the inner CopyButton", async () => {
      const user = userEvent.setup();
      render(
        <OutputPanel
          text="formatted"
          copyLabel="Copy JSON"
          copySuccessMessage="Copied to clipboard"
          copyErrorMessage="Failed to copy to clipboard"
        />
      );
      const button = screen.getByRole("button", { name: "Copy JSON" });
      expect(button).toBeInTheDocument();

      const { toast } = await import("sonner");
      vi.spyOn(navigator.clipboard, "writeText").mockResolvedValue(undefined);
      await user.click(button);
      await waitFor(() => expect(toast.success).toHaveBeenCalledWith("Copied to clipboard"));
    });

    it("surfaces the custom error message when copy fails", async () => {
      const user = userEvent.setup();
      render(<OutputPanel text="formatted" copyErrorMessage="Failed to copy to clipboard" />);

      const { toast } = await import("sonner");
      vi.spyOn(navigator.clipboard, "writeText").mockRejectedValue(new Error("denied"));
      await user.click(screen.getByRole("button", { name: "Copy" }));
      await waitFor(() =>
        expect(toast.error).toHaveBeenCalledWith("Failed to copy to clipboard")
      );
    });
  });
});
