import { Inflate, strFromU8 } from "fflate";

const MAX_ENTRIES = 500;
const MAX_OUTPUT_BYTES = 50 * 1024 * 1024;
const INPUT_CHUNK_BYTES = 256;
const MAX_ZIP_BYTES = 50 * 1024 * 1024;

type Request = { mode: "list" | "extract"; buffer: ArrayBuffer; index?: number };
type DirectoryEntry = { name: string; localOffset: number; dataStart: number; dataEnd: number; size: number; crc: number; method: number };
const CP437_HIGH = "\u00c7\u00fc\u00e9\u00e2\u00e4\u00e0\u00e5\u00e7\u00ea\u00eb\u00e8\u00ef\u00ee\u00ec\u00c4\u00c5\u00c9\u00e6\u00c6\u00f4\u00f6\u00f2\u00fb\u00f9\u00ff\u00d6\u00dc\u00a2\u00a3\u00a5\u20a7\u0192\u00e1\u00ed\u00f3\u00fa\u00f1\u00d1\u00aa\u00ba\u00bf\u2310\u00ac\u00bd\u00bc\u00a1\u00ab\u00bb\u2591\u2592\u2593\u2502\u2524\u2561\u2562\u2556\u2555\u2563\u2551\u2557\u255d\u255c\u255b\u2510\u2514\u2534\u252c\u251c\u2500\u253c\u255e\u255f\u255a\u2554\u2569\u2566\u2560\u2550\u256c\u2567\u2568\u2564\u2565\u2559\u2558\u2552\u2553\u256b\u256a\u2518\u250c\u2588\u2584\u258c\u2590\u2580\u03b1\u00df\u0393\u03c0\u03a3\u03c3\u00b5\u03c4\u03a6\u0398\u03a9\u03b4\u221e\u03c6\u03b5\u2229\u2261\u00b1\u2265\u2264\u2320\u2321\u00f7\u2248\u00b0\u2219\u00b7\u221a\u207f\u00b2\u25a0\u00a0";

function decodeLegacyName(bytes: Uint8Array): string {
  let result = "";
  for (const byte of bytes) result += byte < 128 ? String.fromCharCode(byte) : CP437_HIGH[byte - 128];
  return result;
}

// Check the real central-directory count: JSZip's name map can collapse
// duplicate entries and underestimate the number in a hostile archive.
function checkDirectory(bytes: Uint8Array): DirectoryEntry[] {
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const min = Math.max(0, bytes.length - 65557);
  for (let offset = bytes.length - 22; offset >= min; offset--) {
    if (view.getUint32(offset, true) !== 0x06054b50) continue;
    const commentLength = view.getUint16(offset + 20, true);
    if (offset + 22 + commentLength !== bytes.length) continue;
    const disk = view.getUint16(offset + 4, true);
    const directoryDisk = view.getUint16(offset + 6, true);
    const diskEntries = view.getUint16(offset + 8, true);
    const totalEntries = view.getUint16(offset + 10, true);
    if (disk || directoryDisk || diskEntries !== totalEntries || diskEntries === 0xffff || totalEntries === 0xffff) throw new Error("unsupported");
    if (totalEntries > MAX_ENTRIES) throw new Error("entries");
    const directorySize = view.getUint32(offset + 12, true);
    const directoryStart = view.getUint32(offset + 16, true);
    if (directorySize === 0xffffffff || directoryStart === 0xffffffff) throw new Error("unsupported");
    if (directoryStart + directorySize !== offset) throw new Error("archive");
    const entries: DirectoryEntry[] = [];
    let pos = directoryStart;
    const directoryEnd = directoryStart + directorySize;
    for (let i = 0; i < totalEntries; i++) {
      if (pos + 46 > directoryEnd || view.getUint32(pos, true) !== 0x02014b50) throw new Error("archive");
      const flags = view.getUint16(pos + 8, true);
      const method = view.getUint16(pos + 10, true);
      const crc = view.getUint32(pos + 16, true);
      const compressedSize = view.getUint32(pos + 20, true);
      const size = view.getUint32(pos + 24, true);
      const nameLength = view.getUint16(pos + 28, true);
      const extraLength = view.getUint16(pos + 30, true);
      const commentLength = view.getUint16(pos + 32, true);
      const entryDisk = view.getUint16(pos + 34, true);
      const localOffset = view.getUint32(pos + 42, true);
      const next = pos + 46 + nameLength + extraLength + commentLength;
      if (next > directoryEnd || !nameLength) throw new Error("archive");
      if ((flags & 1) || entryDisk || [compressedSize, size, localOffset].includes(0xffffffff)) throw new Error("unsupported");
      if (localOffset + 30 > directoryStart || view.getUint32(localOffset, true) !== 0x04034b50) throw new Error("archive");
      const localFlags = view.getUint16(localOffset + 6, true);
      const localMethod = view.getUint16(localOffset + 8, true);
      const localNameLength = view.getUint16(localOffset + 26, true);
      const localExtraLength = view.getUint16(localOffset + 28, true);
      const dataStart = localOffset + 30 + localNameLength + localExtraLength;
      const dataEnd = dataStart + compressedSize;
      if (localFlags !== flags || localMethod !== method || localNameLength !== nameLength || dataEnd > directoryStart) throw new Error("archive");
      if (!(flags & 8) && (view.getUint32(localOffset + 14, true) !== crc || view.getUint32(localOffset + 18, true) !== compressedSize || view.getUint32(localOffset + 22, true) !== size)) throw new Error("archive");
      for (let j = 0; j < nameLength; j++) if (bytes[pos + 46 + j] !== bytes[localOffset + 30 + j]) throw new Error("archive");
      const rawName = bytes.subarray(pos + 46, pos + 46 + nameLength);
      let name = flags & 0x800 ? strFromU8(rawName) : decodeLegacyName(rawName);
      // Info-ZIP Unicode path extra field supplies a UTF-8 name for legacy ZIPs.
      for (let extraPos = pos + 46 + nameLength; extraPos + 4 <= pos + 46 + nameLength + extraLength;) {
        const id = view.getUint16(extraPos, true);
        const length = view.getUint16(extraPos + 2, true);
        if (extraPos + 4 + length > pos + 46 + nameLength + extraLength) throw new Error("archive");
        if (id === 0x7075 && length >= 5 && bytes[extraPos + 4] === 1) {
          let nameCrc = 0xffffffff;
          for (const byte of rawName) nameCrc = (nameCrc >>> 8) ^ crcTable[(nameCrc ^ byte) & 0xff];
          if (((nameCrc ^ 0xffffffff) >>> 0) === view.getUint32(extraPos + 5, true)) name = strFromU8(bytes.subarray(extraPos + 9, extraPos + 4 + length));
        }
        extraPos += 4 + length;
      }
      entries.push({ name, localOffset, dataStart, dataEnd, size, crc, method });
      pos = next;
    }
    if (pos !== directoryEnd) throw new Error("archive");
    entries.sort((a, b) => a.localOffset - b.localOffset);
    for (let i = 1; i < entries.length; i++) if (entries[i - 1].dataEnd > entries[i].localOffset) throw new Error("archive");
    return entries;
  }
  throw new Error("archive");
}

const crcTable = Uint32Array.from({ length: 256 }, (_, byte) => {
  let crc = byte;
  for (let i = 0; i < 8; i++) crc = (crc >>> 1) ^ ((crc & 1) ? 0xedb88320 : 0);
  return crc >>> 0;
});

self.onmessage = ({ data }: MessageEvent<Request>) => {
  try {
    const bytes = new Uint8Array(data.buffer);
    if (bytes.length > MAX_ZIP_BYTES) throw new Error("input");
    const directory = checkDirectory(bytes);
    if (data.mode === "extract" && (data.index === undefined || !directory[data.index])) throw new Error("archive");
    if (data.mode === "extract" && directory[data.index!].size > MAX_OUTPUT_BYTES) throw new Error("output");
    const entries = directory.map((entry, index) => ({ name: entry.name, index, size: entry.size })).filter((entry) => !entry.name.endsWith("/"));
    if (data.mode === "list") {
      self.postMessage({ ok: true, entries });
      return;
    }
    const entry = directory[data.index!];
    if (entry.name.endsWith("/")) throw new Error("archive");
    if (entry.method !== 0 && entry.method !== 8) throw new Error("unsupported");
    const parts: Uint8Array<ArrayBuffer>[] = [];
    let total = 0;
    let finished = false;
    let crc = 0xffffffff;
    const accept = (chunk: Uint8Array, final: boolean) => {
      total += chunk.length;
      if (total > MAX_OUTPUT_BYTES) throw new Error("output");
      for (const byte of chunk) crc = (crc >>> 8) ^ crcTable[(crc ^ byte) & 0xff];
      if (chunk.length) parts.push(Uint8Array.from(chunk));
      if (final) {
        if (total !== entry.size || ((crc ^ 0xffffffff) >>> 0) !== entry.crc) throw new Error("integrity");
        finished = true;
      }
    };
    if (entry.method === 0) {
      for (let pos = entry.dataStart; pos < entry.dataEnd; pos += 4096) accept(bytes.subarray(pos, Math.min(pos + 4096, entry.dataEnd)), false);
      accept(new Uint8Array(), true);
    } else {
      const inflate = new Inflate(accept);
      for (let pos = entry.dataStart; pos < entry.dataEnd; pos += INPUT_CHUNK_BYTES) {
        inflate.push(bytes.subarray(pos, Math.min(pos + INPUT_CHUNK_BYTES, entry.dataEnd)), pos + INPUT_CHUNK_BYTES >= entry.dataEnd);
      }
    }
    if (!finished) throw new Error("archive");
    self.postMessage({ ok: true, blob: new Blob(parts, { type: "application/octet-stream" }) });
  } catch (error) {
    self.postMessage({ ok: false, error: error instanceof Error ? error.message : "archive" });
  }
};
