import { NIL, v1, v3, v4, v5, validate } from "uuid";

export type UuidFormat = "v1" | "v3" | "v4" | "v5" | "nil";
export const DNS_NAMESPACE = "6ba7b810-9dad-11d1-80b4-00c04fd430c8";

export function generateUuid(format: UuidFormat, namespace = DNS_NAMESPACE, name = ""): string {
  switch (format) {
    case "v1": return v1();
    case "v4": return v4();
    case "nil": return NIL;
    case "v3":
    case "v5": {
      const checked = namespace.trim();
      if (!validate(checked)) throw new Error("Некорректный UUID пространства имён");
      return format === "v3" ? v3(name, checked) : v5(name, checked);
    }
  }
}

export function validateUuid(value: string): boolean {
  return validate(value);
}
