import { configureModelHost, ModelLoadError } from "@/lib/model-host";
/**
 * Shared loader for in-browser Hugging Face models via Transformers.js
 * (@huggingface/transformers). Used by all on-device AI tools (transcribe,
 * summarize, translate, caption, upscale, segment, depth, sentiment, NER,
 * zero-shot, etc.).
 *
 * Design notes / hard-won lessons:
 * - Loaded via dynamic import so the (large) onnxruntime-web code stays out of
 *   the main bundle and only loads when an AI tool is actually used.
 * - Models are fetched from this site on first use and cached on-device by the
 *   browser; nothing is uploaded — on-brand for BrowseryTools' privacy promise.
 * - Pipelines are cached per task+model so repeated calls don't re-load.
 * - Для совместимых моделей WebGPU выбирается после проверки адаптера.
 */
import type {
  PipelineType,
  ProgressInfo,
  ProgressCallback,
} from "@huggingface/transformers";

type TransformersModule = typeof import("@huggingface/transformers");

let modulePromise: Promise<TransformersModule> | null = null;

async function getTransformers(): Promise<TransformersModule> {
  if (!modulePromise) {
    modulePromise = import("@huggingface/transformers").then((mod) => {
      // Модели и исполняемые файлы ONNX загружаются только с нашего сайта.
      configureModelHost(mod);
      return mod;
    });
  }
  return modulePromise;
}

/** True if the browser exposes WebGPU (Chrome/Edge, recent Safari). */
export function hasWebGPU(): boolean {
  return typeof navigator !== "undefined" && "gpu" in navigator;
}

/** Проверяем сам адаптер: наличие navigator.gpu не гарантирует его доступность. */
export async function preferredDevice(requireFp16 = false): Promise<"webgpu" | "wasm"> {
  if (!hasWebGPU()) return "wasm";
  try {
    const gpu = (navigator as Navigator & { gpu: { requestAdapter: () => Promise<{ features: { has: (name: string) => boolean } } | null> } }).gpu;
    const adapter = await gpu.requestAdapter();
    if (!adapter || (requireFp16 && !adapter.features.has("shader-f16"))) return "wasm";
    return "webgpu";
  } catch {
    return "wasm";
  }
}

// Для этих моделей в комплекте предусмотрены только квантованные файлы.
const quantizedOnlyModels = new Set([
  "Xenova/bert-base-NER",
  "Xenova/m2m100_418M",
  "Xenova/nli-deberta-v3-xsmall",
  "Xenova/distilbart-cnn-6-6",
  "Xenova/distilbert-base-uncased-finetuned-sst-2-english",
]);

export type LoadProgress = {
  /** 0-100 overall download progress across the model's files. */
  percent: number;
  status: string;
  file?: string;
};

const pipelineCache = new Map<string, Promise<unknown>>();

export type GetPipelineOptions = {
  /** "webgpu" | "wasm". Defaults to WebGPU when available, else WASM. */
  device?: "webgpu" | "wasm" | "auto";
  /** Quantization dtype, e.g. "q8", "fp16", "fp32". */
  dtype?: string;
  onProgress?: (p: LoadProgress) => void;
};

/**
 * Get (or lazily create + cache) a Transformers.js pipeline for a task+model.
 * Reports aggregate download progress via `onProgress`.
 */
export async function getPipeline<T = unknown>(
  task: PipelineType,
  model: string,
  options: GetPipelineOptions = {}
): Promise<T> {
  const quantizedOnly = quantizedOnlyModels.has(model);
  // Эти модели запускаем в WASM: в пакете отсутствуют fp32-веса для WebGPU.
  const device = quantizedOnly
    ? "wasm"
    : !options.device || options.device === "auto"
      ? await preferredDevice()
      : options.device;
  const dtype = quantizedOnly ? "q8" : options.dtype;
  const key = `${task}::${model}::${device}::${dtype ?? ""}`;

  if (!pipelineCache.has(key)) {
    const promise = (async () => {
      const { pipeline } = await getTransformers();
      // API сообщает процент отдельного файла, а не всего набора модели.
      const progress_callback: ProgressCallback = (info: ProgressInfo) => {
        if (!options.onProgress) return;
        if (info.status === "progress" && "file" in info) {
          if (!Number.isFinite(info.progress)) {
            options.onProgress({ percent: 0, status: "loading", file: info.file });
            return;
          }
          const percent = Math.max(0, Math.min(100, Math.round(info.progress ?? 0)));
          options.onProgress({ percent, status: "progress", file: info.file });
        } else if (info.status === "ready") {
          options.onProgress({ percent: 100, status: "ready" });
        } else {
          options.onProgress({ percent: 0, status: info.status });
        }
      };

      return pipeline(task, model, {
        device: device as "webgpu" | "wasm",
        ...(dtype ? { dtype: dtype as never } : {}),
        progress_callback,
      });
    })().catch((error) => {
      console.error("Ошибка загрузки модели:", error);
      throw new ModelLoadError();
    });
    pipelineCache.set(key, promise);
    // A failed network/model load must not poison every later retry in this tab.
    void promise.catch(() => {
      if (pipelineCache.get(key) === promise) pipelineCache.delete(key);
    });
  }

  return pipelineCache.get(key) as Promise<T>;
}
