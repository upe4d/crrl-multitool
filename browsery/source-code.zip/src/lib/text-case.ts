function words(text: string): string[] {
  return text.normalize("NFC")
    .replace(/([\p{Ll}\p{N}])(\p{Lu})/gu, "$1 $2")
    .replace(/(\p{Lu})(\p{Lu}\p{Ll})/gu, "$1 $2")
    .match(/[\p{L}\p{M}\p{N}]+/gu) || [];
}

function capitalize(text: string): string {
  const chars = Array.from(text.toLowerCase());
  return chars.length ? chars[0].toUpperCase() + chars.slice(1).join("") : "";
}

export const textCaseConverters = {
  uppercase: (text: string) => text.toUpperCase(),
  lowercase: (text: string) => text.toLowerCase(),
  titlecase: (text: string) => text.replace(/[\p{L}\p{N}][\p{L}\p{M}\p{N}'’]*/gu, capitalize),
  camelcase: (text: string) => words(text).map((word, i) => i ? capitalize(word) : word.toLowerCase()).join(""),
  pascalcase: (text: string) => words(text).map(capitalize).join(""),
  snakecase: (text: string) => words(text).map((word) => word.toLowerCase()).join("_"),
  kebabcase: (text: string) => words(text).map((word) => word.toLowerCase()).join("-"),
  constantcase: (text: string) => words(text).map((word) => word.toUpperCase()).join("_"),
  sentencecase: (text: string) => {
    const chars = Array.from(text.toLowerCase());
    return chars.length ? chars[0].toUpperCase() + chars.slice(1).join("") : "";
  },
  alternatingcase: (text: string) => Array.from(text, (char, index) => index % 2 ? char.toUpperCase() : char.toLowerCase()).join(""),
  inverse: (text: string) => Array.from(text, (char) => char === char.toUpperCase() ? char.toLowerCase() : char.toUpperCase()).join(""),
};
