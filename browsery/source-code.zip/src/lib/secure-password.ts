/** Uses rejection sampling to avoid modulo bias in character selection. */
export function secureRandomInt(max: number): number {
  if (!Number.isSafeInteger(max) || max < 1 || max > 0x100000000) throw new Error("Invalid random range");
  const source = globalThis.crypto;
  if (!source?.getRandomValues) throw new Error("Secure random generator is unavailable");
  const limit = 0x100000000 - (0x100000000 % max);
  const buffer = new Uint32Array(1);
  for (let attempt = 0; attempt < 128; attempt++) {
    source.getRandomValues(buffer);
    if (buffer[0] < limit) return buffer[0] % max;
  }
  throw new Error("Secure random generator failed");
}

/** Samples uniformly from passwords containing at least one character in each selected set. */
export function generateSecurePassword(length: number, classes: string[]): string {
  if (!Number.isSafeInteger(length) || length < 1 || length > 1024 || classes.length === 0 || classes.some((set) => !set)) throw new Error("Invalid password options");
  if (length < classes.length) throw new Error("Password length is too short for selected classes");
  const pool = [...new Set(classes.join(""))].join("");
  for (let attempt = 0; attempt < 4096; attempt++) {
    let result = "";
    for (let i = 0; i < length; i++) result += pool[secureRandomInt(pool.length)];
    if (classes.every((set) => [...result].some((character) => set.includes(character)))) return result;
  }
  throw new Error("Unable to generate a password with the selected classes");
}
