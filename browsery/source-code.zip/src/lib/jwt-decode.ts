export interface DecodedJwt {
  header: Record<string, any>;
  payload: Record<string, any>;
  signature: string;
  signatureVerified: false;
  isValid: boolean;
  errors: string[];
  expiration?: Date;
  issuedAt?: Date;
  notBefore?: Date;
}

function decodeObject(part: string): Record<string, any> {
  if (!part || !/^[A-Za-z0-9_-]+$/.test(part) || part.length % 4 === 1) throw new Error("Некорректное кодирование Base64URL");
  const padded = part.replace(/-/g, "+").replace(/_/g, "/") + "=".repeat((4 - part.length % 4) % 4);
  const binary = atob(padded);
  const bytes = Uint8Array.from(binary, (char) => char.charCodeAt(0));
  const parsed: unknown = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(bytes));
  if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) throw new Error("Ожидался JSON-объект");
  return parsed as Record<string, any>;
}

/** Parses structure and registered time claims only; never verifies a signature. */
export function decodeJwt(token: string, nowSeconds = Math.floor(Date.now() / 1000)): DecodedJwt {
  const result: DecodedJwt = { header: {}, payload: {}, signature: "", signatureVerified: false, isValid: true, errors: [] };
  const parts = token.split(".");
  if (parts.length !== 3) {
    result.errors.push("JWT должен состоять из трёх частей");
    result.isValid = false;
    return result;
  }
  result.signature = parts[2];
  if (!/^[A-Za-z0-9_-]*$/.test(parts[2])) result.errors.push("Некорректный формат подписи Base64URL");
  try { result.header = decodeObject(parts[0]); } catch { result.errors.push("Не удалось прочитать заголовок JWT"); }
  try { result.payload = decodeObject(parts[1]); } catch { result.errors.push("Не удалось прочитать данные JWT"); }

  for (const [claim, target] of [["exp", "expiration"], ["iat", "issuedAt"], ["nbf", "notBefore"]] as const) {
    if (!(claim in result.payload)) continue;
    const value = result.payload[claim];
    const date = new Date(typeof value === "number" ? value * 1000 : NaN);
    if (typeof value !== "number" || !Number.isFinite(value) || Number.isNaN(date.getTime())) {
      result.errors.push(`Поле ${claim} должно содержать корректное числовое время`);
      continue;
    }
    result[target] = date;
    if (claim === "exp" && value <= nowSeconds) result.errors.push("Срок действия токена истёк (exp)");
    if (claim === "nbf" && value > nowSeconds) result.errors.push("Токен ещё не вступил в действие (nbf)");
    if (claim === "iat" && value > nowSeconds + 60) result.errors.push("Время выдачи токена находится в будущем (iat)");
  }
  result.isValid = result.errors.length === 0;
  return result;
}
