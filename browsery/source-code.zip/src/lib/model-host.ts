/** Адреса файлов моделей принадлежат тому же сайту, что и приложение. */
export function localAssetUrl(path: string): string {
  if (typeof window === "undefined" || !path.startsWith("/") || path.startsWith("//")) {
    throw new Error("Некорректный путь к локальным файлам модели");
  }
  return new URL(path, window.location.origin).href;
}

export class ModelLoadError extends Error {
  constructor() {
    super("Не удалось загрузить модель с этого сайта. Проверьте подключение и наличие файлов модели на хостинге.");
    this.name = "ModelLoadError";
  }
}

export function modelErrorMessage(error: unknown, fallback: string): string {
  return error instanceof ModelLoadError ? error.message : fallback;
}

/** Transformers.js загружается только после запуска нужного инструмента. */
export function configureModelHost(mod: typeof import("@huggingface/transformers")): void {
  mod.env.allowLocalModels = false;
  mod.env.allowRemoteModels = true;
  mod.env.remoteHost = localAssetUrl("/models/huggingface/");
  mod.env.remotePathTemplate = "{model}/resolve/{revision}/";

  const wasm = mod.env.backends.onnx?.wasm;
  if (!wasm) throw new Error("Не найден обработчик ONNX WASM");
  const ua = navigator.userAgent;
  const safari = (navigator.vendor || "").includes("Apple") &&
    !/CriOS|FxiOS|EdgiOS|OPiOS|mercury|brave/i.test(ua) &&
    !ua.includes("Chrome") && !ua.includes("Android");
  const version = ua.match(/Version\/(\d+)/);
  const oldSafari = safari && version && Number(version[1]) < 26 && !("gpu" in navigator);
  const suffix = oldSafari ? "" : ".asyncify";
  const prefix = `/browsery/onnxruntime/ort-wasm-simd-threaded${suffix}`;
  wasm.wasmPaths = { mjs: localAssetUrl(`${prefix}.mjs`), wasm: localAssetUrl(`${prefix}.wasm`) };
}
