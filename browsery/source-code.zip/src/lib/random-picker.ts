import { secureRandomInt } from "./secure-password";

export const MAX_RANDOM_COUNT = 10000;
export const MAX_RANDOM_RANGE = 0x100000000;

/** Uniform sampling without allocating an array proportional to the range. */
export function pickRandomNumbers(
  min: number,
  max: number,
  count: number,
  unique: boolean,
  randomBelow: (max: number) => number = secureRandomInt,
): number[] {
  if (!Number.isSafeInteger(min) || !Number.isSafeInteger(max) || min > max) throw new Error("range");
  const range = max - min + 1;
  if (!Number.isSafeInteger(range) || range < 1 || range > MAX_RANDOM_RANGE) throw new Error("range");
  if (!Number.isSafeInteger(count) || count < 1 || count > MAX_RANDOM_COUNT) throw new Error("count");
  if (unique && count > range) throw new Error("unique");
  const result: number[] = [];
  const swapped = new Map<number, number>();
  for (let i = 0; i < count; i++) {
    const remaining = unique ? range - i : range;
    const index = randomBelow(remaining);
    if (!Number.isSafeInteger(index) || index < 0 || index >= remaining) throw new Error("random");
    const picked = unique ? (swapped.get(index) ?? index) : index;
    if (unique) {
      swapped.set(index, swapped.get(remaining - 1) ?? remaining - 1);
      swapped.delete(remaining - 1);
    }
    result.push(min + picked);
  }
  return result;
}
