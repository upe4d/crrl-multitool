import type { Metadata } from "next";
import { findToolByHref } from "./tools-config";
import ru from "../../messages/ru.json";
export function generateToolMetadata(href: string): Metadata { const t = findToolByHref(href); const slug = href.split("/").filter(Boolean).pop() ?? ""; const translated = (ru.ToolsConfig.tools as Record<string, {name?:string;description?:string}>)[slug]; return {title:translated?.name ?? t?.name ?? "Инструменты",description:translated?.description ?? t?.description ?? ""}; }
export function generatePageMetadata(title:string,description:string,_path:string=""):Metadata { return {title,description}; }
