/**
 * Airgap QR Data Streaming Protocol.
 * Each packet carries a CRC32 so a camera-decoded but damaged QR frame is
 * rejected instead of silently corrupting the reconstructed file.
 */

export interface AirgapMeta {
  fileId: string;
  fileName: string;
  fileSize: number;
  compressedSize: number;
  totalChunks: number;
  chunkSize: number;
  checksum: string;
}

export const MAX_AIRGAP_FILE_SIZE = 50 * 1024 * 1024;
export const MAX_AIRGAP_PACKETS = 250000;

export interface AirgapPacket {
  version: "AG2";
  fileId: string;
  chunkIdx: number;
  totalChunks: number;
  fileSize: number;
  fileName: string;
  dataBase64: string;
}

export function crc32(bytes: Uint8Array): string {
  let crc = 0xffffffff;
  for (const byte of bytes) {
    crc ^= byte;
    for (let bit = 0; bit < 8; bit++) {
      crc = (crc >>> 1) ^ (crc & 1 ? 0xedb88320 : 0);
    }
  }
  return ((crc ^ 0xffffffff) >>> 0).toString(16).padStart(8, "0");
}

export async function compressBytes(data: Uint8Array): Promise<Uint8Array> {
  if (typeof CompressionStream === "undefined") return data;
  try {
    const stream = new Response(
      new Blob([new Uint8Array(data).buffer]).stream().pipeThrough(new CompressionStream("gzip")),
    );
    return new Uint8Array(await stream.arrayBuffer());
  } catch (err) {
    console.warn("Compression failed, using uncompressed:", err);
    return data;
  }
}

export async function decompressBytes(data: Uint8Array, maxOutputSize = Number.MAX_SAFE_INTEGER): Promise<Uint8Array> {
  if (typeof DecompressionStream === "undefined") throw new Error("Распаковка GZIP недоступна в этом браузере");
  try {
    const reader = new Blob([new Uint8Array(data).buffer]).stream().pipeThrough(new DecompressionStream("gzip")).getReader();
    const chunks: Uint8Array[] = [];
    let size = 0;
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      size += value.length;
      if (size > maxOutputSize) { await reader.cancel(); throw new Error("Превышен ожидаемый размер"); }
      chunks.push(value);
    }
    const result = new Uint8Array(size);
    let offset = 0;
    for (const chunk of chunks) { result.set(chunk, offset); offset += chunk.length; }
    return result;
  } catch (err) {
    throw new Error("Не удалось распаковать полученный файл");
  }
}

export async function computeChecksum(data: Uint8Array): Promise<string> {
  if (typeof crypto === "undefined" || !crypto.subtle) throw new Error("Для проверки SHA-256 нужен WebCrypto: откройте приложение по HTTPS или на localhost");
  const hashBuffer = await crypto.subtle.digest("SHA-256", new Uint8Array(data).buffer);
  return Array.from(new Uint8Array(hashBuffer))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

export async function verifyAirgapPayload(data: Uint8Array, meta: { fileSize: number; isCompressed: boolean; checksum: string }): Promise<Uint8Array> {
  if (!Number.isSafeInteger(meta.fileSize) || meta.fileSize < 0 || meta.fileSize > MAX_AIRGAP_FILE_SIZE || !/^[0-9a-f]{64}$/i.test(meta.checksum)) {
    throw new Error("Несовместимый формат контрольной суммы. Обновите приложение на обоих устройствах.");
  }
  const bytes = meta.isCompressed ? await decompressBytes(data, meta.fileSize) : data;
  if (bytes.length !== meta.fileSize || (await computeChecksum(bytes)).toLowerCase() !== meta.checksum.toLowerCase()) {
    throw new Error("Проверка целостности файла не пройдена. Начните передачу заново.");
  }
  return bytes;
}

export function bytesToBase64(bytes: Uint8Array): string {
  let binary = "";
  for (let i = 0; i < bytes.length; i += 0x8000) {
    binary += String.fromCharCode.apply(null, Array.from(bytes.subarray(i, i + 0x8000)));
  }
  return btoa(binary);
}

export function base64ToBytes(base64: string): Uint8Array {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

export async function prepareFileForAirgap(
  file: File,
  chunkSize: number = 450,
): Promise<{ meta: AirgapMeta; packets: string[] }> {
  if (!Number.isSafeInteger(chunkSize) || chunkSize < 1 || chunkSize > 1000) throw new Error("Некорректный размер QR-пакета");
  if (file.size > MAX_AIRGAP_FILE_SIZE) throw new Error("Максимальный размер файла для передачи — 50 МБ");
  const rawBytes = new Uint8Array(await file.arrayBuffer());
  const checksum = await computeChecksum(rawBytes);
  const compressed = await compressBytes(rawBytes);
  const isCompressed = compressed.length < rawBytes.length;
  const payload = isCompressed ? compressed : rawBytes;
  const totalChunks = Math.max(1, Math.ceil(payload.length / chunkSize));
  if (totalChunks > MAX_AIRGAP_PACKETS) throw new Error("Слишком много QR-пакетов: увеличьте размер пакета или выберите файл меньшего размера");
  const fileId = Array.from(crypto.getRandomValues(new Uint8Array(8)), (byte) => byte.toString(16).padStart(2, "0")).join("");
  const meta: AirgapMeta = {
    fileId,
    fileName: file.name,
    fileSize: file.size,
    compressedSize: payload.length,
    totalChunks,
    chunkSize,
    checksum,
  };
  const safeFileName = encodeURIComponent(file.name);
  const packets: string[] = [];
  for (let i = 0; i < totalChunks; i++) {
    const chunk = payload.subarray(i * chunkSize, Math.min((i + 1) * chunkSize, payload.length));
    const flags = isCompressed ? "z" : "r";
    // AG2 distinguishes the full SHA-256 format from legacy eight-character hashes.
    packets.push(
      `AG2|${fileId}|${i}|${totalChunks}|${file.size}|${safeFileName}|${flags}|${checksum}|${crc32(chunk)}|${bytesToBase64(chunk)}`,
    );
  }
  return { meta, packets };
}

export interface ParsedPacket {
  version: "AG2";
  fileId: string;
  chunkIdx: number;
  totalChunks: number;
  fileSize: number;
  fileName: string;
  isCompressed: boolean;
  checksum: string;
  data: Uint8Array;
}

export function parseAirgapPacket(raw: string): ParsedPacket | null {
  if (!raw.startsWith("AG2|")) return null;
  const parts = raw.split("|");
  // Reject the old 8-field packet format; it had no corruption detection.
  if (parts.length !== 10) return null;
  const [, fileId, chunkIdxStr, totalChunksStr, fileSizeStr, safeFileName, flags, checksum, expectedCrc, b64] = parts;
  if (![chunkIdxStr, totalChunksStr, fileSizeStr].every((value) => /^(0|[1-9]\d*)$/.test(value))) return null;
  const chunkIdx = Number(chunkIdxStr);
  const totalChunks = Number(totalChunksStr);
  const fileSize = Number(fileSizeStr);
  if (!Number.isSafeInteger(chunkIdx) || !Number.isSafeInteger(totalChunks) || totalChunks < 1 || totalChunks > MAX_AIRGAP_PACKETS ||
      chunkIdx >= totalChunks || !Number.isSafeInteger(fileSize) || fileSize > MAX_AIRGAP_FILE_SIZE || !/^[0-9a-f]{16}$/i.test(fileId) ||
      !/^[0-9a-f]{64}$/i.test(checksum) || !/^[0-9a-f]{8}$/i.test(expectedCrc) ||
      !["z", "r"].includes(flags) || b64.length > 1400 || !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(b64)) return null;
  try {
    const data = base64ToBytes(b64);
    if (data.length > 1000 || data.length > fileSize || totalChunks > Math.max(1, fileSize) || (fileSize > 0 && data.length === 0)) return null;
    if (crc32(data).toLowerCase() !== expectedCrc.toLowerCase()) return null;
    return {
      version: "AG2", fileId, chunkIdx, totalChunks, fileSize,
      fileName: decodeURIComponent(safeFileName), isCompressed: flags === "z", checksum, data,
    };
  } catch {
    return null;
  }
}
