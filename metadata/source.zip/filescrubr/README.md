# File Scrubr

**[Live Website](https://filescrubr.com)**

File Scrubr is a free, privacy-first tool for inspecting, editing, and deleting file metadata in your browser. Drop a file on the page — it is read with the File API, parsed locally, and downloaded from a blob URL. Nothing is uploaded. There is no server-side processing and no analytics.

It is a static [Astro](https://astro.build) site hosted on Cloudflare Pages (no Functions). One file at a time, 50 MB maximum (20 MB on devices with under 4 GB of RAM). Password-protected and damaged files cannot be opened.

Supported formats: JPEG, PNG, WebP, GIF, SVG, MP3, WAV, M4A, FLAC, DOCX, XLSX, PPTX, CSV, and PDF. HEIC tags can be viewed when the browser can parse them; rewriting is not supported. Legacy `.doc`, `.xls`, and `.ppt` are not supported — save as `.docx`, `.xlsx`, or `.pptx` and drop again.

## Architecture

```
src/pages            Astro shells (home, about, 404, robots/llms text)
src/layouts          Document chrome, SEO, nav, footer
src/lib/scrub        Metadata engine (detect → registry → format handlers → engine)
src/workers          Web Worker around engine.handleJob
src/scripts/scrub    Vanilla UI (dropzone, table, download, session)
```

Format support is a strategy map: each format module exports a `FormatHandler` (`parse` / optional `strip` / `edit`). [`src/lib/scrub/registry.ts`](src/lib/scrub/registry.ts) looks up the handler. The UI never imports parsers directly; it talks to [`ScrubClient`](src/lib/scrub/client.ts), which prefers a worker and falls back to the main thread.

## Packages

Runtime:

- [`astro`](https://astro.build) — static site, routing, and View Transitions
- [`@astrojs/sitemap`](https://docs.astro.build/en/guides/integrations-guide/sitemap/) — sitemap generation
- [`exifr`](https://github.com/MikeKovarik/exifr) — image EXIF/XMP parsing (JPEG, PNG, WebP, HEIC)
- [`piexifjs`](https://github.com/hMatoba/piexifjs) — JPEG EXIF write and edit
- [`jszip`](https://stuk.github.io/jszip/) — OOXML (DOCX, XLSX, PPTX) zip I/O
- [`pdf-lib`](https://pdf-lib.js.org/) — PDF Info dictionary read, strip, and edit

Development: TypeScript, Vitest, Playwright, `@astrojs/check`, and jsdom.

## Local development

Node 22+ (see `.nvmrc`).

```sh
npm install
npm run dev
```

```sh
npm run build
npm run preview
```

```sh
npm test
npm run check
npm run test:e2e
```

Regenerate the Open Graph image and apple-touch icon (Playwright):

```sh
npm run render:og
```

## Cloudflare Pages

- Build command: `npm run build`
- Output directory: `dist`
- Node version: `22` (see `.nvmrc`)

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md). Please follow the [Code of Conduct](CODE_OF_CONDUCT.md). Security reports: [SECURITY.md](SECURITY.md).

## License

[AGPL-3.0-or-later](LICENSE).

Built with [Astro](https://astro.build). Visual theme from [Astro Palette](https://github.com/joshruggles/astro-palette) (Terminal palette), based on herdr.
