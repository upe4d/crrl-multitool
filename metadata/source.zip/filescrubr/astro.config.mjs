import { defineConfig } from 'astro/config';
import sitemap from '@astrojs/sitemap';
import { SITE } from './src/lib/site';

export default defineConfig({
  site: SITE.url,
  trailingSlash: 'always',
  compressHTML: true,
  integrations: [
    sitemap({
      serialize(item) {
        const pathname = new URL(item.url).pathname;
        const isHome = pathname === '/';
        return {
          ...item,
          changefreq: isHome ? 'weekly' : 'monthly',
          priority: isHome ? 1.0 : 0.8,
        };
      },
    }),
  ],
});
