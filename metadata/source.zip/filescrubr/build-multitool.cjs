const esbuild = require('esbuild');
const fs = require('fs');
const path = require('path');
esbuild.build({entryPoints:['src/lib/scrub/engine.ts'],bundle:true,format:'iife',globalName:'FileScrubr',platform:'browser',minify:true,write:false,plugins:[{name:'local-read',setup(build){build.onLoad({filter:/\.[cm]?[jt]s$/},args=>({contents:fs.readFileSync(args.path,'utf8'),loader:args.path.endsWith('.ts')?'ts':'js',resolveDir:path.dirname(args.path)}));}}]}).then(result=>{fs.writeFileSync('../github-release-20261107/metadata/engine.js',result.outputFiles[0].contents);console.log('Собрано байт:',result.outputFiles[0].contents.length)}).catch(e=>{console.error(e);process.exitCode=1});
