import { defineConfig } from 'vitest/config';

export default defineConfig({
  test: {
    include: ['src/**/*.test.ts'],
    environment: 'node',
    coverage: {
      provider: 'v8',
      include: ['src/lib/scrub/**/*.ts', 'src/scripts/**/*.ts'],
      exclude: ['src/**/*.test.ts', 'src/lib/scrub/test-fixtures.ts', 'src/scripts/scrub/test-dom.ts'],
    },
  },
});
