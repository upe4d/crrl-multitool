## Pull request

- [ ] `npm test` passes
- [ ] `npm run check` passes
- [ ] New format handlers are registered in `src/lib/scrub/registry.ts` and covered by tests
- [ ] User-facing format copy was updated in `src/lib/scrub/copy.ts` (not duplicated in pages)

## Notes

<!-- What changed and why. Link issues if any. -->
