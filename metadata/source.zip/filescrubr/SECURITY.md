# Security Policy

File Scrubr is a static website. Files are read with the browser File API, parsed in JavaScript (optionally in a Web Worker), and downloaded from a blob URL. Nothing is uploaded and there is no server-side processing.

## Reporting a vulnerability

Please **do not** open a public issue for security reports.

Use [GitHub private vulnerability reporting](https://github.com/montana-digital/filescrubr/security/advisories/new) on this repository.

Include:

- A description of the issue and impact
- Steps to reproduce, or a minimal proof of concept
- Affected versions or commit if you know them

We will acknowledge the report and follow up with a fix or an explanation.

## Out of scope

- Theoretical attacks that require a compromised browser or malicious extension
- Issues that only affect a locally modified copy of the site
- Missing optional headers that do not change the privacy model (files still never leave the device)
