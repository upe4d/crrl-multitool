import { chromium } from 'playwright';
import { pathToFileURL } from 'node:url';
import path from 'node:path';

const root = path.resolve(import.meta.dirname, 'og');

const browser = await chromium.launch();

const og = await browser.newPage({
  viewport: { width: 1200, height: 630 },
  deviceScaleFactor: 1,
});
await og.goto(pathToFileURL(path.join(root, 'og.html')).href, { waitUntil: 'networkidle' });
await og.screenshot({
  path: path.resolve('public/assets/og.png'),
  type: 'png',
});

const icon = await browser.newPage({
  viewport: { width: 180, height: 180 },
  deviceScaleFactor: 1,
});
await icon.goto(pathToFileURL(path.join(root, 'apple-touch-icon.html')).href, {
  waitUntil: 'networkidle',
});
await icon.screenshot({
  path: path.resolve('public/apple-touch-icon.png'),
  type: 'png',
});

await browser.close();
console.log('Wrote public/assets/og.png and public/apple-touch-icon.png');
