import { asScrubError } from '../lib/scrub/errors';
import { handleJob } from '../lib/scrub/engine';
import type { WorkerRequest } from '../lib/scrub/types';

self.onmessage = async (event: MessageEvent<WorkerRequest>) => {
  const id = event.data?.id ?? 0;
  try {
    const result = await handleJob(event.data);
    if (result.buffer) {
      (self as unknown as Worker).postMessage(result, [result.buffer]);
    } else {
      (self as unknown as Worker).postMessage(result);
    }
  } catch (err) {
    const error = asScrubError(err);
    (self as unknown as Worker).postMessage({
      id,
      ok: false,
      error: { code: error.code, message: error.message, hint: error.hint },
    });
  }
};
