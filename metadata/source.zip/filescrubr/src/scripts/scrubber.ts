export { initScrubber } from './scrub/app';
