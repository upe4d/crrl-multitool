const PREFIX = 'Inspect, edit and delete metadata ';
const FLAIR = 'for free';
const CHAR_MS = 30;
const FLARE_MS = 400;

let controller: AbortController | undefined;

function prefersReducedMotion(): boolean {
  return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
}

function delay(ms: number, signal: AbortSignal): Promise<void> {
  if (signal.aborted) return Promise.reject(new DOMException('Aborted', 'AbortError'));
  return new Promise((resolve, reject) => {
    const onAbort = () => {
      window.clearTimeout(id);
      reject(new DOMException('Aborted', 'AbortError'));
    };
    const id = window.setTimeout(() => {
      signal.removeEventListener('abort', onAbort);
      resolve();
    }, ms);
    signal.addEventListener('abort', onAbort, { once: true });
  });
}

export function initHeroLede() {
  controller?.abort();
  controller = new AbortController();
  const { signal } = controller;

  const lede = document.querySelector<HTMLElement>('#scrub-app .hero-lede');
  if (!lede) return;

  lede.querySelector('.hero-lede-live')?.remove();
  lede.classList.remove('is-animating');

  const sizerFlair = lede.querySelector('.hero-lede-sizer .hero-lede-flair');

  if (prefersReducedMotion()) {
    lede.classList.remove('is-pending');
    sizerFlair?.classList.add('is-flare');
    return;
  }

  const live = document.createElement('span');
  live.className = 'hero-lede-live';
  live.setAttribute('aria-hidden', 'true');

  const prefixEl = document.createElement('span');
  const flairEl = document.createElement('span');
  flairEl.className = 'hero-lede-flair';
  const cursor = document.createElement('span');
  cursor.className = 'hero-lede-cursor';
  cursor.setAttribute('aria-hidden', 'true');
  live.append(prefixEl, flairEl, cursor);
  lede.append(live);
  lede.classList.add('is-animating');
  lede.classList.remove('is-pending');

  void (async () => {
    try {
      for (let i = 1; i <= PREFIX.length; i += 1) {
        prefixEl.textContent = PREFIX.slice(0, i);
        await delay(CHAR_MS, signal);
      }
      for (let i = 1; i <= FLAIR.length; i += 1) {
        flairEl.textContent = FLAIR.slice(0, i);
        await delay(CHAR_MS, signal);
      }
      cursor.remove();
      flairEl.classList.add('is-flare', 'is-shining');
      sizerFlair?.classList.add('is-flare');
      await Promise.race([
        new Promise<void>((resolve) => {
          flairEl.addEventListener('animationend', () => resolve(), { once: true, signal });
        }),
        delay(FLARE_MS + 80, signal),
      ]);
      flairEl.classList.remove('is-shining');
    } catch (err) {
      if (err instanceof DOMException && err.name === 'AbortError') return;
      prefixEl.textContent = PREFIX;
      flairEl.textContent = FLAIR;
      flairEl.classList.add('is-flare');
      flairEl.classList.remove('is-shining');
      sizerFlair?.classList.add('is-flare');
      cursor.remove();
    }
  })();
}
