import { $ } from './dom';
import { canDownload, getSession, isBusy, isEditing, setBusyFlag } from './session';

export type StatusKind = 'ok' | 'warn' | 'error' | 'busy' | 'empty' | '';

export function setStatus(kind: StatusKind, message: string, hint?: string) {
  const el = $('scrub-status');
  if (!el) return;
  el.dataset.kind = kind;
  el.replaceChildren();
  const prompt = document.createElement('span');
  prompt.className = 'scrub-prompt';
  prompt.textContent = kind === 'error' ? '$ error' : kind === 'warn' ? '$ warn' : kind === 'busy' ? '$ …' : kind === 'ok' || kind === 'empty' ? '$ ok' : '$';
  const msg = document.createElement('span');
  msg.className = 'scrub-status-msg';
  msg.textContent = message;
  el.append(prompt, msg);
  if (hint) {
    const extra = document.createElement('span');
    extra.className = 'scrub-status-hint';
    extra.textContent = hint;
    el.append(extra);
  }
  if (kind === 'error') {
    el.setAttribute('role', 'alert');
    el.focus();
  } else {
    el.removeAttribute('role');
  }
}

export function setBusy(value: boolean, label?: string) {
  setBusyFlag(value);
  const app = $('scrub-app');
  app?.classList.toggle('is-busy', value);
  for (const btn of document.querySelectorAll<HTMLButtonElement>('[data-scrub-action]')) {
    btn.disabled = value || btn.hasAttribute('data-keep-disabled');
  }
  if (value && label) setStatus('busy', label);
}

export function updateActions() {
  const session = getSession();
  const editing = isEditing();
  const busy = isBusy();
  const hasSession = Boolean(session);
  const canEdit = Boolean(session?.caps.edit && session.records.some((r) => r.writable));
  const canStrip = Boolean(session?.caps.strip && session.records.some((r) => r.removable));
  const active = document.activeElement;

  toggle('btn-delete', hasSession && canStrip && !editing, busy);
  toggle('btn-edit', hasSession && canEdit && !editing, busy);
  toggle('btn-clear', hasSession, busy);
  toggle('btn-new', hasSession, busy);
  toggle('btn-save', hasSession && editing, busy);
  toggle('btn-cancel-edit', hasSession && editing, busy);
  toggle('btn-download', hasSession && canDownload() && !editing, busy);

  if (active instanceof HTMLElement && active.hasAttribute('hidden') && active.closest('#scrub-app')) {
    active.blur();
    $('scrub-status')?.focus();
  }
}

function toggle(id: string, show: boolean, busy: boolean) {
  const el = $(id);
  if (!el) return;
  el.toggleAttribute('hidden', !show);
  if (el instanceof HTMLButtonElement) {
    el.disabled = busy || !show;
    if (!show) el.setAttribute('data-keep-disabled', '');
    else el.removeAttribute('data-keep-disabled');
  }
}
