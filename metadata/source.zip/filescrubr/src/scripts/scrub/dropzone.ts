import { Errors } from '../../lib/scrub/errors';
import { ACCEPT_ATTR } from '../../lib/scrub/types';
import { $ } from './dom';
import { isBusy } from './session';
import { setStatus } from './status';

export function bindDropzone(onFiles: (files: FileList | File[] | null) => void, signal: AbortSignal) {
  const drop = $('dropzone');
  const input = $('scrub-input') as HTMLInputElement | null;
  if (input) input.accept = ACCEPT_ATTR;

  drop?.addEventListener('click', () => {
    if (drop.classList.contains('is-disabled')) return;
    if (isBusy()) {
      warnBusy();
      return;
    }
    input?.click();
  }, { signal });
  drop?.addEventListener('keydown', (e) => {
    if (drop.classList.contains('is-disabled')) return;
    if (isBusy()) {
      warnBusy();
      return;
    }
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      input?.click();
    }
  }, { signal });
  input?.addEventListener('change', () => onFiles(input.files), { signal });

  drop?.addEventListener('dragenter', (e) => { e.preventDefault(); drop.classList.add('is-dragover'); }, { signal });
  drop?.addEventListener('dragover', (e) => { e.preventDefault(); drop.classList.add('is-dragover'); }, { signal });
  drop?.addEventListener('dragleave', () => drop.classList.remove('is-dragover'), { signal });
  drop?.addEventListener('drop', (e) => {
    e.preventDefault();
    drop.classList.remove('is-dragover');
    if (drop.classList.contains('is-disabled')) return;
    if (isBusy()) {
      warnBusy();
      return;
    }
    onFiles(e.dataTransfer?.files ?? null);
  }, { signal });
}

export function warnBusy() {
  const err = Errors.busy();
  setStatus('warn', err.message, err.hint);
}

export function takeFiles(list: FileList | File[] | null, loadFile: (file: File) => void) {
  if (!list || list.length === 0) return;
  const files = Array.from(list);
  if (files.some((f) => f.size === 0 && (f.type === '' || f.type === 'application/x-directory'))) {
    setStatus('error', Errors.multiple().message, 'Folders are not supported. Drop a single file.');
    return;
  }
  if (files.length > 1) {
    setStatus('error', Errors.multiple().message, Errors.multiple().hint);
    return;
  }
  loadFile(files[0]!);
}
