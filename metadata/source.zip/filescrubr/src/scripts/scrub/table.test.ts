/** @vitest-environment jsdom */
import { beforeEach, describe, expect, it } from 'vitest';
import { FORMAT_CAPS } from '../../lib/scrub/types';
import { setEditing, setSession } from './session';
import { animateRemovedRows, collectEdits, renderTable } from './table';
import { mountScrubApp, sampleRecords, sessionWith } from './test-dom';

function stubMotion(reduce: boolean) {
  window.matchMedia = ((query: string) =>
    ({
      matches: reduce && query.includes('prefers-reduced-motion'),
      media: query,
      addEventListener() {},
      removeEventListener() {},
      addListener() {},
      removeListener() {},
      dispatchEvent() {
        return false;
      },
      onchange: null,
    })) as typeof window.matchMedia;
}

describe('table', () => {
  beforeEach(() => {
    mountScrubApp();
    setEditing(false);
    setSession(null);
    stubMotion(false);
  });

  it('groups rows and shows values', () => {
    renderTable(sampleRecords());
    expect(document.querySelectorAll('.meta-group').length).toBe(2);
    expect(document.body.textContent).toContain('Comment');
    expect(document.body.textContent).toContain('secret');
    expect(document.querySelectorAll('[data-edit-key]').length).toBe(0);
    expect(document.querySelector('[role="columnheader"]')?.textContent).toBe('Field');
  });

  it('renders inputs in edit mode and collects edits', () => {
    setEditing(true);
    renderTable(sampleRecords());
    const input = document.querySelector<HTMLInputElement>('[data-edit-key="Comment"]');
    expect(input).toBeTruthy();
    input!.value = 'Ada';
    expect(collectEdits()).toEqual({ Comment: 'Ada' });
  });

  it('shows deletable and editable tags on capable rows', () => {
    sessionWith();
    renderTable(sampleRecords());
    const comment = document.querySelector('[data-meta-key="Comment"]');
    expect(comment?.querySelector('.meta-tag-deletable')?.textContent).toBe('deletable');
    expect(comment?.querySelector('.meta-tag-editable')?.textContent).toBe('editable');
    const name = document.querySelector('[data-meta-key="name"]');
    expect(name?.querySelector('.meta-tag')).toBeNull();
  });

  it('hides tags when the format cannot strip or edit', () => {
    sessionWith(FORMAT_CAPS.heic);
    renderTable(sampleRecords());
    expect(document.querySelector('.meta-tag')).toBeNull();
  });

  it('skips motion and drops removed rows immediately', async () => {
    stubMotion(true);
    sessionWith();
    renderTable(sampleRecords());
    const after = sampleRecords().filter((r) => r.key !== 'Comment');
    await animateRemovedRows(sampleRecords(), after);
    expect(document.body.textContent).toContain('name');
    expect(document.body.textContent).not.toContain('secret');
    expect(document.querySelector('[data-meta-key="Comment"]')).toBeNull();
  });

  it('falls back to a full render when removed rows are missing from the DOM', async () => {
    sessionWith();
    const after = sampleRecords().filter((r) => r.key !== 'Comment');
    await animateRemovedRows(sampleRecords(), after);
    expect(document.body.textContent).toContain('name');
    expect(document.body.textContent).not.toContain('secret');
    expect(document.querySelectorAll('.meta-row').length).toBe(1);
  });
});
