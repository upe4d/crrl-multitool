/** @vitest-environment jsdom */
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { downloadBuffer, revokeObjectUrls } from './download';
import { mountScrubApp } from './test-dom';

describe('download', () => {
  beforeEach(() => {
    mountScrubApp();
    vi.stubGlobal('URL', {
      createObjectURL: vi.fn(() => 'blob:test'),
      revokeObjectURL: vi.fn(),
    });
  });

  afterEach(() => {
    revokeObjectUrls();
    vi.unstubAllGlobals();
  });

  it('creates a blob URL and clicks an anchor', () => {
    const click = vi.spyOn(HTMLAnchorElement.prototype, 'click').mockImplementation(() => {});
    const mode = downloadBuffer(new ArrayBuffer(4), 'shot-scrubbed.png', 'image/png');
    expect(mode).toBe('ok');
    expect(click).toHaveBeenCalled();
    click.mockRestore();
  });

  it('reports download_failed with a hint when blob creation throws', () => {
    vi.stubGlobal('Blob', class {
      constructor() {
        throw new Error('fail');
      }
    });
    const mode = downloadBuffer(new ArrayBuffer(4), 'shot-scrubbed.png', 'image/png');
    expect(mode).toBe('fail');
    expect(document.getElementById('scrub-status')?.textContent).toContain('Could not start the download');
    expect(document.getElementById('scrub-status')?.textContent).toContain('Try Download File again');
  });
});
