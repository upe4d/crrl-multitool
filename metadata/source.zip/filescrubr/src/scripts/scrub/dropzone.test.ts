/** @vitest-environment jsdom */
import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import { ACCEPT_ATTR } from '../../lib/scrub/types';
import { bindDropzone, takeFiles } from './dropzone';
import { setBusyFlag } from './session';
import { mountScrubApp } from './test-dom';

function statusText() {
  return document.getElementById('scrub-status')?.textContent ?? '';
}

describe('dropzone', () => {
  beforeEach(() => {
    mountScrubApp();
    setBusyFlag(false);
  });

  afterEach(() => {
    setBusyFlag(false);
  });

  it('assigns ACCEPT_ATTR on the file input', () => {
    bindDropzone(() => {}, new AbortController().signal);
    const input = document.getElementById('scrub-input') as HTMLInputElement;
    expect(input.accept).toBe(ACCEPT_ATTR);
  });

  it('loads a single file', () => {
    const loaded: File[] = [];
    takeFiles([new File(['x'], 'a.png')], (file) => loaded.push(file));
    expect(loaded).toHaveLength(1);
  });

  it('rejects multiple files', () => {
    const loaded: File[] = [];
    takeFiles([new File(['x'], 'a.png'), new File(['y'], 'b.png')], (file) => loaded.push(file));
    expect(loaded).toHaveLength(0);
    expect(statusText()).toContain('Drop one file at a time');
  });

  it('rejects folder-like empty files', () => {
    const folder = new File([], 'folder', { type: 'application/x-directory' });
    takeFiles([folder], () => {});
    expect(statusText()).toContain('Folders are not supported');
  });

  it('warns when a drop happens while busy', () => {
    setBusyFlag(true);
    bindDropzone(() => {}, new AbortController().signal);
    const drop = document.getElementById('dropzone')!;
    drop.dispatchEvent(new Event('drop', { bubbles: true, cancelable: true }));
    expect(statusText()).toContain('Still working on the current file');
  });
});
