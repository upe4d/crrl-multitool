import type { MetadataRecord } from '../../lib/scrub/types';
import { $ } from './dom';
import { getSession, isEditing } from './session';

const BLINK_MS = 840;
const COLLAPSE_MS = 350;
const ANIM_CAP_MS = 1200;

function recordId(rec: Pick<MetadataRecord, 'group' | 'key'>): string {
  return `${rec.group}\0${rec.key}`;
}

function prefersReducedMotion(): boolean {
  return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
}

function delay(ms: number): Promise<void> {
  return new Promise((resolve) => window.setTimeout(resolve, ms));
}

function appendTags(keyEl: HTMLElement, rec: MetadataRecord) {
  const caps = getSession()?.caps;
  const tags: HTMLSpanElement[] = [];
  if (caps?.strip && rec.removable) {
    const tag = document.createElement('span');
    tag.className = 'meta-tag meta-tag-deletable';
    tag.textContent = 'deletable';
    tags.push(tag);
  }
  if (caps?.edit && rec.writable) {
    const tag = document.createElement('span');
    tag.className = 'meta-tag meta-tag-editable';
    tag.textContent = 'editable';
    tags.push(tag);
  }
  if (!tags.length) return;
  const wrap = document.createElement('span');
  wrap.className = 'meta-tags';
  wrap.append(...tags);
  keyEl.append(wrap);
}

export function renderTable(records: MetadataRecord[]) {
  const root = $('scrub-table');
  if (!root) return;
  root.replaceChildren();
  const groups = new Map<string, MetadataRecord[]>();
  for (const rec of records) {
    const list = groups.get(rec.group) ?? [];
    list.push(rec);
    groups.set(rec.group, list);
  }
  const editing = isEditing();
  for (const [group, rows] of groups) {
    const heading = document.createElement('h3');
    heading.className = 'meta-group';
    heading.textContent = group;
    root.append(heading);
    const table = document.createElement('div');
    table.className = 'meta-table';
    table.setAttribute('role', 'table');
    table.setAttribute('aria-label', `${group} metadata`);
    const head = document.createElement('div');
    head.className = 'visually-hidden';
    head.setAttribute('role', 'row');
    const fieldHeader = document.createElement('div');
    fieldHeader.setAttribute('role', 'columnheader');
    fieldHeader.textContent = 'Field';
    const valueHeader = document.createElement('div');
    valueHeader.setAttribute('role', 'columnheader');
    valueHeader.textContent = 'Value';
    head.append(fieldHeader, valueHeader);
    table.append(head);
    for (const rec of rows) {
      const row = document.createElement('div');
      row.className = 'meta-row';
      row.setAttribute('role', 'row');
      row.dataset.metaGroup = rec.group;
      row.dataset.metaKey = rec.key;
      const key = document.createElement('div');
      key.className = 'meta-key';
      key.setAttribute('role', 'cell');
      const label = document.createElement('span');
      label.className = 'meta-key-label';
      label.textContent = rec.key;
      key.append(label);
      appendTags(key, rec);
      const val = document.createElement('div');
      val.className = 'meta-val';
      val.setAttribute('role', 'cell');
      if (editing && rec.writable) {
        const input = document.createElement('input');
        input.type = 'text';
        input.value = rec.value;
        input.dataset.editKey = rec.key;
        input.setAttribute('aria-label', rec.key);
        val.append(input);
      } else {
        val.textContent = rec.value;
      }
      row.append(key, val);
      table.append(row);
    }
    root.append(table);
  }
}

function findRow(rec: Pick<MetadataRecord, 'group' | 'key'>): HTMLElement | null {
  for (const row of document.querySelectorAll<HTMLElement>('.meta-row')) {
    if (row.dataset.metaGroup === rec.group && row.dataset.metaKey === rec.key) return row;
  }
  return null;
}

function collapseElement(el: HTMLElement) {
  el.style.overflow = 'hidden';
  el.style.maxHeight = `${el.getBoundingClientRect().height}px`;
  void el.offsetHeight;
  el.classList.add('is-collapsing');
  el.style.maxHeight = '0px';
}

export async function animateRemovedRows(
  before: MetadataRecord[],
  after: MetadataRecord[],
  stillCurrent: () => boolean = () => true,
): Promise<void> {
  const finish = () => {
    if (stillCurrent()) renderTable(after);
  };
  try {
    const afterIds = new Set(after.map(recordId));
    const removed = before.filter((rec) => !afterIds.has(recordId(rec)));
    if (removed.length === 0 || prefersReducedMotion()) {
      finish();
      return;
    }

    const nodes = removed.map(findRow);
    if (nodes.some((el) => !el)) {
      finish();
      return;
    }

    const rows = nodes as HTMLElement[];
    for (const row of rows) row.classList.add('is-removing');

    await Promise.race([
      (async () => {
        await delay(BLINK_MS);
        if (!stillCurrent()) return;
        const extras = new Set<HTMLElement>();
        for (const row of rows) {
          collapseElement(row);
          const table = row.closest('.meta-table');
          if (!(table instanceof HTMLElement)) continue;
          const leftover = [...table.querySelectorAll('.meta-row')].filter(
            (el) => !el.classList.contains('is-removing'),
          );
          if (leftover.length > 0) continue;
          extras.add(table);
          const heading = table.previousElementSibling;
          if (heading instanceof HTMLElement && heading.classList.contains('meta-group')) {
            extras.add(heading);
          }
        }
        for (const el of extras) collapseElement(el);
        await delay(COLLAPSE_MS);
      })(),
      delay(ANIM_CAP_MS),
    ]);
    finish();
  } catch {
    finish();
  }
}

export function collectEdits(): Record<string, string> {
  const edits: Record<string, string> = {};
  for (const input of document.querySelectorAll<HTMLInputElement>('[data-edit-key]')) {
    const key = input.dataset.editKey;
    if (!key) continue;
    edits[key] = input.value;
  }
  return edits;
}
