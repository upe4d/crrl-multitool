import { ScrubClient } from '../../lib/scrub/client';
import type { FormatCaps, MetadataRecord } from '../../lib/scrub/types';

export interface Session {
  filename: string;
  buffer: ArrayBuffer;
  records: MetadataRecord[];
  caps: FormatCaps;
  mime: string;
  extension: string;
  warnings: string[];
}

let client: ScrubClient | null = null;
let session: Session | null = null;
let editing = false;
let busy = false;
let jobGen = 0;
let hasDownload = false;

export function getClient(): ScrubClient | null {
  return client;
}

export function setClient(next: ScrubClient | null) {
  client = next;
}

export function ensureClient(): ScrubClient {
  if (!client) client = new ScrubClient();
  return client;
}

export function getSession(): Session | null {
  return session;
}

export function setSession(next: Session | null) {
  session = next;
  if (!next) hasDownload = false;
}

export function canDownload(): boolean {
  return hasDownload;
}

export function setHasDownload(value: boolean) {
  hasDownload = value;
}

export function isEditing(): boolean {
  return editing;
}

export function setEditing(value: boolean) {
  editing = value;
}

export function isBusy(): boolean {
  return busy;
}

export function setBusyFlag(value: boolean) {
  busy = value;
}

export function currentJobGen(): number {
  return jobGen;
}

export function bumpJobGen(): number {
  jobGen += 1;
  return jobGen;
}
