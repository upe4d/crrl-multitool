/** @vitest-environment jsdom */
import { beforeEach, describe, expect, it } from 'vitest';
import { FORMAT_CAPS } from '../../lib/scrub/types';
import { Errors } from '../../lib/scrub/errors';
import { setEditing, setHasDownload } from './session';
import { setStatus, updateActions } from './status';
import { mountScrubApp, sampleRecords, sessionWith } from './test-dom';

function shown(id: string) {
  const el = document.getElementById(id);
  return Boolean(el && !el.hasAttribute('hidden'));
}

describe('status and actions', () => {
  beforeEach(() => {
    mountScrubApp();
  });

  it('shows Delete and Edit for a writable PNG session', () => {
    sessionWith(FORMAT_CAPS.png);
    updateActions();
    expect(shown('btn-delete')).toBe(true);
    expect(shown('btn-edit')).toBe(true);
    expect(shown('btn-clear')).toBe(true);
    expect(shown('btn-download')).toBe(false);
  });

  it('hides Delete and Edit for HEIC inspect-only', () => {
    sessionWith(FORMAT_CAPS.heic, sampleRecords({ writable: false, removable: false }));
    updateActions();
    expect(shown('btn-delete')).toBe(false);
    expect(shown('btn-edit')).toBe(false);
  });

  it('shows Save/Cancel only while editing and Download after canDownload', () => {
    sessionWith(FORMAT_CAPS.png);
    setEditing(true);
    updateActions();
    expect(shown('btn-save')).toBe(true);
    expect(shown('btn-cancel-edit')).toBe(true);
    expect(shown('btn-delete')).toBe(false);
    setEditing(false);
    setHasDownload(true);
    updateActions();
    expect(shown('btn-download')).toBe(true);
  });

  it('renders user-visible errors with a hint and role=alert', () => {
    const cases = [
      Errors.unsupported(),
      Errors.ole(),
      Errors.video(),
      Errors.tooLarge(50),
      Errors.encrypted(),
      Errors.damaged(),
      Errors.invalidOutput(),
      Errors.heicWrite(),
      Errors.timeout(),
      Errors.downloadFailed(),
      Errors.generic(),
    ];
    for (const err of cases) {
      setStatus('error', err.message, err.hint);
      const el = document.getElementById('scrub-status')!;
      expect(el.getAttribute('role')).toBe('alert');
      expect(el.dataset.kind).toBe('error');
      expect(el.textContent).toContain(err.message);
      expect(el.textContent).toContain(err.hint!);
    }
  });

  it('renders nothing_removable as empty, not alert', () => {
    const err = Errors.nothingRemovable();
    setStatus('empty', err.message, err.hint);
    const el = document.getElementById('scrub-status')!;
    expect(el.getAttribute('role')).toBeNull();
    expect(el.dataset.kind).toBe('empty');
    expect(el.textContent).toContain(err.message);
  });
});
