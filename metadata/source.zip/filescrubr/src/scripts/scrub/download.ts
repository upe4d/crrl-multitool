import { Errors } from '../../lib/scrub/errors';
import { setStatus } from './status';

let objectUrls: string[] = [];
let pagehideBound = false;

export function revokeObjectUrls() {
  for (const url of objectUrls) URL.revokeObjectURL(url);
  objectUrls = [];
}

export function bindPagehideCleanup() {
  if (pagehideBound) return;
  pagehideBound = true;
  window.addEventListener('pagehide', () => {
    revokeObjectUrls();
  });
}

export function downloadBuffer(buffer: ArrayBuffer, filename: string, mime: string) {
  try {
    const blob = new Blob([buffer], { type: mime });
    const url = URL.createObjectURL(blob);
    objectUrls.push(url);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.rel = 'noopener';
    document.body.append(a);
    a.click();
    a.remove();
    const isiOS = /iPad|iPhone|iPod/.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
    const downloadLikelyIgnored = isiOS || !('download' in HTMLAnchorElement.prototype);
    if (downloadLikelyIgnored) {
      const opened = window.open(url, '_blank', 'noopener');
      if (!opened) {
        setStatus('warn', 'If the download did not start, tap the file link in a new tab and use Share / Save.');
      } else {
        setStatus('warn', 'If the download did not start, use Share / Save in the new tab.');
      }
      return 'tab' as const;
    }
    window.setTimeout(() => {
      URL.revokeObjectURL(url);
      objectUrls = objectUrls.filter((u) => u !== url);
    }, 60_000);
    return 'ok' as const;
  } catch {
    const err = Errors.downloadFailed();
    setStatus('error', err.message, err.hint);
    return 'fail' as const;
  }
}
