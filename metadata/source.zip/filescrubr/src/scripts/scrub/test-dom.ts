import { FORMAT_CAPS, type FormatCaps, type MetadataRecord } from '../../lib/scrub/types';
import { setEditing, setHasDownload, setSession } from './session';

export function mountScrubApp() {
  document.body.innerHTML = `
    <main id="scrub-app">
      <div id="dropzone" class="dropzone" role="button" tabindex="0">
        <input id="scrub-input" type="file" />
      </div>
      <p id="scrub-status" tabindex="-1"><span class="scrub-status-msg">Ready.</span></p>
      <section id="scrub-results" hidden>
        <p id="scrub-filename"></p>
        <div id="scrub-actions">
          <button id="btn-delete" hidden data-scrub-action>Delete Metadata</button>
          <button id="btn-edit" hidden data-scrub-action>Edit Metadata</button>
          <button id="btn-clear" hidden data-scrub-action>Clear</button>
          <button id="btn-new" hidden>Start New Scrub</button>
          <button id="btn-save" hidden data-scrub-action>Save</button>
          <button id="btn-cancel-edit" hidden data-scrub-action>Cancel edit</button>
          <button id="btn-download" hidden data-scrub-action>Download File</button>
        </div>
        <div id="scrub-table"></div>
      </section>
    </main>
  `;
}

export function sampleRecords(overrides: Partial<MetadataRecord> = {}): MetadataRecord[] {
  return [
    { group: 'File', key: 'name', value: 'shot.png', writable: false, removable: false },
    { group: 'PNG', key: 'Comment', value: 'secret', writable: true, removable: true, ...overrides },
  ];
}

export function sessionWith(caps: FormatCaps = FORMAT_CAPS.png, records = sampleRecords()) {
  setSession({
    filename: 'shot.png',
    buffer: new ArrayBuffer(8),
    records,
    caps,
    mime: 'image/png',
    extension: 'png',
    warnings: [],
  });
  setEditing(false);
  setHasDownload(false);
}
