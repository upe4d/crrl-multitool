/** @vitest-environment jsdom */
import { describe, expect, it } from 'vitest';
import { Errors } from '../../lib/scrub/errors';
import { maxBytes } from './app';

describe('maxBytes', () => {
  it('uses 50 MB when deviceMemory is missing or high', () => {
    Object.defineProperty(navigator, 'deviceMemory', { configurable: true, value: 8 });
    expect(maxBytes()).toEqual({ bytes: 50 * 1024 * 1024, mb: 50 });
  });

  it('uses 20 MB on low-memory devices', () => {
    Object.defineProperty(navigator, 'deviceMemory', { configurable: true, value: 2 });
    expect(maxBytes()).toEqual({ bytes: 20 * 1024 * 1024, mb: 20 });
    expect(Errors.tooLarge(20).message).toContain('20 MB');
  });
});
