import { formatBytes, scrubbedName } from '../../lib/scrub/bytes';
import { ScrubClient } from '../../lib/scrub/client';
import { Errors, ScrubError, asScrubError } from '../../lib/scrub/errors';
import { $ } from './dom';
import { bindPagehideCleanup, downloadBuffer, revokeObjectUrls } from './download';
import { bindDropzone, takeFiles, warnBusy } from './dropzone';
import {
  bumpJobGen,
  canDownload,
  currentJobGen,
  ensureClient,
  getClient,
  getSession,
  isBusy,
  isEditing,
  setBusyFlag,
  setClient,
  setEditing,
  setHasDownload,
  setSession,
} from './session';
import { setBusy, setStatus, updateActions } from './status';
import { animateRemovedRows, collectEdits, renderTable } from './table';

let bindController: AbortController | null = null;

export function maxBytes(): { bytes: number; mb: number } {
  const mem = (navigator as Navigator & { deviceMemory?: number }).deviceMemory;
  const mb = typeof mem === 'number' && mem < 4 ? 20 : 50;
  return { bytes: mb * 1024 * 1024, mb };
}

function resetUi() {
  bumpJobGen();
  getClient()?.reset();
  setClient(new ScrubClient());
  setSession(null);
  setEditing(false);
  setBusyFlag(false);
  revokeObjectUrls();
  const input = $('scrub-input') as HTMLInputElement | null;
  if (input) input.value = '';
  $('dropzone')?.classList.remove('is-disabled', 'is-dragover');
  $('dropzone')?.removeAttribute('aria-disabled');
  $('scrub-results')?.setAttribute('hidden', '');
  renderTable([]);
  updateActions();
  setStatus('', 'Ready.');
}

function applySessionFromParse(filename: string, buffer: ArrayBuffer, res: Awaited<ReturnType<ScrubClient['run']>>) {
  if (!res.ok || !res.records || !res.caps || !res.format) {
    throw new ScrubError(res.error?.code ?? 'parse_failed', res.error?.message ?? 'Could not read this file.', res.error?.hint);
  }
  setSession({
    filename,
    buffer,
    records: res.records,
    caps: res.caps,
    mime: res.mime ?? 'application/octet-stream',
    extension: res.extension ?? 'bin',
    warnings: res.warnings ?? [],
  });
  const session = getSession()!;
  $('dropzone')?.classList.add('is-disabled');
  $('dropzone')?.setAttribute('aria-disabled', 'true');
  $('scrub-results')?.removeAttribute('hidden');
  const nameEl = $('scrub-filename');
  if (nameEl) nameEl.textContent = `${filename} · ${formatBytes(buffer.byteLength)}`;
  setEditing(false);
  setHasDownload(false);
  renderTable(session.records);
  updateActions();
  const hint = workerFallbackHint();
  if (res.caps.inspectOnlyReason) {
    setStatus('warn', res.caps.inspectOnlyReason, hint);
  } else if (session.warnings.length) {
    setStatus('warn', session.warnings[0]!, hint);
  } else {
    const n = session.records.filter((r) => r.removable).length;
    if (n) setStatus('ok', `Found ${n} removable field${n === 1 ? '' : 's'}.`, hint);
    else setStatus('empty', 'No removable metadata found.', hint);
  }
}

function workerFallbackHint(): string | undefined {
  const client = getClient();
  if (!client?.noWorker || client.showedWorkerWarning) return undefined;
  client.markWorkerWarningShown();
  return 'Running without a background worker; large files may freeze briefly.';
}

async function loadFile(file: File) {
  if (isBusy()) {
    warnBusy();
    return;
  }
  const { bytes, mb } = maxBytes();
  if (file.size > bytes) {
    setStatus('error', Errors.tooLarge(mb).message, Errors.tooLarge(mb).hint);
    return;
  }
  const gen = bumpJobGen();
  setBusy(true, 'parsing…');
  try {
    const buffer = await file.arrayBuffer();
    if (gen !== currentJobGen()) return;
    const client = ensureClient();
    const res = await client.run('parse', file.name, buffer);
    if (gen !== currentJobGen()) return;
    applySessionFromParse(file.name, buffer, res);
  } catch (err) {
    if (gen !== currentJobGen()) return;
    const error = asScrubError(err);
    if (error.code === 'aborted') return;
    setStatus('error', error.message, error.hint);
    setSession(null);
    $('dropzone')?.classList.remove('is-disabled');
    $('scrub-results')?.setAttribute('hidden', '');
    updateActions();
  } finally {
    if (gen === currentJobGen()) setBusy(false);
  }
}

async function onDelete() {
  const session = getSession();
  if (!session || isBusy() || !session.caps.strip || !session.records.some((r) => r.removable)) return;
  const gen = currentJobGen();
  setBusy(true, 'scrubbing…');
  try {
    const res = await getClient()!.run('strip', session.filename, session.buffer);
    if (gen !== currentJobGen()) return;
    const live = getSession();
    if (!live) return;
    if (!res.ok || !res.buffer) {
      throw new ScrubError(res.error?.code ?? 'generic', res.error?.message ?? 'Could not strip metadata.', res.error?.hint);
    }
    const before = session.records;
    live.buffer = res.buffer;
    live.records = res.records ?? live.records;
    const removed = res.removedCount ?? 0;
    if (removed === 0) {
      const leftover = live.records.filter((r) => r.removable);
      if (leftover.length === 0) {
        renderTable(live.records);
        setStatus('empty', 'No removable metadata found.', workerFallbackHint());
        return;
      }
      live.records = live.records.map((r) => (r.removable ? { ...r, removable: false } : r));
      renderTable(live.records);
      const n = leftover.length;
      setStatus('warn', `Could not strip ${n} field${n === 1 ? '' : 's'}.`, workerFallbackHint());
      return;
    }
    setHasDownload(true);
    const name = scrubbedName(live.filename, live.extension);
    const mode = downloadBuffer(res.buffer, name, live.mime);
    const fallback = workerFallbackHint();
    if (mode !== 'fail') {
      if (res.remainingRemovable && res.remainingRemovable > 0) {
        setStatus('warn', res.warnings?.[0] ?? `Removed ${res.removedCount} fields; ${res.remainingRemovable} could not be stripped.`, fallback ?? `Downloading ${name}.`);
      } else if (mode !== 'tab') {
        setStatus('ok', `Removed ${res.removedCount} fields. Downloading ${name}.`, fallback);
      }
    }
    if (gen === currentJobGen()) {
      await animateRemovedRows(before, live.records, () => gen === currentJobGen());
    }
  } catch (err) {
    if (gen !== currentJobGen()) return;
    const error = asScrubError(err);
    if (error.code === 'aborted') return;
    if (error.code === 'nothing_removable') {
      setStatus('empty', error.message, error.hint);
      return;
    }
    setHasDownload(true);
    setStatus('error', error.message, error.hint ?? workerFallbackHint());
  } finally {
    if (gen === currentJobGen()) {
      setBusy(false);
      updateActions();
    }
  }
}

async function onSave() {
  const session = getSession();
  if (!session || isBusy() || !isEditing()) return;
  const edits = collectEdits();
  const gen = currentJobGen();
  setBusy(true, 'saving…');
  try {
    const res = await getClient()!.run('applyEdits', session.filename, session.buffer, edits);
    if (gen !== currentJobGen()) return;
    const live = getSession();
    if (!live) return;
    if (!res.ok || !res.buffer) {
      throw new ScrubError(res.error?.code ?? 'generic', res.error?.message ?? 'Could not save metadata.', res.error?.hint);
    }
    live.buffer = res.buffer;
    live.records = res.records ?? live.records;
    setEditing(false);
    setHasDownload(true);
    renderTable(live.records);
    updateActions();
    setStatus('ok', 'Changes saved. Download when ready.', workerFallbackHint());
  } catch (err) {
    if (gen !== currentJobGen()) return;
    const error = asScrubError(err);
    if (error.code === 'aborted') return;
    setHasDownload(true);
    setStatus('error', error.message, error.hint);
  } finally {
    if (gen === currentJobGen()) {
      setBusy(false);
      updateActions();
    }
  }
}

function onDownload() {
  const session = getSession();
  if (!session || !canDownload()) return;
  const name = scrubbedName(session.filename, session.extension);
  const mode = downloadBuffer(session.buffer, name, session.mime);
  if (mode === 'ok') setStatus('ok', `Downloading ${name}.`);
}

function cancelEdit() {
  const session = getSession();
  if (!session || !isEditing()) return;
  setEditing(false);
  renderTable(session.records);
  updateActions();
  setStatus('ok', 'Edit cancelled.');
}

function bind() {
  bindController?.abort();
  bindController = new AbortController();
  const { signal } = bindController;
  bindPagehideCleanup();
  bindDropzone((list) => takeFiles(list, (file) => void loadFile(file)), signal);

  $('btn-delete')?.addEventListener('click', () => void onDelete(), { signal });
  $('btn-edit')?.addEventListener('click', () => {
    const session = getSession();
    if (!session || isBusy() || isEditing() || !session.caps.edit || !session.records.some((r) => r.writable)) return;
    setEditing(true);
    renderTable(session.records);
    updateActions();
    setStatus('', 'Edit writable fields, then Save.');
  }, { signal });
  $('btn-cancel-edit')?.addEventListener('click', cancelEdit, { signal });
  $('btn-save')?.addEventListener('click', () => void onSave(), { signal });
  $('btn-download')?.addEventListener('click', onDownload, { signal });
  $('btn-clear')?.addEventListener('click', resetUi, { signal });
  $('btn-new')?.addEventListener('click', resetUi, { signal });

  document.addEventListener('keydown', (e) => {
    if (e.key !== 'Escape' || !isEditing() || isBusy()) return;
    e.preventDefault();
    cancelEdit();
  }, { signal });

  window.addEventListener('unhandledrejection', (event) => {
    const err = event.reason;
    if (err instanceof ScrubError && err.code === 'aborted') {
      event.preventDefault();
      return;
    }
    if (!(err instanceof ScrubError) || !isBusy()) return;
    setStatus('error', err.message, err.hint);
  }, { signal });
}

export function initScrubber() {
  if (!document.getElementById('scrub-app')) return;
  getClient()?.reset();
  setClient(new ScrubClient());
  bind();
  resetUi();
}
