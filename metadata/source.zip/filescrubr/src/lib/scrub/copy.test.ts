import { describe, expect, it } from 'vitest';
import { FORMAT_COPY, formatIdsInCopy } from './copy';
import { FORMAT_CAPS, type FormatId } from './types';

describe('FORMAT_COPY', () => {
  it('covers every format except video and unknown', () => {
    const ids = new Set(formatIdsInCopy());
    for (const id of Object.keys(FORMAT_CAPS) as FormatId[]) {
      if (id === 'unknown' || id === 'video') continue;
      expect(ids.has(id), `${id} missing from FORMAT_COPY`).toBe(true);
    }
  });

  it('gives every group a label and summary', () => {
    for (const group of FORMAT_COPY) {
      expect(group.label.length).toBeGreaterThan(0);
      expect(group.summary.length).toBeGreaterThan(0);
      expect(group.ids.length).toBeGreaterThan(0);
    }
  });
});
