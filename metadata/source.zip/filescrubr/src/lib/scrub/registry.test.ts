import { describe, expect, it } from 'vitest';
import { FORMAT_CAPS, type FormatId } from './types';
import { getHandler } from './registry';

const NO_HANDLER: FormatId[] = ['ole', 'video', 'unknown'];

describe('registry', () => {
  it('exposes a handler for every readable format', () => {
    for (const id of Object.keys(FORMAT_CAPS) as FormatId[]) {
      const handler = getHandler(id);
      if (NO_HANDLER.includes(id)) {
        expect(handler).toBeUndefined();
        continue;
      }
      expect(handler?.id).toBe(id);
      expect(handler?.caps).toEqual(FORMAT_CAPS[id]);
      if (FORMAT_CAPS[id].strip) expect(handler?.strip).toBeTypeOf('function');
      else expect(handler?.strip).toBeUndefined();
      if (FORMAT_CAPS[id].edit) expect(handler?.edit).toBeTypeOf('function');
      else expect(handler?.edit).toBeUndefined();
    }
  });
});
