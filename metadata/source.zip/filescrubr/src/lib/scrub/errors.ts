import { FORMAT_CAPS, supportedLabel, type ScrubErrorCode } from './types';

export class ScrubError extends Error {
  readonly code: ScrubErrorCode;
  readonly hint?: string;

  constructor(code: ScrubErrorCode, message: string, hint?: string, options?: { cause?: unknown }) {
    super(message, options);
    this.name = 'ScrubError';
    this.code = code;
    this.hint = hint;
  }
}

export function asScrubError(err: unknown): ScrubError {
  if (err instanceof ScrubError) return err;
  const message = err instanceof Error ? err.message : 'Something went wrong. Clear and try another file.';
  const lower = message.toLowerCase();
  if (lower.includes('password') || lower.includes('encrypt')) {
    return Errors.encrypted({ cause: err });
  }
  if (lower.includes('memory') || lower.includes('allocation') || err instanceof RangeError) {
    return new ScrubError(
      'too_large',
      'This file is too large to process in memory.',
      'Try a smaller file.',
      { cause: err },
    );
  }
  return Errors.damaged({ cause: err });
}

export const Errors = {
  tooLarge: (maxMb: number) =>
    new ScrubError('too_large', `File is too large for this device (max ${maxMb} MB).`, 'Try a smaller file.'),
  multiple: () =>
    new ScrubError('multiple', 'Drop one file at a time.', 'Clear extra files and try again.'),
  unsupported: () =>
    new ScrubError(
      'unsupported',
      FORMAT_CAPS.unknown.inspectOnlyReason!,
      FORMAT_CAPS.unknown.inspectOnlyHint ?? `Try ${supportedLabel()}.`,
    ),
  ole: () =>
    new ScrubError(
      'ole',
      FORMAT_CAPS.ole.inspectOnlyReason!,
      FORMAT_CAPS.ole.inspectOnlyHint,
    ),
  video: () =>
    new ScrubError(
      'video',
      FORMAT_CAPS.video.inspectOnlyReason!,
      FORMAT_CAPS.video.inspectOnlyHint,
    ),
  damaged: (options?: { cause?: unknown }) =>
    new ScrubError(
      'parse_failed',
      'Could not read this file. It may be damaged or encrypted.',
      'Try another file, or export from the original app and drop again.',
      options,
    ),
  encrypted: (options?: { cause?: unknown }) =>
    new ScrubError(
      'encrypted',
      'This file is password-protected and cannot be opened here.',
      'Remove the password in the original app, then drop the file again.',
      options,
    ),
  invalidOutput: () =>
    new ScrubError(
      'invalid_output',
      'Scrub produced an invalid file, so nothing was downloaded.',
      'The original is still in memory. Clear and try again, or download without changes.',
    ),
  heicWrite: () =>
    new ScrubError(
      'heic_write',
      FORMAT_CAPS.heic.inspectOnlyReason!,
      FORMAT_CAPS.heic.inspectOnlyHint,
    ),
  nothingRemovable: () =>
    new ScrubError(
      'nothing_removable',
      'No removable metadata found.',
      'This file has no tags this app can remove.',
    ),
  downloadFailed: () =>
    new ScrubError(
      'download_failed',
      'Could not start the download. Try again.',
      'Try Download File again, or Clear and start over.',
    ),
  timeout: () =>
    new ScrubError(
      'timeout',
      'Timed out reading this file.',
      'Try a smaller file, or clear and try again.',
    ),
  worker: () =>
    new ScrubError(
      'worker',
      'Background worker failed.',
      'Retrying without a background worker; large files may freeze briefly.',
    ),
  aborted: () => new ScrubError('aborted', 'Cancelled.'),
  generic: () =>
    new ScrubError(
      'generic',
      'Something went wrong. Clear and try another file.',
      'Clear and try another file.',
    ),
  busy: () =>
    new ScrubError(
      'busy',
      'Still working on the current file.',
      'Wait for it to finish, or Clear and start again.',
    ),
};
