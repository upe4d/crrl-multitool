import { describe, expect, it } from 'vitest';
import { detect, detectMagic, extensionFormat } from './detect';
import {
  ftyp,
  sampleCsv,
  sampleFlac,
  sampleGif,
  sampleHeic,
  sampleJpeg,
  sampleM4a,
  sampleMp3,
  sampleOle,
  samplePdf,
  samplePng,
  sampleSvg,
  sampleUnknown,
  sampleVideo,
  sampleWav,
  sampleWebp,
} from './test-fixtures';

describe('detect', () => {
  it('maps legacy .doc OLE magic to ole', () => {
    const ole = sampleOle();
    expect(detect('report.doc', ole).format).toBe('ole');
    expect(detectMagic(ole)).toBe('ole');
  });

  it('treats ftyp avc1 as unsupported video, not m4a', () => {
    const buf = sampleVideo();
    expect(detectMagic(buf)).toBe('video');
    expect(detect('clip.mp4', buf).format).toBe('video');
  });

  it('distinguishes JPEG and MP3 magic', () => {
    const jpeg = sampleJpeg();
    const mp3 = sampleMp3();
    expect(detectMagic(jpeg)).toBe('jpeg');
    expect(detect('song.mp3', jpeg).format).toBe('jpeg');
    expect(detectMagic(mp3)).toBe('mp3');
    expect(detect('photo.jpg', mp3).format).toBe('mp3');
  });

  it('detects each supported magic', async () => {
    expect(detectMagic(sampleJpeg())).toBe('jpeg');
    expect(detectMagic(samplePng())).toBe('png');
    expect(detectMagic(sampleWebp())).toBe('webp');
    expect(detectMagic(sampleGif())).toBe('gif');
    expect(detectMagic(sampleSvg())).toBe('svg');
    expect(detectMagic(sampleMp3())).toBe('mp3');
    expect(detectMagic(sampleWav())).toBe('wav');
    expect(detectMagic(sampleM4a())).toBe('m4a');
    expect(detectMagic(sampleFlac())).toBe('flac');
    expect(detectMagic(await samplePdf())).toBe('pdf');
    expect(detectMagic(sampleHeic())).toBe('heic');
    expect(detectMagic(sampleOle())).toBe('ole');
    expect(detectMagic(sampleUnknown())).toBe('unknown');
  });

  it('uses extension for CSV and SVG without strong magic', () => {
    expect(detect('data.csv', sampleCsv(false)).format).toBe('csv');
    expect(detect('logo.svg', new TextEncoder().encode('not xml')).format).toBe('svg');
  });

  it('maps common extensions', () => {
    expect(extensionFormat('a.jpg')).toBe('jpeg');
    expect(extensionFormat('a.jpeg')).toBe('jpeg');
    expect(extensionFormat('a.m4b')).toBe('m4a');
    expect(extensionFormat('a.heif')).toBe('heic');
    expect(extensionFormat('a.docx')).toBe('docx');
    expect(extensionFormat('a.mp4')).toBe('video');
  });

  it('warns when extension disagrees with magic', () => {
    const detection = detect('song.mp3', sampleJpeg());
    expect(detection.format).toBe('jpeg');
    expect(detection.extensionGuess).toBe('mp3');
    expect(detection.fromMagic).toBe(true);
  });

  it('treats M4A extension on a video ftyp as m4a', () => {
    expect(detect('song.m4a', ftyp('isom', ['mp42'])).format).toBe('m4a');
  });
});
