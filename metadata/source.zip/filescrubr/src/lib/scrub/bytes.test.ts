import { describe, expect, it } from 'vitest';
import { u32be, u32le } from './bytes';

describe('unsigned lengths', () => {
  it('reads a high-bit big-endian length as unsigned', () => {
    const buf = new Uint8Array([0x80, 0x00, 0x00, 0x01]);
    expect(u32be(buf, 0)).toBe(0x80000001);
  });

  it('reads a high-bit little-endian length as unsigned', () => {
    const buf = new Uint8Array([0x01, 0x00, 0x00, 0x80]);
    expect(u32le(buf, 0)).toBe(0x80000001);
  });

  it('throws when the read is out of range', () => {
    expect(() => u32be(new Uint8Array([1, 2, 3]), 0)).toThrow(RangeError);
    expect(() => u32le(new Uint8Array([1, 2]), 0)).toThrow(RangeError);
  });
});
