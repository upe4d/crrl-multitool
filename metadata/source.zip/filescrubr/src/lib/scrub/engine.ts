import JSZip from 'jszip';
import { u8 } from './bytes';
import { detect, detectMagic, extFor, mimeFor, refineZipFormat } from './detect';
import { Errors, ScrubError, asScrubError } from './errors';
import { parseOoxml } from './ooxml';
import { countRemovable, fileRecords } from './records';
import { getHandler } from './registry';
import type { FormatId, ParseResult, WorkerRequest, WorkerResponse, WriteResult } from './types';

function copyToBuffer(data: Uint8Array): ArrayBuffer {
  const out = new ArrayBuffer(data.byteLength);
  new Uint8Array(out).set(data);
  return out;
}

export async function handleJob(req: WorkerRequest): Promise<WorkerResponse> {
  try {
    if (req.op === 'parse') {
      const parsed = await parseFile(req.filename, req.buffer);
      return {
        id: req.id,
        ok: true,
        format: parsed.format,
        mime: parsed.mime,
        extension: parsed.extension,
        records: parsed.records,
        caps: parsed.caps,
        warnings: parsed.warnings,
      };
    }
    const result = req.op === 'strip'
      ? await stripFile(req.filename, req.buffer)
      : await editFile(req.filename, req.buffer, req.edits ?? {});
    return {
      id: req.id,
      ok: true,
      records: result.records,
      warnings: result.warnings,
      buffer: copyToBuffer(result.buffer),
      removedCount: result.removedCount,
      remainingRemovable: result.remainingRemovable,
    };
  } catch (err) {
    const error = asScrubError(err);
    return {
      id: req.id,
      ok: false,
      error: { code: error.code, message: error.message, hint: error.hint },
    };
  }
}

export async function parseFile(filename: string, buffer: ArrayBuffer): Promise<ParseResult> {
  const detection = detect(filename, buffer);
  let format = detection.format;
  const warnings: string[] = [];

  if (format === 'unknown' || format === 'docx' || format === 'xlsx' || format === 'pptx') {
    const magic = detectMagic(buffer);
    if (magic === 'unknown' && u8(buffer)[0] === 0x50 && u8(buffer)[1] === 0x4b) {
      try {
        const ooxml = await parseOoxml(buffer, format === 'unknown' ? undefined : format);
        format = ooxml.format;
      } catch (err) {
        if (err instanceof ScrubError && (err.code === 'encrypted' || err.code === 'too_large')) throw err;
      }
    }
  }

  if (detection.extensionGuess && detection.fromMagic && detection.extensionGuess !== format && detection.extensionGuess !== 'ole') {
    warnings.push(`File looks like ${format}, not ${detection.extensionGuess}. Scrubbing as ${format}.`);
  }

  if (format === 'video') throw Errors.video();
  if (format === 'ole') throw Errors.ole();
  if (format === 'unknown') throw Errors.unsupported();

  const handler = getHandler(format);
  if (!handler) throw Errors.unsupported();

  const caps = { ...handler.caps };
  const base = fileRecords(filename, format, buffer.byteLength);
  const parsed = await handler.parse(buffer);
  if (parsed.warnings?.length) warnings.push(...parsed.warnings);

  return {
    format,
    mime: mimeFor(format),
    extension: extFor(format, filename),
    records: [...base, ...parsed.records],
    caps,
    warnings,
    orientation: parsed.orientation,
  };
}

export async function stripFile(filename: string, buffer: ArrayBuffer): Promise<WriteResult> {
  const before = await parseFile(filename, buffer);
  if (!before.caps.strip) {
    if (before.format === 'heic') throw Errors.heicWrite();
    throw Errors.unsupported();
  }
  const removableBefore = countRemovable(before.records);
  if (removableBefore === 0) throw Errors.nothingRemovable();

  const written = await writeByFormat(before.format, buffer, 'strip', {}, before.orientation);
  return finalizeWrite(filename, before.format, before.records, written);
}

export async function editFile(filename: string, buffer: ArrayBuffer, edits: Record<string, string>): Promise<WriteResult> {
  const before = await parseFile(filename, buffer);
  if (!before.caps.edit) throw Errors.unsupported();
  const written = await writeByFormat(before.format, buffer, 'edit', edits, before.orientation);
  return finalizeWrite(filename, before.format, before.records, written);
}

async function writeByFormat(
  format: FormatId,
  buffer: ArrayBuffer,
  mode: 'strip' | 'edit',
  edits: Record<string, string> = {},
  orientation?: number,
): Promise<Uint8Array> {
  const handler = getHandler(format);
  if (!handler) throw Errors.unsupported();
  if (mode === 'strip') {
    if (!handler.strip) throw Errors.unsupported();
    return handler.strip(buffer, { orientation });
  }
  if (!handler.edit) throw Errors.unsupported();
  return handler.edit(buffer, edits);
}

async function finalizeWrite(
  filename: string,
  format: FormatId,
  before: ParseResult['records'],
  written: Uint8Array,
): Promise<WriteResult> {
  const magic = detectMagic(written);
  const zipOk = format === 'docx' || format === 'xlsx' || format === 'pptx';
  const stillOk =
    magic === format ||
    (format === 'mp3' && (magic === 'mp3' || magic === 'unknown')) ||
    (format === 'csv' && (magic === 'unknown' || magic === 'csv')) ||
    (format === 'svg' && (magic === 'svg' || magic === 'unknown')) ||
    (zipOk && (magic === 'unknown' || magic === format)) ||
    (format === 'm4a' && (magic === 'm4a' || magic === 'heic' || magic === 'video'));
  if (!stillOk && magic !== 'unknown') {
    throw Errors.invalidOutput();
  }
  if (zipOk) {
    try {
      const names = Object.keys((await JSZip.loadAsync(written)).files);
      if (refineZipFormat(names) !== format) throw Errors.invalidOutput();
    } catch (err) {
      if (err instanceof ScrubError) throw err;
      throw Errors.invalidOutput();
    }
  }

  const copy = copyToBuffer(written);
  let after: ParseResult;
  try {
    after = await parseFile(filename, copy);
  } catch {
    throw Errors.invalidOutput();
  }
  const remainingRemovable = countRemovable(after.records);
  const removedCount = Math.max(0, countRemovable(before) - remainingRemovable);
  const warnings: string[] = [];
  if (remainingRemovable > 0) {
    warnings.push(`Removed ${removedCount} fields; ${remainingRemovable} could not be stripped.`);
  }
  return {
    buffer: written,
    records: after.records,
    warnings,
    removedCount,
    remainingRemovable,
  };
}
