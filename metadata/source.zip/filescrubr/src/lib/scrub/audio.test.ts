import { describe, expect, it } from 'vitest';
import { ascii } from './bytes';
import { parseIsoMeta, stripIsoMeta } from './iso';

function be32(n: number): number[] {
  return [(n >>> 24) & 0xff, (n >>> 16) & 0xff, (n >>> 8) & 0xff, n & 0xff];
}

function box(type: string, payload: number[], largesize = false): number[] {
  const header = largesize ? 16 : 8;
  const size = header + payload.length;
  const typeBytes = [type.charCodeAt(0), type.charCodeAt(1), type.charCodeAt(2), type.charCodeAt(3)];
  if (!largesize) return [...be32(size), ...typeBytes, ...payload];
  return [...be32(1), ...typeBytes, ...be32(0), ...be32(size), ...payload];
}

describe('iso boxes', () => {
  it('reads 64-bit largesize so later metadata boxes are still found', () => {
    const udta = box('udta', [0, 0, 0, 0]);
    const mdat = box('mdat', new Array(32).fill(0x11), true);
    const ftyp = box('ftyp', [
      0x4d, 0x34, 0x41, 0x20,
      0, 0, 0, 0,
    ]);
    const buf = new Uint8Array([...ftyp, ...mdat, ...udta]);
    const before = parseIsoMeta(buf);
    expect(before.some((r) => r.key === 'udta')).toBe(true);
    const out = stripIsoMeta(buf);
    expect(ascii(out, mdat.length + ftyp.length + 4, 4)).toBe('free');
  });
});
