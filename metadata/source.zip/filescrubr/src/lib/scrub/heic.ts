import { parseWithExifr } from './records';
import { FORMAT_CAPS, type FormatHandler } from './types';

export const heicHandler: FormatHandler = {
  id: 'heic',
  caps: FORMAT_CAPS.heic,
  async parse(buffer) {
    const { records, orientation, warning } = await parseWithExifr(buffer);
    const warnings = warning ? [warning] : [];
    if (records.length === 0 && FORMAT_CAPS.heic.inspectOnlyReason) {
      warnings.push(FORMAT_CAPS.heic.inspectOnlyReason);
    }
    return { records, orientation, warnings };
  },
};
