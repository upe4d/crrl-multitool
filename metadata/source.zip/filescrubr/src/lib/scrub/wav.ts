import { ascii, concat, latin1, u32le, u8 } from './bytes';
import { rec } from './records';
import { filterRiff, walkRiff } from './riff';
import { FORMAT_CAPS, type FormatHandler, type MetadataRecord } from './types';

export function parseWav(buffer: ArrayBuffer | Uint8Array): MetadataRecord[] {
  const records: MetadataRecord[] = [];
  walkRiff(u8(buffer), 'WAVE', (id, data) => {
    if (id === 'LIST' && ascii(data, 0, 4) === 'INFO') {
      let i = 4;
      while (i + 8 <= data.length) {
        const key = ascii(data, i, 4);
        const size = u32le(data, i + 4);
        const val = latin1(data.subarray(i + 8, i + 8 + size)).replace(/\0+$/, '');
        records.push(rec('WAV', wavLabel(key), val, true, true));
        i += 8 + size + (size % 2);
      }
    }
    if (id === 'bext') {
      records.push(rec('WAV', 'bext', `[Broadcast Wave, ${data.length} bytes]`, false, true));
    }
    if (id === 'iXML') {
      records.push(rec('WAV', 'iXML', `[embedded, ${data.length} bytes]`, false, true));
    }
  });
  return records;
}

export function stripWav(buffer: ArrayBuffer | Uint8Array): Uint8Array {
  return filterRiff(u8(buffer), 'WAVE', (id, data) => {
    if (id === 'bext' || id === 'iXML' || id === '_axml') return false;
    if (id === 'LIST' && ascii(data, 0, 4) === 'INFO') return false;
    return true;
  });
}

export function applyWavEdits(buffer: ArrayBuffer | Uint8Array, edits: Record<string, string>): Uint8Array {
  const stripped = stripWav(buffer);
  const chunks: [string, string][] = [];
  const map: Record<string, string> = {
    title: 'INAM',
    artist: 'IART',
    album: 'IPRD',
    comment: 'ICMT',
    copyright: 'ICOP',
    software: 'ISFT',
    date: 'ICRD',
    INAM: 'INAM',
    IART: 'IART',
    IPRD: 'IPRD',
    ICMT: 'ICMT',
    ICOP: 'ICOP',
    ISFT: 'ISFT',
    ICRD: 'ICRD',
  };
  for (const [key, value] of Object.entries(edits)) {
    const id = map[key];
    if (!id || !value) continue;
    chunks.push([id, value]);
  }
  if (chunks.length === 0) return stripped;
  return insertListInfo(stripped, chunks);
}

function wavLabel(id: string): string {
  const labels: Record<string, string> = {
    INAM: 'title', IART: 'artist', IPRD: 'album', ICMT: 'comment', ICOP: 'copyright',
    ISFT: 'software', ICRD: 'date', IGNR: 'genre',
  };
  return labels[id] ?? id;
}

function insertListInfo(wav: Uint8Array, chunks: [string, string][]): Uint8Array {
  const pieces: Uint8Array[] = [new TextEncoder().encode('INFO')];
  for (const [id, value] of chunks) {
    const bytes = new TextEncoder().encode(value);
    const size = bytes.length + 1;
    const padded = size + (size % 2);
    const chunk = new Uint8Array(8 + padded);
    for (let i = 0; i < 4; i++) chunk[i] = id.charCodeAt(i);
    chunk[4] = size & 0xff;
    chunk[5] = (size >> 8) & 0xff;
    chunk.set(bytes, 8);
    pieces.push(chunk);
  }
  const listData = concat(pieces);
  const list = new Uint8Array(8 + listData.length);
  list.set([0x4c, 0x49, 0x53, 0x54]);
  new DataView(list.buffer).setUint32(4, listData.length, true);
  list.set(listData, 8);

  const parts: Uint8Array[] = [wav.subarray(8, 12)];
  let i = 12;
  let inserted = false;
  while (i + 8 <= wav.length) {
    const id = ascii(wav, i, 4);
    const size = u32le(wav, i + 4);
    const padded = size + (size % 2);
    const end = i + 8 + padded;
    if (id === 'fmt ' && !inserted) {
      parts.push(wav.subarray(i, Math.min(end, wav.length)));
      parts.push(list);
      inserted = true;
    } else {
      parts.push(wav.subarray(i, Math.min(end, wav.length)));
    }
    i = end;
  }
  if (!inserted) parts.push(list);
  const body = concat(parts);
  const out = new Uint8Array(8 + body.length);
  out.set([0x52, 0x49, 0x46, 0x46]);
  new DataView(out.buffer).setUint32(4, body.length, true);
  out.set(body, 8);
  return out;
}

export const wavHandler: FormatHandler = {
  id: 'wav',
  caps: FORMAT_CAPS.wav,
  parse(buffer) {
    return { records: parseWav(buffer) };
  },
  strip(buffer) {
    return stripWav(buffer);
  },
  edit(buffer, edits) {
    return applyWavEdits(buffer, edits);
  },
};
