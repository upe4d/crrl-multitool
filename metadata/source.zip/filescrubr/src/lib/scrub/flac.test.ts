import { describe, expect, it } from 'vitest';
import { parseFlac, stripFlac } from './flac';
import { sampleFlac } from './test-fixtures';
import { ascii } from './bytes';

describe('flac', () => {
  it('parses Vorbis TITLE', () => {
    expect(parseFlac(sampleFlac()).some((r) => r.key === 'TITLE' && r.value.includes('Secret'))).toBe(true);
  });

  it('strips Vorbis comments', () => {
    const out = stripFlac(sampleFlac());
    expect(ascii(out, 0, 4)).toBe('fLaC');
    expect(parseFlac(out).some((r) => r.key === 'TITLE')).toBe(false);
  });
});
