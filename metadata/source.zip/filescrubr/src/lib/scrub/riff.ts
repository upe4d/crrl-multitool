import { ascii, concat, u32le } from './bytes';
import { ScrubError } from './errors';

export function walkRiff(
  buf: Uint8Array,
  form: string,
  visit: (fourcc: string, data: Uint8Array) => void,
): void {
  if (ascii(buf, 0, 4) !== 'RIFF' || ascii(buf, 8, 4) !== form) {
    throw new ScrubError('parse_failed', `Not a valid ${form} file.`);
  }
  let i = 12;
  while (i + 8 <= buf.length) {
    const fourcc = ascii(buf, i, 4);
    const size = u32le(buf, i + 4);
    const start = i + 8;
    const end = start + size;
    if (end > buf.length) break;
    visit(fourcc, buf.subarray(start, end));
    i = start + size + (size % 2);
  }
}

export function filterRiff(
  buf: Uint8Array,
  form: string,
  keep: (id: string, data: Uint8Array) => boolean,
): Uint8Array {
  if (ascii(buf, 0, 4) !== 'RIFF' || ascii(buf, 8, 4) !== form) {
    throw new ScrubError('parse_failed', `Not a valid ${form} file.`);
  }
  const parts: Uint8Array[] = [buf.subarray(8, 12)];
  let i = 12;
  while (i + 8 <= buf.length) {
    const id = ascii(buf, i, 4);
    const size = u32le(buf, i + 4);
    const padded = size + (size % 2);
    const end = i + 8 + padded;
    if (end > buf.length) break;
    const data = buf.subarray(i + 8, i + 8 + size);
    if (keep(id, data)) parts.push(buf.subarray(i, Math.min(end, buf.length)));
    i = end;
  }
  const body = concat(parts);
  const out = new Uint8Array(8 + body.length);
  out.set([0x52, 0x49, 0x46, 0x46]);
  new DataView(out.buffer).setUint32(4, body.length, true);
  out.set(body, 8);
  return out;
}
