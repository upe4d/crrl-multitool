import { describe, expect, it } from 'vitest';
import { ascii } from './bytes';
import { applyPngEdits, parsePngText, stripPng } from './png';
import { pngChunk, samplePng } from './test-fixtures';

function typesOf(buf: Uint8Array): string[] {
  const types: string[] = [];
  let i = 8;
  while (i + 12 <= buf.length) {
    const len = ((buf[i]! << 24) | (buf[i + 1]! << 16) | (buf[i + 2]! << 8) | buf[i + 3]!) >>> 0;
    types.push(ascii(buf, i + 4, 4));
    i += 12 + len;
  }
  return types;
}

describe('png', () => {
  it('drops tEXt and keeps IHDR/IDAT', () => {
    const src = samplePng();
    expect(parsePngText(src).some((r) => r.key === 'Comment')).toBe(true);
    const out = stripPng(src);
    expect(ascii(out, 1, 3)).toBe('PNG');
    const types = typesOf(out);
    expect(types).toContain('IHDR');
    expect(types).toContain('IDAT');
    expect(types).toContain('IEND');
    expect(types).not.toContain('tEXt');
    expect(parsePngText(out)).toEqual([]);
  });

  it('applies tEXt edits', () => {
    const out = applyPngEdits(samplePng(), { Comment: 'Ada' });
    expect(parsePngText(out).some((r) => r.key === 'Comment' && r.value === 'Ada')).toBe(true);
  });

  it('rejects a high-bit chunk length instead of looping', () => {
    const sig = new Uint8Array([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);
    const ihdr = new Uint8Array(13);
    const bad = new Uint8Array(12);
    const view = new DataView(bad.buffer);
    view.setUint32(0, 0x80000000);
    bad.set(new TextEncoder().encode('tEXt'), 4);
    const parts = [sig, pngChunk('IHDR', ihdr), bad];
    const total = parts.reduce((n, p) => n + p.length, 0);
    const src = new Uint8Array(total);
    let o = 0;
    for (const p of parts) {
      src.set(p, o);
      o += p.length;
    }
    expect(() => parsePngText(src)).toThrow();
  });
});
