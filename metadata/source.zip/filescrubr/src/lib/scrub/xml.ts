export function escapeRe(value: string): string {
  return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

export function escapeXml(value: string): string {
  return value
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

export function xmlText(xml: string, tag: string): string | null {
  const re = new RegExp(`<${escapeRe(tag)}\\b[^>]*>([\\s\\S]*?)</${escapeRe(tag)}>`, 'i');
  const m = xml.match(re);
  if (!m) return null;
  const value = m[1]!.replace(/<[^>]+>/g, '').trim();
  return value || null;
}

export function setXmlText(xml: string, tag: string, value: string): string {
  const re = new RegExp(`<${escapeRe(tag)}\\b([^>]*)>([\\s\\S]*?)</${escapeRe(tag)}>`, 'i');
  if (re.test(xml)) {
    return xml.replace(re, value ? `<${tag}$1>${escapeXml(value)}</${tag}>` : `<${tag}$1/>`);
  }
  return xml;
}
