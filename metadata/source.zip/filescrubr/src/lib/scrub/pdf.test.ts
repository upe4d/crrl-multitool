import { describe, expect, it } from 'vitest';
import { applyPdfEdits, parsePdf, stripPdf } from './pdf';
import { sampleEncryptedPdf, samplePdf, toBuffer } from './test-fixtures';

describe('pdf', () => {
  it('parses Info dictionary fields', async () => {
    const records = await parsePdf(toBuffer(await samplePdf()));
    expect(records.some((r) => r.key === 'title' && r.value === 'Secret Title')).toBe(true);
    expect(records.some((r) => r.key === 'author' && r.value === 'Secret Author')).toBe(true);
  });

  it('strips identifying Info fields', async () => {
    const out = await stripPdf(toBuffer(await samplePdf()));
    const after = await parsePdf(toBuffer(out));
    expect(after.some((r) => r.key === 'title' && r.value === 'Secret Title')).toBe(false);
    expect(after.some((r) => r.key === 'author' && r.value === 'Secret Author')).toBe(false);
  });

  it('edits title and author', async () => {
    const out = await applyPdfEdits(toBuffer(await samplePdf()), { title: 'Ada', author: 'Lovelace' });
    const after = await parsePdf(toBuffer(out));
    expect(after.some((r) => r.key === 'title' && r.value === 'Ada')).toBe(true);
    expect(after.some((r) => r.key === 'author' && r.value === 'Lovelace')).toBe(true);
  });

  it('rejects encrypted PDFs', async () => {
    await expect(parsePdf(toBuffer(await sampleEncryptedPdf()))).rejects.toMatchObject({
      code: 'encrypted',
    });
  });
});
