import piexif from 'piexifjs';
import { concat, fromLatin1, latin1, u8 } from './bytes';
import { ScrubError } from './errors';
import { mergeWritable, parseWithExifr } from './records';
import { FORMAT_CAPS, type FormatHandler, type MetadataRecord } from './types';

const STRIP_MARKERS = new Set([0xe1, 0xed, 0xfe]);

export function jpegOrientation(records: MetadataRecord[]): number | undefined {
  const row = records.find((r) => r.key.toLowerCase() === 'orientation');
  if (!row) return undefined;
  const n = Number.parseInt(row.value, 10);
  if (Number.isFinite(n) && n >= 1 && n <= 8) return n;
  const mapped: Record<string, number> = {
    'horizontal (normal)': 1,
    'mirror horizontal': 2,
    'rotate 180': 3,
    'mirror vertical': 4,
    'mirror horizontal and rotate 270 cw': 5,
    'rotate 90 cw': 6,
    'mirror horizontal and rotate 90 cw': 7,
    'rotate 270 cw': 8,
  };
  return mapped[row.value.trim().toLowerCase()];
}

export function stripJpeg(buffer: ArrayBuffer | Uint8Array, orientation?: number): Uint8Array {
  const buf = u8(buffer);
  if (buf[0] !== 0xff || buf[1] !== 0xd8) {
    throw new ScrubError('parse_failed', 'Not a valid JPEG file.');
  }

  const parts: Uint8Array[] = [buf.subarray(0, 2)];
  if (orientation && orientation !== 1) parts.push(buildOrientationExif(orientation));

  let i = 2;
  while (i < buf.length) {
    if (buf[i] !== 0xff) {
      parts.push(buf.subarray(i));
      break;
    }
    while (i < buf.length && buf[i] === 0xff && buf[i + 1] === 0xff) i += 1;
    if (i + 1 >= buf.length) break;
    const marker = buf[i + 1]!;
    if (marker === 0xda) {
      parts.push(buf.subarray(i));
      break;
    }
    if (marker === 0xd9) {
      parts.push(buf.subarray(i, i + 2));
      break;
    }
    if ((marker >= 0xd0 && marker <= 0xd7) || marker === 0x01 || marker === 0xd8) {
      parts.push(buf.subarray(i, i + 2));
      i += 2;
      continue;
    }
    if (i + 3 >= buf.length) {
      parts.push(buf.subarray(i));
      break;
    }
    const len = (buf[i + 2]! << 8) | buf[i + 3]!;
    const end = i + 2 + len;
    if (end > buf.length) {
      throw new ScrubError('parse_failed', 'Could not read this file. It may be damaged or encrypted.');
    }
    if (!STRIP_MARKERS.has(marker)) parts.push(buf.subarray(i, end));
    i = end;
  }
  return concat(parts);
}

function buildOrientationExif(orientation: number): Uint8Array {
  const payload = new Uint8Array([
    0xff, 0xe1, 0x00, 0x1e,
    0x45, 0x78, 0x69, 0x66, 0x00, 0x00,
    0x49, 0x49, 0x2a, 0x00, 0x08, 0x00, 0x00, 0x00,
    0x01, 0x00,
    0x12, 0x01, 0x03, 0x00, 0x01, 0x00, 0x00, 0x00,
    orientation & 0xff, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00,
  ]);
  payload[3] = payload.length - 2;
  return payload;
}

function extractApp1(buf: Uint8Array): Uint8Array | null {
  let i = 2;
  while (i + 4 < buf.length && buf[i] === 0xff) {
    const marker = buf[i + 1]!;
    if (marker === 0xda || marker === 0xd9) break;
    if ((marker >= 0xd0 && marker <= 0xd7) || marker === 0x01) {
      i += 2;
      continue;
    }
    const len = (buf[i + 2]! << 8) | buf[i + 3]!;
    const end = i + 2 + len;
    if (marker === 0xe1 && asciiEquals(buf, i + 4, 'Exif')) return buf.subarray(i, end);
    i = end;
  }
  return null;
}

function asciiEquals(buf: Uint8Array, offset: number, text: string): boolean {
  for (let i = 0; i < text.length; i++) {
    if (buf[offset + i] !== text.charCodeAt(i)) return false;
  }
  return true;
}

const EDITABLE_JPEG: Record<string, { ifd: '0th' | 'Exif' | 'GPS'; tag: number }> = {
  ImageDescription: { ifd: '0th', tag: piexif.ImageIFD.ImageDescription },
  Make: { ifd: '0th', tag: piexif.ImageIFD.Make },
  Model: { ifd: '0th', tag: piexif.ImageIFD.Model },
  Artist: { ifd: '0th', tag: piexif.ImageIFD.Artist },
  Copyright: { ifd: '0th', tag: piexif.ImageIFD.Copyright },
  Software: { ifd: '0th', tag: piexif.ImageIFD.Software },
  DateTime: { ifd: '0th', tag: piexif.ImageIFD.DateTime },
  DateTimeOriginal: { ifd: 'Exif', tag: piexif.ExifIFD.DateTimeOriginal },
  DateTimeDigitized: { ifd: 'Exif', tag: piexif.ExifIFD.DateTimeDigitized },
  UserComment: { ifd: 'Exif', tag: piexif.ExifIFD.UserComment },
};

export function applyJpegEdits(buffer: ArrayBuffer | Uint8Array, edits: Record<string, string>): Uint8Array {
  const buf = u8(buffer);
  const app1 = extractApp1(buf);
  let exif: ReturnType<typeof piexif.load> = { '0th': {}, Exif: {}, GPS: {}, '1st': {}, thumbnail: undefined };
  if (app1) {
    const stub = concat([new Uint8Array([0xff, 0xd8]), app1, new Uint8Array([0xff, 0xd9])]);
    try {
      exif = piexif.load(latin1(stub));
    } catch {
      /* empty exif */
    }
  }
  for (const [key, value] of Object.entries(edits)) {
    const spec = EDITABLE_JPEG[key];
    if (!spec) continue;
    const ifd = exif[spec.ifd] as Record<number, unknown>;
    if (value.trim() === '') delete ifd[spec.tag];
    else ifd[spec.tag] = value;
  }
  const dumped = fromLatin1(piexif.dump(exif));
  const header = new Uint8Array(4 + dumped.length);
  header[0] = 0xff;
  header[1] = 0xe1;
  header[2] = ((dumped.length + 2) >> 8) & 0xff;
  header[3] = (dumped.length + 2) & 0xff;
  header.set(dumped, 4);
  const stripped = stripJpeg(buf);
  return concat([stripped.subarray(0, 2), header, stripped.subarray(2)]);
}

export function jpegWritableKeys(): string[] {
  return Object.keys(EDITABLE_JPEG);
}

export const jpegHandler: FormatHandler = {
  id: 'jpeg',
  caps: FORMAT_CAPS.jpeg,
  async parse(buffer) {
    const { records, orientation, warning } = await parseWithExifr(buffer);
    const merged = mergeWritable(records, jpegWritableKeys());
    return {
      records: merged,
      orientation: orientation ?? jpegOrientation(merged),
      warnings: warning ? [warning] : [],
    };
  },
  strip(buffer, ctx) {
    return stripJpeg(buffer, ctx?.orientation);
  },
  edit(buffer, edits) {
    return applyJpegEdits(buffer, edits);
  },
};
