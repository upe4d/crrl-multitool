import { PDFDocument, PDFName } from 'pdf-lib';
import { ScrubError } from './errors';
import { rec } from './records';
import { FORMAT_CAPS, type FormatHandler, type MetadataRecord } from './types';

const PDF_LIB_MARK = /pdf-lib/i;

export async function parsePdf(buffer: ArrayBuffer): Promise<MetadataRecord[]> {
  const pdf = await load(buffer);
  const records: MetadataRecord[] = [];
  push(records, 'title', pdf.getTitle(), true);
  push(records, 'author', pdf.getAuthor(), true);
  push(records, 'subject', pdf.getSubject(), true);
  push(records, 'keywords', pdf.getKeywords(), true);
  push(records, 'creator', identifying(pdf.getCreator()), true);
  push(records, 'producer', identifying(pdf.getProducer()), true);
  const created = pdf.getCreationDate();
  const modified = pdf.getModificationDate();
  if (created && isIdentifyingDate(created)) {
    records.push(rec('PDF', 'created', created.toISOString(), true, true));
  }
  if (modified && isIdentifyingDate(modified)) {
    records.push(rec('PDF', 'modified', modified.toISOString(), true, true));
  }
  return records;
}

export async function stripPdf(buffer: ArrayBuffer): Promise<Uint8Array> {
  const pdf = await load(buffer);
  pdf.setTitle('');
  pdf.setAuthor('');
  pdf.setSubject('');
  pdf.setKeywords([]);
  pdf.setCreator('');
  pdf.setProducer('');
  clearInfoKeys(pdf);
  return new Uint8Array(await pdf.save({ updateFieldAppearances: false }));
}

export async function applyPdfEdits(buffer: ArrayBuffer, edits: Record<string, string>): Promise<Uint8Array> {
  const pdf = await load(buffer);
  if ('title' in edits) pdf.setTitle(edits.title ?? '');
  if ('author' in edits) pdf.setAuthor(edits.author ?? '');
  if ('subject' in edits) pdf.setSubject(edits.subject ?? '');
  if ('keywords' in edits) pdf.setKeywords((edits.keywords ?? '').split(',').map((s) => s.trim()).filter(Boolean));
  if ('creator' in edits) pdf.setCreator(edits.creator ?? '');
  if ('producer' in edits) pdf.setProducer(edits.producer ?? '');
  if ('created' in edits && edits.created) {
    const d = new Date(edits.created);
    if (!Number.isNaN(d.valueOf())) pdf.setCreationDate(d);
  }
  if ('modified' in edits && edits.modified) {
    const d = new Date(edits.modified);
    if (!Number.isNaN(d.valueOf())) pdf.setModificationDate(d);
  }
  return new Uint8Array(await pdf.save({ updateFieldAppearances: false }));
}

async function load(buffer: ArrayBuffer): Promise<PDFDocument> {
  try {
    return await PDFDocument.load(buffer, { ignoreEncryption: false, updateMetadata: false });
  } catch (err) {
    const msg = err instanceof Error ? err.message : '';
    if (/encrypt|password/i.test(msg)) {
      throw new ScrubError('encrypted', 'This file is password-protected and cannot be opened here.');
    }
    throw new ScrubError('parse_failed', 'Could not read this PDF. It may be damaged or encrypted.');
  }
}

function identifying(value: string | undefined): string | undefined {
  if (!value?.trim()) return undefined;
  if (PDF_LIB_MARK.test(value)) return undefined;
  return value;
}

function isIdentifyingDate(date: Date): boolean {
  const t = date.getTime();
  if (!Number.isFinite(t) || t <= 0) return false;
  return date.getUTCFullYear() >= 1980;
}

function clearInfoKeys(pdf: PDFDocument) {
  const dict = (pdf as unknown as { getInfoDict: () => { delete: (name: ReturnType<typeof PDFName.of>) => void } }).getInfoDict();
  for (const key of ['Title', 'Author', 'Subject', 'Keywords', 'Creator', 'Producer', 'CreationDate', 'ModDate']) {
    dict.delete(PDFName.of(key));
  }
}

function push(records: MetadataRecord[], key: string, value: string | undefined, writable: boolean) {
  if (value) records.push(rec('PDF', key, value, writable, true));
}

export const pdfHandler: FormatHandler = {
  id: 'pdf',
  caps: FORMAT_CAPS.pdf,
  async parse(buffer) {
    return { records: await parsePdf(buffer) };
  },
  strip(buffer) {
    return stripPdf(buffer);
  },
  edit(buffer, edits) {
    return applyPdfEdits(buffer, edits);
  },
};
