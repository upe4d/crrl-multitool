import { describe, expect, it } from 'vitest';
import { Errors, ScrubError, asScrubError } from './errors';
import { FORMAT_CAPS } from './types';

const USER_VISIBLE = [
  Errors.tooLarge(50),
  Errors.multiple(),
  Errors.unsupported(),
  Errors.ole(),
  Errors.video(),
  Errors.damaged(),
  Errors.encrypted(),
  Errors.invalidOutput(),
  Errors.heicWrite(),
  Errors.nothingRemovable(),
  Errors.downloadFailed(),
  Errors.timeout(),
  Errors.worker(),
  Errors.generic(),
  Errors.busy(),
];

describe('asScrubError', () => {
  it('passes ScrubError through', () => {
    const err = Errors.unsupported();
    expect(asScrubError(err)).toBe(err);
  });

  it('maps encryption messages without leaking the library text as the hint', () => {
    const mapped = asScrubError(new Error('PDF is encrypted with a password'));
    expect(mapped).toBeInstanceOf(ScrubError);
    expect(mapped.code).toBe('encrypted');
    expect(mapped.hint).not.toMatch(/PDF is encrypted/i);
  });

  it('maps allocation failures to too_large', () => {
    const mapped = asScrubError(new RangeError('Array buffer allocation failed'));
    expect(mapped.code).toBe('too_large');
  });

  it('does not put raw parse messages in the user hint', () => {
    const mapped = asScrubError(new Error('piexifjs: invalid IFD'));
    expect(mapped.code).toBe('parse_failed');
    expect(mapped.hint).not.toContain('piexifjs');
    expect(mapped.hint).not.toContain('invalid IFD');
  });
});

describe('Errors catalog', () => {
  it('gives every user-visible error a message and recovery hint', () => {
    for (const err of USER_VISIBLE) {
      expect(err.message.length).toBeGreaterThan(0);
      expect(err.hint?.length).toBeGreaterThan(0);
    }
  });

  it('keeps aborted silent (no hint)', () => {
    expect(Errors.aborted().code).toBe('aborted');
    expect(Errors.aborted().hint).toBeUndefined();
  });

  it('reuses FORMAT_CAPS copy for inspect-only errors', () => {
    expect(Errors.ole().message).toBe(FORMAT_CAPS.ole.inspectOnlyReason);
    expect(Errors.ole().hint).toBe(FORMAT_CAPS.ole.inspectOnlyHint);
    expect(Errors.video().message).toBe(FORMAT_CAPS.video.inspectOnlyReason);
    expect(Errors.heicWrite().message).toBe(FORMAT_CAPS.heic.inspectOnlyReason);
    expect(Errors.unsupported().message).toBe(FORMAT_CAPS.unknown.inspectOnlyReason);
  });
});
