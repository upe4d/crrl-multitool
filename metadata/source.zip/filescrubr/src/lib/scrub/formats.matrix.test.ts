import { describe, expect, it } from 'vitest';
import { editFile, parseFile, stripFile } from './engine';
import { FORMAT_CAPS, type FormatId } from './types';
import { fixtureFor, sampleCsv, samplePng, toBuffer, truncated } from './test-fixtures';
import { countRemovable } from './records';

const REJECTS = new Set<FormatId>(['ole', 'video', 'unknown']);

const EDITS: Partial<Record<FormatId, { key: string; value: string }>> = {
  jpeg: { key: 'Artist', value: 'Ada Lovelace' },
  png: { key: 'Comment', value: 'Ada' },
  svg: { key: 'title', value: 'New Title' },
  mp3: { key: 'title', value: 'New Track' },
  wav: { key: 'title', value: 'New Wave' },
  docx: { key: 'title', value: 'New Doc' },
  xlsx: { key: 'title', value: 'New Sheet' },
  pptx: { key: 'title', value: 'New Deck' },
  pdf: { key: 'title', value: 'New Pdf' },
};

describe('FORMAT_CAPS matrix', () => {
  for (const format of Object.keys(FORMAT_CAPS) as FormatId[]) {
    const caps = FORMAT_CAPS[format];

    it(`${format}: parse matches caps.read`, async () => {
      const file = await fixtureFor(format);
      const buffer = toBuffer(file.bytes);
      if (REJECTS.has(format) || !caps.read) {
        await expect(parseFile(file.filename, buffer)).rejects.toMatchObject({
          code: format === 'ole' ? 'ole' : format === 'video' ? 'video' : 'unsupported',
        });
        return;
      }
      const parsed = await parseFile(file.filename, buffer);
      expect(parsed.format).toBe(format);
      expect(parsed.caps).toEqual(caps);
      expect(parsed.records.some((r) => r.group === 'File' && r.key === 'name')).toBe(true);
    });

    it(`${format}: strip matches caps.strip`, async () => {
      const file = await fixtureFor(format);
      const buffer = toBuffer(file.bytes);
      if (REJECTS.has(format) || !caps.read) {
        await expect(stripFile(file.filename, buffer)).rejects.toBeTruthy();
        return;
      }
      if (!caps.strip) {
        await expect(stripFile(file.filename, buffer)).rejects.toMatchObject({
          code: format === 'heic' ? 'heic_write' : 'unsupported',
        });
        return;
      }
      const before = await parseFile(file.filename, buffer);
      if (countRemovable(before.records) === 0) {
        await expect(stripFile(file.filename, buffer)).rejects.toMatchObject({ code: 'nothing_removable' });
        return;
      }
      const written = await stripFile(file.filename, buffer);
      expect(written.remainingRemovable).toBe(0);
      expect(written.removedCount).toBeGreaterThan(0);
    });

    it(`${format}: edit matches caps.edit`, async () => {
      const file = await fixtureFor(format);
      const buffer = toBuffer(file.bytes);
      const spec = EDITS[format];
      if (!caps.edit || !spec) {
        if (REJECTS.has(format) || !caps.read) {
          await expect(editFile(file.filename, buffer, { title: 'x' })).rejects.toBeTruthy();
          return;
        }
        await expect(editFile(file.filename, buffer, { title: 'x' })).rejects.toMatchObject({ code: 'unsupported' });
        return;
      }
      const written = await editFile(file.filename, buffer, { [spec.key]: spec.value });
      const row = written.records.find((r) => r.key === spec.key);
      expect(row?.value).toContain(spec.value);
    });
  }

  it('truncated PNG is parse_failed', async () => {
    await expect(parseFile('shot.png', toBuffer(truncated(samplePng(), 20)))).rejects.toMatchObject({
      code: 'parse_failed',
    });
  });

  it('CSV without BOM has nothing removable', async () => {
    const parsed = await parseFile('data.csv', toBuffer(sampleCsv(false)));
    expect(countRemovable(parsed.records)).toBe(0);
  });
});
