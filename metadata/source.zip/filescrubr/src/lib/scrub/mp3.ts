import { ascii, concat, latin1, u32le, u8 } from './bytes';
import { rec } from './records';
import { FORMAT_CAPS, type FormatHandler, type MetadataRecord } from './types';

const TEXT_FRAMES = new Set(['TIT2', 'TPE1', 'TALB', 'TCOP', 'TYER', 'TDRC', 'TCON', 'COMM', 'TCOM']);

export function parseMp3(buffer: ArrayBuffer | Uint8Array): MetadataRecord[] {
  const buf = u8(buffer);
  const records: MetadataRecord[] = [];
  if (ascii(buf, 0, 3) === 'ID3') {
    const size = synchsafe(buf, 6);
    const end = 10 + size;
    let i = 10;
    const major = buf[3] ?? 3;
    while (i + 10 <= end && i + 10 <= buf.length) {
      const id = ascii(buf, i, 4);
      if (!/^[A-Z0-9]{4}$/.test(id)) break;
      const frameSize = major === 4 ? synchsafe(buf, i + 4) : u32beSafe(buf, i + 4);
      const dataStart = i + 10;
      const dataEnd = dataStart + frameSize;
      if (dataEnd > buf.length) break;
      const writable = TEXT_FRAMES.has(id);
      records.push(rec('ID3', id3Label(id), decodeId3Text(buf.subarray(dataStart, dataEnd), id), writable, true));
      i = dataEnd;
    }
  }
  if (buf.length >= 128 && ascii(buf, buf.length - 128, 3) === 'TAG') {
    const tag = buf.subarray(buf.length - 128);
    pushIf(records, 'ID3v1', 'title', latin1(tag.subarray(3, 33)).trim(), true);
    pushIf(records, 'ID3v1', 'artist', latin1(tag.subarray(33, 63)).trim(), true);
    pushIf(records, 'ID3v1', 'album', latin1(tag.subarray(63, 93)).trim(), true);
    pushIf(records, 'ID3v1', 'year', latin1(tag.subarray(93, 97)).trim(), true);
    pushIf(records, 'ID3v1', 'comment', latin1(tag.subarray(97, 127)).trim(), true);
  }
  return records;
}

export function stripMp3(buffer: ArrayBuffer | Uint8Array): Uint8Array {
  let buf = u8(buffer);
  if (ascii(buf, 0, 3) === 'ID3') {
    const size = synchsafe(buf, 6);
    buf = buf.subarray(10 + size);
  }
  if (buf.length >= 128 && ascii(buf, buf.length - 128, 3) === 'TAG') {
    buf = buf.subarray(0, buf.length - 128);
  }
  if (buf.length >= 32 && ascii(buf, buf.length - 32, 8) === 'APETAGEX') {
    const len = u32le(buf, buf.length - 24);
    if (len > 0 && len < buf.length) buf = buf.subarray(0, buf.length - 32 - len);
  }
  return buf;
}

export function applyMp3Edits(buffer: ArrayBuffer | Uint8Array, edits: Record<string, string>): Uint8Array {
  const audio = stripMp3(buffer);
  const frames: Uint8Array[] = [];
  const map: Record<string, string> = {
    title: 'TIT2',
    artist: 'TPE1',
    album: 'TALB',
    copyright: 'TCOP',
    year: 'TYER',
    genre: 'TCON',
    comment: 'COMM',
    TIT2: 'TIT2',
    TPE1: 'TPE1',
    TALB: 'TALB',
    TCOP: 'TCOP',
    TYER: 'TYER',
    TCON: 'TCON',
    COMM: 'COMM',
  };
  for (const [key, value] of Object.entries(edits)) {
    const id = map[key] ?? (TEXT_FRAMES.has(key) ? key : '');
    if (!id || !value) continue;
    frames.push(makeId3Frame(id, value));
  }
  if (frames.length === 0) return audio;
  const body = concat(frames);
  const header = new Uint8Array(10);
  header.set([0x49, 0x44, 0x33, 3, 0, 0]);
  writeSynchsafe(header, 6, body.length);
  return concat([header, body, audio]);
}

function pushIf(records: MetadataRecord[], group: string, key: string, value: string, writable: boolean) {
  if (value) records.push(rec(group, key, value, writable, true));
}

function synchsafe(buf: Uint8Array, offset: number): number {
  return ((buf[offset]! & 0x7f) << 21) | ((buf[offset + 1]! & 0x7f) << 14) | ((buf[offset + 2]! & 0x7f) << 7) | (buf[offset + 3]! & 0x7f);
}

function u32beSafe(buf: Uint8Array, offset: number): number {
  return ((buf[offset]! << 24) | (buf[offset + 1]! << 16) | (buf[offset + 2]! << 8) | buf[offset + 3]!) >>> 0;
}

function writeSynchsafe(buf: Uint8Array, offset: number, value: number) {
  buf[offset] = (value >>> 21) & 0x7f;
  buf[offset + 1] = (value >>> 14) & 0x7f;
  buf[offset + 2] = (value >>> 7) & 0x7f;
  buf[offset + 3] = value & 0x7f;
}

function decodeId3Text(data: Uint8Array, id: string): string {
  if (data.length === 0) return `[${data.length} bytes]`;
  if (id === 'APIC') return `[embedded artwork, ${data.length} bytes]`;
  const enc = data[0];
  const body = data.subarray(id === 'COMM' ? skipCommPrefix(data) : 1);
  try {
    if (enc === 1) return new TextDecoder('utf-16').decode(body).replace(/\0/g, '').trim();
    if (enc === 2) return new TextDecoder('utf-16be').decode(body).replace(/\0/g, '').trim();
    if (enc === 3) return new TextDecoder('utf-8').decode(body).replace(/\0/g, '').trim();
    return latin1(body).replace(/\0/g, '').trim();
  } catch {
    return `[${data.length} bytes]`;
  }
}

function skipCommPrefix(data: Uint8Array): number {
  if (data.length < 5) return 1;
  let i = 4;
  if (data[0] === 1 || data[0] === 2) {
    while (i + 1 < data.length && !(data[i] === 0 && data[i + 1] === 0)) i += 2;
    return i + 2;
  }
  while (i < data.length && data[i] !== 0) i += 1;
  return i + 1;
}

function makeId3Frame(id: string, value: string): Uint8Array {
  const encoded = new TextEncoder().encode(value);
  const payload = new Uint8Array(1 + encoded.length);
  payload[0] = 3;
  payload.set(encoded, 1);
  const frame = new Uint8Array(10 + payload.length);
  for (let i = 0; i < 4; i++) frame[i] = id.charCodeAt(i);
  frame[4] = (payload.length >>> 24) & 0xff;
  frame[5] = (payload.length >>> 16) & 0xff;
  frame[6] = (payload.length >>> 8) & 0xff;
  frame[7] = payload.length & 0xff;
  frame.set(payload, 10);
  return frame;
}

function id3Label(id: string): string {
  const labels: Record<string, string> = {
    TIT2: 'title', TPE1: 'artist', TALB: 'album', TCOP: 'copyright', TYER: 'year',
    TDRC: 'year', TCON: 'genre', COMM: 'comment', TCOM: 'composer', APIC: 'artwork',
    PRIV: 'private', TXXX: 'custom',
  };
  return labels[id] ?? id;
}

export const mp3Handler: FormatHandler = {
  id: 'mp3',
  caps: FORMAT_CAPS.mp3,
  parse(buffer) {
    return { records: parseMp3(buffer) };
  },
  strip(buffer) {
    return stripMp3(buffer);
  },
  edit(buffer, edits) {
    return applyMp3Edits(buffer, edits);
  },
};
