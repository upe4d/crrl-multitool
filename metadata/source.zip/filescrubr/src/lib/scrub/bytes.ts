export function u8(buf: ArrayBuffer | Uint8Array): Uint8Array {
  return buf instanceof Uint8Array ? buf : new Uint8Array(buf);
}

export function ascii(buf: Uint8Array, start: number, len: number): string {
  let out = '';
  const end = Math.min(buf.length, start + len);
  for (let i = start; i < end; i++) out += String.fromCharCode(buf[i]!);
  return out;
}

export function latin1(buf: Uint8Array, start = 0, end = buf.length): string {
  let out = '';
  for (let i = start; i < end; i++) out += String.fromCharCode(buf[i]!);
  return out;
}

export function fromLatin1(text: string): Uint8Array {
  const out = new Uint8Array(text.length);
  for (let i = 0; i < text.length; i++) out[i] = text.charCodeAt(i) & 0xff;
  return out;
}

export function be16(buf: Uint8Array, offset: number): number {
  return (buf[offset]! << 8) | buf[offset + 1]!;
}

export function be32(buf: Uint8Array, offset: number): number {
  return ((buf[offset]! << 24) | (buf[offset + 1]! << 16) | (buf[offset + 2]! << 8) | buf[offset + 3]!) >>> 0;
}

export function u32be(buf: Uint8Array, offset: number): number {
  if (offset + 4 > buf.length) throw new RangeError('u32be: out of range');
  return be32(buf, offset);
}

export function u32le(buf: Uint8Array, offset: number): number {
  if (offset + 4 > buf.length) throw new RangeError('u32le: out of range');
  return (
    (buf[offset]! |
      (buf[offset + 1]! << 8) |
      (buf[offset + 2]! << 16) |
      (buf[offset + 3]! << 24)) >>>
    0
  );
}

export function concat(parts: Uint8Array[]): Uint8Array {
  const total = parts.reduce((n, p) => n + p.length, 0);
  const out = new Uint8Array(total);
  let o = 0;
  for (const p of parts) {
    out.set(p, o);
    o += p.length;
  }
  return out;
}

export function startsWith(buf: Uint8Array, sig: number[] | string, offset = 0): boolean {
  if (typeof sig === 'string') {
    if (offset + sig.length > buf.length) return false;
    for (let i = 0; i < sig.length; i++) {
      if (buf[offset + i] !== sig.charCodeAt(i)) return false;
    }
    return true;
  }
  if (offset + sig.length > buf.length) return false;
  return sig.every((b, i) => buf[offset + i] === b);
}

export function indexOfBytes(buf: Uint8Array, seq: number[] | string, from = 0): number {
  const needle = typeof seq === 'string'
    ? Array.from(seq, (c) => c.charCodeAt(0))
    : seq;
  outer: for (let i = from; i <= buf.length - needle.length; i++) {
    for (let j = 0; j < needle.length; j++) {
      if (buf[i + j] !== needle[j]) continue outer;
    }
    return i;
  }
  return -1;
}

export function decodeText(buf: Uint8Array): string {
  if (buf.length >= 3 && buf[0] === 0xef && buf[1] === 0xbb && buf[2] === 0xbf) {
    return new TextDecoder('utf-8').decode(buf.subarray(3));
  }
  if (buf.length >= 2 && buf[0] === 0xff && buf[1] === 0xfe) {
    return new TextDecoder('utf-16le').decode(buf.subarray(2));
  }
  if (buf.length >= 2 && buf[0] === 0xfe && buf[1] === 0xff) {
    return new TextDecoder('utf-16be').decode(buf.subarray(2));
  }
  return new TextDecoder('utf-8', { fatal: false }).decode(buf);
}

export function formatBytes(n: number): string {
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / (1024 * 1024)).toFixed(1)} MB`;
}

export function sanitizeBasename(name: string): string {
  const base = name.replace(/\\/g, '/').split('/').pop() ?? 'file';
  const cleaned = base.replace(/[<>:"/\\|?*\u0000-\u001f]/g, '_').trim() || 'file';
  return cleaned;
}

export function scrubbedName(filename: string, extension: string): string {
  const safe = sanitizeBasename(filename);
  const dot = safe.lastIndexOf('.');
  const stem = dot > 0 ? safe.slice(0, dot) : safe;
  const ext = extension.replace(/^\./, '');
  const already = stem.replace(/-scrubbed$/i, '');
  return `${already}-scrubbed.${ext}`;
}
