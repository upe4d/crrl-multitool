import { ascii, concat, u8 } from './bytes';
import { ScrubError } from './errors';
import { rec } from './records';
import { FORMAT_CAPS, type FormatHandler, type MetadataRecord } from './types';

export function parseFlac(buffer: ArrayBuffer | Uint8Array): MetadataRecord[] {
  const records: MetadataRecord[] = [];
  walkFlac(u8(buffer), (type, data) => {
    if (type === 4) records.push(...parseVorbisComment(data));
    if (type === 6) records.push(rec('FLAC', 'PICTURE', `[embedded, ${data.length} bytes]`, false, true));
  });
  return records;
}

export function stripFlac(buffer: ArrayBuffer | Uint8Array): Uint8Array {
  const buf = u8(buffer);
  if (ascii(buf, 0, 4) !== 'fLaC') throw new ScrubError('parse_failed', 'Not a valid FLAC file.');
  const out = [buf.subarray(0, 4)];
  let i = 4;
  while (i + 4 <= buf.length) {
    const last = (buf[i]! & 0x80) !== 0;
    const type = buf[i]! & 0x7f;
    const size = (buf[i + 1]! << 16) | (buf[i + 2]! << 8) | buf[i + 3]!;
    const end = i + 4 + size;
    if (end > buf.length) break;
    if (type === 4 || type === 6) {
      const pad = new Uint8Array(4 + size);
      pad[0] = (last ? 0x80 : 0) | 1;
      pad[1] = buf[i + 1]!;
      pad[2] = buf[i + 2]!;
      pad[3] = buf[i + 3]!;
      out.push(pad);
    } else {
      out.push(buf.subarray(i, end));
    }
    i = end;
    if (last) break;
  }
  out.push(buf.subarray(i));
  return concat(out);
}

function walkFlac(buf: Uint8Array, visit: (type: number, data: Uint8Array) => void) {
  if (ascii(buf, 0, 4) !== 'fLaC') throw new ScrubError('parse_failed', 'Not a valid FLAC file.');
  let i = 4;
  while (i + 4 <= buf.length) {
    const last = (buf[i]! & 0x80) !== 0;
    const type = buf[i]! & 0x7f;
    const size = (buf[i + 1]! << 16) | (buf[i + 2]! << 8) | buf[i + 3]!;
    const end = i + 4 + size;
    if (end > buf.length) break;
    visit(type, buf.subarray(i + 4, end));
    i = end;
    if (last) break;
  }
}

function parseVorbisComment(data: Uint8Array): MetadataRecord[] {
  const view = new DataView(data.buffer, data.byteOffset, data.byteLength);
  if (data.length < 8) return [];
  const vendorLen = view.getUint32(0, true);
  let o = 4 + vendorLen;
  if (o + 4 > data.length) return [];
  const count = view.getUint32(o, true);
  o += 4;
  const records: MetadataRecord[] = [];
  for (let n = 0; n < count && o + 4 <= data.length; n++) {
    const len = view.getUint32(o, true);
    o += 4;
    const text = new TextDecoder('utf-8').decode(data.subarray(o, o + len));
    o += len;
    const eq = text.indexOf('=');
    const key = eq >= 0 ? text.slice(0, eq) : text;
    const value = eq >= 0 ? text.slice(eq + 1) : '';
    records.push(rec('FLAC', key, value, false, true));
  }
  return records;
}

export const flacHandler: FormatHandler = {
  id: 'flac',
  caps: FORMAT_CAPS.flac,
  parse(buffer) {
    return { records: parseFlac(buffer) };
  },
  strip(buffer) {
    return stripFlac(buffer);
  },
};
