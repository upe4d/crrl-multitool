import type { FormatId } from './types';

export interface FormatCopyGroup {
  ids: FormatId[];
  label: string;
  summary: string;
}

export const FORMAT_COPY: FormatCopyGroup[] = [
  {
    ids: ['jpeg', 'png'],
    label: 'JPEG, PNG',
    summary: 'read, delete, and edit common tags. JPEG orientation is kept so photos do not rotate.',
  },
  {
    ids: ['webp', 'gif'],
    label: 'WebP, GIF',
    summary: 'read and delete metadata. Edit is not offered.',
  },
  {
    ids: ['svg'],
    label: 'SVG',
    summary: 'strip editor metadata, comments, and hidden layers; edit title and description.',
  },
  {
    ids: ['mp3', 'wav'],
    label: 'MP3, WAV',
    summary: 'read, delete, and edit common tags.',
  },
  {
    ids: ['m4a', 'flac'],
    label: 'M4A, FLAC',
    summary: 'read and delete; edit is not offered in this version.',
  },
  {
    ids: ['docx', 'xlsx', 'pptx'],
    label: 'DOCX, XLSX, PPTX',
    summary: 'read and delete Office properties; edit title, author, and related fields.',
  },
  {
    ids: ['csv'],
    label: 'CSV',
    summary: 'inspect BOM, delimiter, and headers; delete strips a UTF-8 BOM only.',
  },
  {
    ids: ['pdf'],
    label: 'PDF',
    summary: 'read, delete, and edit the Info dictionary.',
  },
  {
    ids: ['heic'],
    label: 'HEIC',
    summary: 'view tags when the browser can parse them. Rewriting is not supported; export JPEG first.',
  },
  {
    ids: ['ole'],
    label: '.doc, .xls, .ppt',
    summary: 'not supported. Save as .docx, .xlsx, or .pptx and drop again.',
  },
];

export function formatCopyLines(): string[] {
  return FORMAT_COPY.map((group) => `${group.label} — ${group.summary}`);
}

export function formatCopyPlain(): string {
  return FORMAT_COPY.map((group) => `${group.label} — ${group.summary}`).join(' ');
}

export function formatIdsInCopy(): FormatId[] {
  return FORMAT_COPY.flatMap((group) => group.ids);
}
