import { concat, latin1, u32be, u8 } from './bytes';
import { ScrubError } from './errors';
import { parseWithExifr, rec } from './records';
import { FORMAT_CAPS, type FormatHandler, type MetadataRecord } from './types';

const PNG_SIG = [0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a];
const DROP = new Set(['tEXt', 'iTXt', 'zTXt', 'tIME', 'eXIf']);
const CRC_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    table[n] = c >>> 0;
  }
  return table;
})();

function crc32(buf: Uint8Array): number {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]!) & 0xff]! ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

function typeAt(buf: Uint8Array, offset: number): string {
  return latin1(buf.subarray(offset, offset + 4));
}

export function parsePngText(buffer: ArrayBuffer | Uint8Array): MetadataRecord[] {
  const records: MetadataRecord[] = [];
  walkPng(u8(buffer), (type, data) => {
    if (type === 'tEXt') {
      const z = data.indexOf(0);
      if (z < 0) return;
      const key = latin1(data.subarray(0, z));
      const value = latin1(data.subarray(z + 1));
      records.push(rec('PNG', key, value, true, true));
    } else if (type === 'tIME') {
      records.push(rec('PNG', 'tIME', latin1(data), false, true));
    } else if (type === 'eXIf') {
      records.push(rec('PNG', 'eXIf', `[embedded, ${data.length} bytes]`, false, true));
    } else if (type === 'iTXt' || type === 'zTXt') {
      const z = data.indexOf(0);
      const key = z >= 0 ? latin1(data.subarray(0, z)) : type;
      records.push(rec('PNG', key, `[compressed text, ${data.length} bytes]`, false, true));
    }
  });
  return records;
}

export function stripPng(buffer: ArrayBuffer | Uint8Array): Uint8Array {
  return filterPng(u8(buffer), () => true);
}

export function applyPngEdits(buffer: ArrayBuffer | Uint8Array, edits: Record<string, string>): Uint8Array {
  const stripped = filterPng(u8(buffer), (type) => !DROP.has(type) || type === 'IHDR');
  const extras: Uint8Array[] = [];
  for (const [key, value] of Object.entries(edits)) {
    if (!value) continue;
    extras.push(makeTextChunk(key.replace(/[^\x20-\x7e]/g, '').slice(0, 79) || 'Comment', value));
  }
  return injectBeforeIend(stripped, extras);
}

function walkPng(buf: Uint8Array, visit: (type: string, data: Uint8Array) => void): void {
  if (buf.length < 8 || PNG_SIG.some((b, i) => buf[i] !== b)) {
    throw new ScrubError('parse_failed', 'Not a valid PNG file.');
  }
  let i = 8;
  while (i + 12 <= buf.length) {
    const len = u32be(buf, i);
    const type = typeAt(buf, i + 4);
    const dataStart = i + 8;
    const dataEnd = dataStart + len;
    if (dataEnd + 4 > buf.length) throw new ScrubError('parse_failed', 'Could not read this file. It may be damaged or encrypted.');
    visit(type, buf.subarray(dataStart, dataEnd));
    i = dataEnd + 4;
    if (type === 'IEND') break;
  }
}

function filterPng(buf: Uint8Array, keep: (type: string) => boolean): Uint8Array {
  if (buf.length < 8 || PNG_SIG.some((b, i) => buf[i] !== b)) {
    throw new ScrubError('parse_failed', 'Not a valid PNG file.');
  }
  const parts: Uint8Array[] = [buf.subarray(0, 8)];
  let i = 8;
  while (i + 12 <= buf.length) {
    const len = u32be(buf, i);
    const type = typeAt(buf, i + 4);
    const end = i + 12 + len;
    if (end > buf.length) throw new ScrubError('parse_failed', 'Could not read this file. It may be damaged or encrypted.');
    if (!DROP.has(type) && keep(type)) parts.push(buf.subarray(i, end));
    i = end;
    if (type === 'IEND') break;
  }
  return concat(parts);
}

function makeTextChunk(keyword: string, text: string): Uint8Array {
  const payload = new TextEncoder().encode(`${keyword}\0${text}`);
  const type = new TextEncoder().encode('tEXt');
  const body = concat([type, payload]);
  const crc = crc32(body);
  const out = new Uint8Array(12 + payload.length);
  const view = new DataView(out.buffer);
  view.setUint32(0, payload.length);
  out.set(body, 4);
  view.setUint32(8 + payload.length, crc);
  return out;
}

function injectBeforeIend(buf: Uint8Array, chunks: Uint8Array[]): Uint8Array {
  if (chunks.length === 0) return buf;
  let i = 8;
  while (i + 8 <= buf.length) {
    const len = u32be(buf, i);
    const type = typeAt(buf, i + 4);
    if (type === 'IEND') return concat([buf.subarray(0, i), ...chunks, buf.subarray(i)]);
    i += 12 + len;
  }
  return buf;
}

export const pngHandler: FormatHandler = {
  id: 'png',
  caps: FORMAT_CAPS.png,
  async parse(buffer) {
    const { records, orientation, warning } = await parseWithExifr(buffer);
    return {
      records: [...records, ...parsePngText(buffer)],
      orientation,
      warnings: warning ? [warning] : [],
    };
  },
  strip(buffer) {
    return stripPng(buffer);
  },
  edit(buffer, edits) {
    return applyPngEdits(buffer, edits);
  },
};
