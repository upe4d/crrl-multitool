import { describe, expect, it } from 'vitest';
import { parseCsv, stripCsv } from './csv';
import { countRemovable } from './records';

describe('csv', () => {
  it('strips a UTF-8 BOM', () => {
    const src = new TextEncoder().encode('\uFEFFname,city\nAda,London\n');
    expect(src[0]).toBe(0xef);
    const records = parseCsv(src);
    expect(countRemovable(records)).toBe(1);
    const out = stripCsv(src);
    expect(out[0]).toBe('n'.charCodeAt(0));
    expect(countRemovable(parseCsv(out))).toBe(0);
  });

  it('reports nothing removable when there is no BOM', () => {
    const src = new TextEncoder().encode('name,city\nAda,London\n');
    const records = parseCsv(src);
    expect(countRemovable(records)).toBe(0);
    expect(stripCsv(src)).toEqual(src);
  });
});
