import { ascii, u8 } from './bytes';
import { rec } from './records';
import { FORMAT_CAPS, type FormatHandler, type MetadataRecord } from './types';

export function stripIsoMeta(buffer: ArrayBuffer | Uint8Array): Uint8Array {
  const buf = u8(buffer).slice();
  freeBoxes(buf, 0, buf.length, new Set(['udta', 'meta', 'ilst', 'uuid', '©xyz', 'XMP_']));
  return buf;
}

export function parseIsoMeta(buffer: ArrayBuffer | Uint8Array): MetadataRecord[] {
  const records: MetadataRecord[] = [];
  const raw = u8(buffer);
  walkBoxes(raw, 0, raw.length, (type, data) => {
    if (type === 'udta' || type === 'meta' || type === 'ilst') {
      records.push(rec('M4A', type, `[${data.length} bytes]`, false, true));
    }
    if (type === '©nam' || type === '©ART' || type === '©alb' || type === '©cmt') {
      records.push(rec('M4A', type, decodeBoxText(data), false, true));
    }
  });
  return records;
}

function readBoxHeader(buf: Uint8Array, i: number, end: number): { size: number; header: number } | null {
  if (i + 8 > end) return null;
  let size = ((buf[i]! << 24) | (buf[i + 1]! << 16) | (buf[i + 2]! << 8) | buf[i + 3]!) >>> 0;
  let header = 8;
  if (size === 1) {
    if (i + 16 > end) return null;
    const hi = ((buf[i + 8]! << 24) | (buf[i + 9]! << 16) | (buf[i + 10]! << 8) | buf[i + 11]!) >>> 0;
    const lo = ((buf[i + 12]! << 24) | (buf[i + 13]! << 16) | (buf[i + 14]! << 8) | buf[i + 15]!) >>> 0;
    if (hi !== 0) return null;
    size = lo;
    header = 16;
  }
  if (size === 0) size = end - i;
  return { size, header };
}

function walkBoxes(buf: Uint8Array, start: number, end: number, visit: (type: string, data: Uint8Array) => void) {
  let i = start;
  while (i + 8 <= end) {
    const header = readBoxHeader(buf, i, end);
    if (!header) break;
    const { size, header: headerLen } = header;
    const type = ascii(buf, i + 4, 4);
    if (size < headerLen || i + size > end) break;
    const data = buf.subarray(i + headerLen, i + size);
    visit(type, data);
    if (type === 'moov' || type === 'trak' || type === 'mdia' || type === 'udta' || type === 'meta' || type === 'ilst') {
      const innerStart = type === 'meta' ? 4 : 0;
      walkBoxes(data, innerStart, data.length, visit);
    }
    i += size;
  }
}

function freeBoxes(buf: Uint8Array, start: number, end: number, types: Set<string>) {
  let i = start;
  while (i + 8 <= end) {
    const header = readBoxHeader(buf, i, end);
    if (!header) break;
    const { size, header: headerLen } = header;
    const type = ascii(buf, i + 4, 4);
    if (size < headerLen || i + size > end) break;
    if (types.has(type)) {
      buf[i + 4] = 0x66;
      buf[i + 5] = 0x72;
      buf[i + 6] = 0x65;
      buf[i + 7] = 0x65;
      buf.fill(0, i + headerLen, i + size);
    } else if (type === 'moov' || type === 'trak' || type === 'mdia' || type === 'udta' || type === 'meta') {
      const inner = type === 'meta' ? i + headerLen + 4 : i + headerLen;
      freeBoxes(buf, inner, i + size, types);
    }
    i += size;
  }
}

function decodeBoxText(data: Uint8Array): string {
  const idx = data.indexOf(0);
  const start = idx >= 0 ? idx + 1 : 0;
  try {
    return new TextDecoder('utf-8').decode(data.subarray(start)).replace(/\0/g, '').trim() || `[${data.length} bytes]`;
  } catch {
    return `[${data.length} bytes]`;
  }
}

export const m4aHandler: FormatHandler = {
  id: 'm4a',
  caps: FORMAT_CAPS.m4a,
  parse(buffer) {
    return { records: parseIsoMeta(buffer) };
  },
  strip(buffer) {
    return stripIsoMeta(buffer);
  },
};
