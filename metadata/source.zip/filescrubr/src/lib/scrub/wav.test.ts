import { describe, expect, it } from 'vitest';
import { applyWavEdits, parseWav, stripWav } from './wav';
import { sampleWav } from './test-fixtures';
import { ascii } from './bytes';

describe('wav', () => {
  it('parses LIST INFO title', () => {
    expect(parseWav(sampleWav()).some((r) => r.key === 'title' && r.value.includes('Secret'))).toBe(true);
  });

  it('strips LIST INFO', () => {
    const out = stripWav(sampleWav());
    expect(ascii(out, 0, 4)).toBe('RIFF');
    expect(ascii(out, 8, 4)).toBe('WAVE');
    expect(parseWav(out)).toEqual([]);
  });

  it('writes a new title', () => {
    const out = applyWavEdits(sampleWav(), { title: 'Ada' });
    expect(parseWav(out).some((r) => r.key === 'title' && r.value === 'Ada')).toBe(true);
  });
});
