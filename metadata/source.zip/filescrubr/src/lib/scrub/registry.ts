import { jpegHandler } from './jpeg';
import { pngHandler } from './png';
import { webpHandler } from './webp';
import { gifHandler } from './gif';
import { svgHandler } from './svg';
import { mp3Handler } from './mp3';
import { wavHandler } from './wav';
import { m4aHandler } from './iso';
import { flacHandler } from './flac';
import { csvHandler } from './csv';
import { ooxmlHandler } from './ooxml';
import { pdfHandler } from './pdf';
import { heicHandler } from './heic';
import type { FormatHandler, FormatId } from './types';

const HANDLERS: Partial<Record<FormatId, FormatHandler>> = {
  jpeg: jpegHandler,
  png: pngHandler,
  webp: webpHandler,
  gif: gifHandler,
  svg: svgHandler,
  mp3: mp3Handler,
  wav: wavHandler,
  m4a: m4aHandler,
  flac: flacHandler,
  docx: ooxmlHandler('docx'),
  xlsx: ooxmlHandler('xlsx'),
  pptx: ooxmlHandler('pptx'),
  csv: csvHandler,
  pdf: pdfHandler,
  heic: heicHandler,
};

export function getHandler(id: FormatId): FormatHandler | undefined {
  return HANDLERS[id];
}
