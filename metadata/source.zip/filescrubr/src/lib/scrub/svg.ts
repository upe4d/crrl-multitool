import { decodeText, u8 } from './bytes';
import { rec } from './records';
import { FORMAT_CAPS, type FormatHandler, type MetadataRecord } from './types';
import { escapeXml } from './xml';

const COMMENT_RE = /<!--[\s\S]*?-->/g;
const METADATA_RE = /<metadata\b[\s\S]*?<\/metadata>/gi;
const TITLE_RE = /<title\b[^>]*>([\s\S]*?)<\/title>/i;
const DESC_RE = /<desc\b[^>]*>([\s\S]*?)<\/desc>/i;
const INK_ATTR = /\s+inkscape:[^\s=>]+(?:=(?:"[^"]*"|'[^']*'|[^\s>]+))?/gi;
const SODI_ATTR = /\s+sodipodi:[^\s=>]+(?:=(?:"[^"]*"|'[^']*'|[^\s>]+))?/gi;
const XMLNS_INK = /\s+xmlns:inkscape="[^"]*"/gi;
const XMLNS_SODI = /\s+xmlns:sodipodi="[^"]*"/gi;
const HIDDEN_TAG = /<([a-zA-Z][\w:-]*)([^>]*?(?:display\s*:\s*none|visibility\s*:\s*hidden)[^>]*)>([\s\S]*?)<\/\1>/gi;
const CREATOR_RE = /<(?:dc:creator|cc:attributionName|sodipodi:namedview)\b[\s\S]*?<\/(?:dc:creator|cc:attributionName|sodipodi:namedview)>/gi;
const SCRIPT_BLOCK = /<script\b[^>]*>[\s\S]*?<\/script>/gi;
const SCRIPT_SELF = /<script\b[^>]*\/>/gi;
const EVENT_ATTR = /\s+on[a-zA-Z]+\s*=\s*(?:"[^"]*"|'[^']*'|[^\s>]+)/g;
const JS_URL_ATTR = /(\s(?:href|xlink:href|src)\s*=\s*)(["']?)javascript:[^"'>\s]*/gi;

export function hasActiveContent(text: string): boolean {
  return /<script\b/i.test(text) || /\son[a-zA-Z]+\s*=/i.test(text) || /javascript:/i.test(text);
}

function innerText(xml: string, re: RegExp): string | null {
  const m = xml.match(re);
  if (!m) return null;
  return m[1]!.replace(/<[^>]+>/g, '').trim();
}

export function parseSvg(text: string): MetadataRecord[] {
  const records: MetadataRecord[] = [];
  const title = innerText(text, TITLE_RE);
  const desc = innerText(text, DESC_RE);
  if (title) records.push(rec('SVG', 'title', title, true, false));
  if (desc) records.push(rec('SVG', 'desc', desc, true, false));
  if (/<metadata\b/i.test(text)) {
    records.push(rec('SVG', 'metadata', '[XML metadata block]', false, true));
  }
  if (/inkscape:/i.test(text) || /sodipodi:/i.test(text)) {
    records.push(rec('SVG', 'editor attributes', 'Inkscape / Sodipodi attributes present', false, true));
  }
  if (/display\s*:\s*none|visibility\s*:\s*hidden/i.test(text)) {
    records.push(rec('SVG', 'hidden layers', 'Elements marked hidden are still in the file', false, true));
  }
  const comments = text.match(COMMENT_RE);
  if (comments?.length) {
    records.push(rec('SVG', 'comments', `${comments.length} XML comment(s)`, false, true));
  }
  if (hasActiveContent(text)) {
    records.push(rec('SVG', 'active content', 'Script, event handlers, or javascript: URLs present', false, true));
  }
  return records;
}

export function stripSvg(text: string): string {
  let out = text.replace(COMMENT_RE, '');
  out = out.replace(METADATA_RE, '');
  out = out.replace(CREATOR_RE, '');
  out = out.replace(HIDDEN_TAG, '');
  out = out.replace(INK_ATTR, '');
  out = out.replace(SODI_ATTR, '');
  out = out.replace(XMLNS_INK, '');
  out = out.replace(XMLNS_SODI, '');
  out = out.replace(SCRIPT_BLOCK, '');
  out = out.replace(SCRIPT_SELF, '');
  out = out.replace(EVENT_ATTR, '');
  out = out.replace(JS_URL_ATTR, '$1$2');
  return out.trim() + '\n';
}

export function applySvgEdits(text: string, edits: Record<string, string>): string {
  let out = stripSvg(text);
  if ('title' in edits) {
    out = upsertTag(out, 'title', edits.title ?? '');
  }
  if ('desc' in edits) {
    out = upsertTag(out, 'desc', edits.desc ?? '');
  }
  return out;
}

function upsertTag(svg: string, tag: string, value: string): string {
  const re = new RegExp(`<${tag}\\b[^>]*>[\\s\\S]*?<\\/${tag}>`, 'i');
  const replacement = value ? `<${tag}>${escapeXml(value)}</${tag}>` : '';
  if (re.test(svg)) return svg.replace(re, replacement);
  if (!value) return svg;
  return svg.replace(/<svg\b[^>]*>/i, (open) => `${open}\n  ${replacement}`);
}

export const svgHandler: FormatHandler = {
  id: 'svg',
  caps: FORMAT_CAPS.svg,
  parse(buffer) {
    return { records: parseSvg(decodeText(u8(buffer))) };
  },
  strip(buffer) {
    return new TextEncoder().encode(stripSvg(decodeText(u8(buffer))));
  },
  edit(buffer, edits) {
    return new TextEncoder().encode(applySvgEdits(decodeText(u8(buffer)), edits));
  },
};
