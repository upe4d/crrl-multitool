import { decodeText, u8 } from './bytes';
import { rec } from './records';
import { FORMAT_CAPS, type FormatHandler, type MetadataRecord } from './types';

export function parseCsv(buffer: ArrayBuffer | Uint8Array): MetadataRecord[] {
  const buf = u8(buffer);
  const records: MetadataRecord[] = [];
  let bom = 'none';
  if (buf[0] === 0xef && buf[1] === 0xbb && buf[2] === 0xbf) bom = 'UTF-8';
  else if (buf[0] === 0xff && buf[1] === 0xfe) bom = 'UTF-16 LE';
  else if (buf[0] === 0xfe && buf[1] === 0xff) bom = 'UTF-16 BE';
  records.push(rec('CSV', 'BOM', bom, false, bom !== 'none'));

  const text = decodeText(buf);
  const first = text.split(/\r?\n/).find((line) => line.length > 0) ?? '';
  const comma = (first.match(/,/g) ?? []).length;
  const semi = (first.match(/;/g) ?? []).length;
  const tab = (first.match(/\t/g) ?? []).length;
  const delimiter = tab > comma && tab > semi ? 'tab' : semi > comma ? 'semicolon' : 'comma';
  records.push(rec('CSV', 'delimiter', delimiter, false, false));

  const sep = delimiter === 'tab' ? '\t' : delimiter === 'semicolon' ? ';' : ',';
  const headers = first.split(sep).slice(0, 20).map((h) => h.trim());
  if (headers.length) {
    records.push(rec('CSV', 'headers', headers.join(', '), false, false));
  }
  const rows = text.split(/\r?\n/).filter((l) => l.length > 0).length;
  records.push(rec('CSV', 'rows', String(rows), false, false));
  return records;
}

export function stripCsv(buffer: ArrayBuffer | Uint8Array): Uint8Array {
  const buf = u8(buffer);
  if (buf[0] === 0xef && buf[1] === 0xbb && buf[2] === 0xbf) return buf.subarray(3);
  if ((buf[0] === 0xff && buf[1] === 0xfe) || (buf[0] === 0xfe && buf[1] === 0xff)) return buf.subarray(2);
  return buf;
}

export const csvHandler: FormatHandler = {
  id: 'csv',
  caps: FORMAT_CAPS.csv,
  parse(buffer) {
    return { records: parseCsv(buffer) };
  },
  strip(buffer) {
    return stripCsv(buffer);
  },
};
