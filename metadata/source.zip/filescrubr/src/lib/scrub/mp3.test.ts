import { describe, expect, it } from 'vitest';
import { applyMp3Edits, parseMp3, stripMp3 } from './mp3';
import { sampleMp3 } from './test-fixtures';
import { ascii } from './bytes';

describe('mp3', () => {
  it('parses ID3v2 title and ID3v1 tags', () => {
    const records = parseMp3(sampleMp3());
    expect(records.some((r) => r.key === 'title' && r.value.includes('Secret'))).toBe(true);
  });

  it('strips ID3v2 and ID3v1', () => {
    const out = stripMp3(sampleMp3());
    expect(ascii(out, 0, 3)).not.toBe('ID3');
    expect(ascii(out, out.length - 128, 3)).not.toBe('TAG');
    expect(parseMp3(out)).toEqual([]);
  });

  it('writes a new title', () => {
    const out = applyMp3Edits(sampleMp3(), { title: 'Ada' });
    expect(parseMp3(out).some((r) => r.key === 'title' && r.value === 'Ada')).toBe(true);
  });
});
