import { describe, expect, it } from 'vitest';
import { countRemovable, fileRecords, mergeWritable, rec } from './records';

describe('records', () => {
  it('builds non-removable file rows', () => {
    const rows = fileRecords('shot.png', 'png', 12);
    expect(rows).toHaveLength(3);
    expect(rows.every((r) => !r.removable && !r.writable)).toBe(true);
  });

  it('counts removable fields', () => {
    const rows = [rec('PNG', 'Comment', 'x', true, true), rec('File', 'name', 'a', false, false)];
    expect(countRemovable(rows)).toBe(1);
  });

  it('marks listed keys writable', () => {
    const rows = [rec('EXIF', 'Artist', 'A', false, true), rec('EXIF', 'Make', 'M', false, true)];
    const merged = mergeWritable(rows, ['Artist']);
    expect(merged.find((r) => r.key === 'Artist')?.writable).toBe(true);
    expect(merged.find((r) => r.key === 'Make')?.writable).toBe(false);
  });
});
