import type { FormatId } from './types';
import { ascii, startsWith, u8 } from './bytes';

const JPEG = [0xff, 0xd8, 0xff];
const PNG = [0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a];
const PDF = [0x25, 0x50, 0x44, 0x46];
const ZIP = [0x50, 0x4b, 0x03, 0x04];
const OLE = [0xd0, 0xcf, 0x11, 0xe0, 0xa1, 0xb1, 0x1a, 0xe1];
const FLAC = [0x66, 0x4c, 0x61, 0x43];
const ID3 = [0x49, 0x44, 0x33];

function looksLikeMpeg(buf: Uint8Array): boolean {
  if (buf.length < 3) return false;
  return buf[0] === 0xff && (buf[1]! & 0xe0) === 0xe0;
}

interface Ftyp {
  major: string;
  compatible: string[];
}

function readFtyp(buf: Uint8Array): Ftyp | null {
  if (buf.length < 16 || ascii(buf, 4, 4) !== 'ftyp') return null;
  const size = ((buf[0]! << 24) | (buf[1]! << 16) | (buf[2]! << 8) | buf[3]!) >>> 0;
  const end = Math.min(buf.length, size || 16);
  const major = ascii(buf, 8, 4);
  const compatible: string[] = [];
  for (let i = 16; i + 4 <= end; i += 4) compatible.push(ascii(buf, i, 4));
  return { major, compatible };
}

function brandsOf(ftyp: Ftyp): string[] {
  return [ftyp.major, ...ftyp.compatible].map((b) => b.replace(/\0/g, ''));
}

const HEIC_BRANDS = new Set(['heic', 'heix', 'heif', 'hevc', 'mif1', 'msf1', 'heim', 'heis']);
const AUDIO_BRANDS = new Set(['M4A ', 'M4B ', 'M4P ', 'M4A']);
const VIDEO_BRANDS = new Set(['avc1', 'avc3', 'hev1', 'hvc1', 'vp09', 'av01', 'mp41', 'mp42', 'isom', 'iso2', 'iso4', 'iso5', 'iso6', 'dash', 'qt  ']);

export interface Detection {
  format: FormatId;
  fromMagic: boolean;
  extensionGuess: FormatId | null;
}

export function extensionFormat(filename: string): FormatId | null {
  const ext = filename.toLowerCase().split('.').pop() ?? '';
  switch (ext) {
    case 'jpg':
    case 'jpeg':
      return 'jpeg';
    case 'png':
      return 'png';
    case 'webp':
      return 'webp';
    case 'gif':
      return 'gif';
    case 'svg':
      return 'svg';
    case 'mp3':
      return 'mp3';
    case 'wav':
      return 'wav';
    case 'm4a':
    case 'm4b':
      return 'm4a';
    case 'flac':
      return 'flac';
    case 'docx':
      return 'docx';
    case 'xlsx':
      return 'xlsx';
    case 'pptx':
      return 'pptx';
    case 'csv':
      return 'csv';
    case 'pdf':
      return 'pdf';
    case 'heic':
    case 'heif':
      return 'heic';
    case 'doc':
    case 'xls':
    case 'ppt':
      return 'ole';
    case 'mp4':
    case 'm4v':
    case 'mov':
      return 'video';
    default:
      return null;
  }
}

function isoFormat(buf: Uint8Array): FormatId | null {
  const ftyp = readFtyp(buf);
  if (!ftyp) return null;
  const brands = brandsOf(ftyp);
  if (brands.some((b) => HEIC_BRANDS.has(b) || HEIC_BRANDS.has(b.toLowerCase()))) return 'heic';
  if (brands.some((b) => AUDIO_BRANDS.has(b) || b.startsWith('M4A'))) return 'm4a';
  if (brands.some((b) => VIDEO_BRANDS.has(b))) return 'video';
  return 'video';
}

export function detectMagic(buffer: ArrayBuffer | Uint8Array): FormatId {
  const buf = u8(buffer);
  if (buf.length < 8) return 'unknown';

  if (startsWith(buf, JPEG)) return 'jpeg';
  if (startsWith(buf, PNG)) return 'png';
  if (startsWith(buf, 'GIF87a') || startsWith(buf, 'GIF89a')) return 'gif';
  if (startsWith(buf, 'RIFF') && ascii(buf, 8, 4) === 'WEBP') return 'webp';
  if (startsWith(buf, 'RIFF') && ascii(buf, 8, 4) === 'WAVE') return 'wav';
  if (startsWith(buf, PDF)) return 'pdf';
  if (startsWith(buf, FLAC)) return 'flac';
  if (startsWith(buf, ID3) || looksLikeMpeg(buf)) return 'mp3';
  if (startsWith(buf, OLE)) return 'ole';

  const iso = isoFormat(buf);
  if (iso) return iso;

  if (startsWith(buf, ZIP)) return 'unknown';

  const head = new TextDecoder('utf-8', { fatal: false }).decode(buf.subarray(0, Math.min(buf.length, 256))).trimStart();
  if (head.startsWith('<svg') || (head.startsWith('<?xml') && head.includes('<svg'))) return 'svg';

  return 'unknown';
}

export function refineZipFormat(names: string[]): FormatId {
  const joined = names.join('\n').toLowerCase();
  if (joined.includes('word/document.xml')) return 'docx';
  if (joined.includes('xl/workbook.xml')) return 'xlsx';
  if (joined.includes('ppt/presentation.xml')) return 'pptx';
  return 'unknown';
}

export function detect(filename: string, buffer: ArrayBuffer | Uint8Array): Detection {
  const extensionGuess = extensionFormat(filename);
  const fromMagic = detectMagic(buffer);

  if (fromMagic === 'video' && extensionGuess === 'm4a') {
    return { format: 'm4a', fromMagic: true, extensionGuess };
  }
  if (fromMagic === 'unknown' && extensionGuess === 'csv') {
    return { format: 'csv', fromMagic: false, extensionGuess };
  }
  if (fromMagic === 'unknown' && extensionGuess === 'svg') {
    return { format: 'svg', fromMagic: false, extensionGuess };
  }
  if (fromMagic === 'unknown' && (extensionGuess === 'docx' || extensionGuess === 'xlsx' || extensionGuess === 'pptx')) {
    return { format: extensionGuess, fromMagic: false, extensionGuess };
  }
  return {
    format: fromMagic === 'unknown' ? (extensionGuess ?? 'unknown') : fromMagic,
    fromMagic: fromMagic !== 'unknown',
    extensionGuess,
  };
}

export function mimeFor(format: FormatId): string {
  switch (format) {
    case 'jpeg':
      return 'image/jpeg';
    case 'png':
      return 'image/png';
    case 'webp':
      return 'image/webp';
    case 'gif':
      return 'image/gif';
    case 'svg':
      return 'image/svg+xml';
    case 'mp3':
      return 'audio/mpeg';
    case 'wav':
      return 'audio/wav';
    case 'm4a':
      return 'audio/mp4';
    case 'flac':
      return 'audio/flac';
    case 'docx':
      return 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';
    case 'xlsx':
      return 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
    case 'pptx':
      return 'application/vnd.openxmlformats-officedocument.presentationml.presentation';
    case 'csv':
      return 'text/csv';
    case 'pdf':
      return 'application/pdf';
    case 'heic':
      return 'image/heic';
    default:
      return 'application/octet-stream';
  }
}

export function extFor(format: FormatId, filename: string): string {
  const fromName = filename.toLowerCase().split('.').pop();
  if (fromName && fromName.length <= 5) {
    if (format === 'jpeg' && (fromName === 'jpg' || fromName === 'jpeg')) return fromName;
    if (format === fromName || (format === 'm4a' && (fromName === 'm4a' || fromName === 'm4b'))) return fromName;
  }
  if (format === 'jpeg') return 'jpg';
  if (format === 'unknown' || format === 'ole' || format === 'video') return fromName || 'bin';
  return format;
}
