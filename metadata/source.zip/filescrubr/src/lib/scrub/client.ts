import { Errors, ScrubError, asScrubError } from './errors';
import type { WorkerOp, WorkerRequest, WorkerResponse } from './types';

const DEFAULT_TIMEOUT = 30_000;
const LARGE_TIMEOUT = 60_000;

export interface ScrubClientOptions {
  timeoutMs?: number;
  largeTimeoutMs?: number;
}

type Pending = {
  resolve: (value: WorkerResponse) => void;
  reject: (err: unknown) => void;
  timer: number;
};

export class ScrubClient {
  private worker: Worker | null = null;
  private workerFailed = false;
  private nextId = 1;
  private pending = new Map<number, Pending>();
  private warnedNoWorker = false;
  private jobAbort: AbortController | null = null;

  constructor(private readonly options: ScrubClientOptions = {}) {}

  get noWorker(): boolean {
    return this.workerFailed || typeof Worker === 'undefined';
  }

  get showedWorkerWarning(): boolean {
    return this.warnedNoWorker;
  }

  markWorkerWarningShown() {
    this.warnedNoWorker = true;
  }

  abortInFlight() {
    this.jobAbort?.abort();
    this.jobAbort = null;
    const hadPending = this.pending.size > 0;
    for (const [, job] of this.pending) {
      clearTimeout(job.timer);
      job.reject(Errors.aborted());
    }
    this.pending.clear();
    if (hadPending && this.worker) {
      this.worker.terminate();
      this.worker = null;
    }
  }

  reset() {
    this.abortInFlight();
    if (this.worker) {
      this.worker.terminate();
      this.worker = null;
    }
    this.workerFailed = false;
  }

  async run(op: WorkerOp, filename: string, buffer: ArrayBuffer, edits?: Record<string, string>): Promise<WorkerResponse> {
    this.abortInFlight();
    const abort = new AbortController();
    this.jobAbort = abort;
    const { signal } = abort;
    const throwIfAborted = () => {
      if (signal.aborted) throw Errors.aborted();
    };

    const id = this.nextId++;
    const timeout = buffer.byteLength > 20 * 1024 * 1024
      ? (this.options.largeTimeoutMs ?? LARGE_TIMEOUT)
      : (this.options.timeoutMs ?? DEFAULT_TIMEOUT);
    const request: WorkerRequest = { id, op, filename, buffer, edits };

    const worker = this.ensureWorker();
    if (!worker) {
      return this.runOnMain(request, signal);
    }

    try {
      const result = await this.runInWorker(worker, request, timeout, signal);
      throwIfAborted();
      return result;
    } catch (err) {
      throwIfAborted();
      const error = err instanceof ScrubError ? err : asScrubError(err);
      if (error.code === 'worker') {
        this.workerFailed = true;
        return this.runOnMain(request, signal);
      }
      throw error;
    }
  }

  private async runOnMain(request: WorkerRequest, signal: AbortSignal): Promise<WorkerResponse> {
    this.workerFailed = true;
    const { handleJob } = await import('./engine');
    if (signal.aborted) throw Errors.aborted();
    const result = await handleJob(request);
    if (signal.aborted) throw Errors.aborted();
    return result;
  }

  private ensureWorker(): Worker | null {
    if (this.workerFailed || typeof Worker === 'undefined') return null;
    if (this.worker) return this.worker;
    try {
      this.worker = new Worker(new URL('../../workers/scrub.worker.ts', import.meta.url), { type: 'module' });
      this.worker.onmessage = (event: MessageEvent<WorkerResponse>) => {
        const job = this.pending.get(event.data.id);
        if (!job) return;
        clearTimeout(job.timer);
        this.pending.delete(event.data.id);
        job.resolve(event.data);
      };
      this.worker.onerror = () => {
        this.failWorker(Errors.worker());
      };
      this.worker.onmessageerror = () => {
        this.failWorker(Errors.worker());
      };
      return this.worker;
    } catch {
      this.workerFailed = true;
      return null;
    }
  }

  private failWorker(err: ScrubError) {
    this.workerFailed = true;
    if (this.worker) {
      this.worker.terminate();
      this.worker = null;
    }
    for (const [, job] of this.pending) {
      clearTimeout(job.timer);
      job.reject(err);
    }
    this.pending.clear();
  }

  private async runInWorker(
    worker: Worker,
    request: WorkerRequest,
    timeout: number,
    signal: AbortSignal,
  ): Promise<WorkerResponse> {
    if (signal.aborted) throw Errors.aborted();
    return new Promise((resolve, reject) => {
      const onAbort = () => {
        clearTimeout(timer);
        this.pending.delete(request.id);
        reject(Errors.aborted());
      };
      signal.addEventListener('abort', onAbort, { once: true });
      const timer = window.setTimeout(() => {
        signal.removeEventListener('abort', onAbort);
        this.pending.delete(request.id);
        worker.terminate();
        this.worker = null;
        reject(Errors.timeout());
      }, timeout);
      this.pending.set(request.id, {
        resolve: (value) => {
          signal.removeEventListener('abort', onAbort);
          resolve(value);
        },
        reject: (err) => {
          signal.removeEventListener('abort', onAbort);
          reject(err);
        },
        timer,
      });
      worker.postMessage(request);
    });
  }
}
