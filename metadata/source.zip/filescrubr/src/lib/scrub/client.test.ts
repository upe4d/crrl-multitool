/** @vitest-environment jsdom */
import { afterEach, describe, expect, it, vi } from 'vitest';
import { ScrubClient } from '../../lib/scrub/client';
import { samplePng, toBuffer } from '../../lib/scrub/test-fixtures';

class HangWorker {
  constructor(_url?: URL | string, _opts?: WorkerOptions) {}
  onmessage: ((event: MessageEvent) => void) | null = null;
  onerror: ((event: Event) => void) | null = null;
  onmessageerror: ((event: Event) => void) | null = null;
  postMessage() {}
  terminate() {}
  addEventListener() {}
  removeEventListener() {}
  dispatchEvent() { return false; }
}

class CrashWorker extends HangWorker {
  postMessage() {
    queueMicrotask(() => this.onerror?.(new Event('error')));
  }
}

describe('ScrubClient', () => {
  afterEach(() => {
    vi.unstubAllGlobals();
  });

  it('falls back to handleJob when Worker is missing', async () => {
    vi.stubGlobal('Worker', undefined);
    const client = new ScrubClient();
    const res = await client.run('parse', 'shot.png', toBuffer(samplePng()));
    expect(res.ok).toBe(true);
    expect(res.format).toBe('png');
    expect(client.noWorker).toBe(true);
  });

  it('retries on the main thread after a worker crash', async () => {
    vi.stubGlobal('Worker', CrashWorker);
    const client = new ScrubClient();
    const res = await client.run('parse', 'shot.png', toBuffer(samplePng()));
    expect(res.ok).toBe(true);
    expect(res.format).toBe('png');
    expect(client.noWorker).toBe(true);
  });

  it('does not retry a timeout on the main thread', async () => {
    vi.stubGlobal('Worker', HangWorker);
    const client = new ScrubClient({ timeoutMs: 20 });
    await expect(client.run('parse', 'shot.png', toBuffer(samplePng()))).rejects.toMatchObject({
      code: 'timeout',
    });
  });
});
