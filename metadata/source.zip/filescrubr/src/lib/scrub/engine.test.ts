import { describe, expect, it } from 'vitest';
import { handleJob, parseFile, stripFile } from './engine';
import { parsePngText } from './png';
import { countRemovable } from './records';
import { ascii } from './bytes';
import { sampleCsv, sampleHeic, sampleOle, samplePng, sampleSvg, sampleUnknown, sampleVideo, toBuffer } from './test-fixtures';

describe('engine', () => {
  it('rejects unknown files', async () => {
    const res = await handleJob({
      id: 1,
      op: 'parse',
      filename: 'notes.bin',
      buffer: toBuffer(sampleUnknown()),
    });
    expect(res.ok).toBe(false);
    expect(res.error?.code).toBe('unsupported');
    expect(res.error?.hint).toBeTruthy();
  });

  it('rejects OLE magic as ole', async () => {
    await expect(parseFile('report.doc', toBuffer(sampleOle()))).rejects.toMatchObject({ code: 'ole' });
  });

  it('rejects video ftyp', async () => {
    await expect(parseFile('clip.mp4', toBuffer(sampleVideo()))).rejects.toMatchObject({ code: 'video' });
  });

  it('inspects HEIC without treating empty tags as unsupported', async () => {
    const parsed = await parseFile('photo.heic', toBuffer(sampleHeic()));
    expect(parsed.format).toBe('heic');
    expect(parsed.caps.strip).toBe(false);
    expect(parsed.warnings.length).toBeGreaterThan(0);
  });

  it('round-trips PNG strip through the engine', async () => {
    const src = samplePng();
    const before = await parseFile('shot.png', toBuffer(src));
    expect(before.records.some((r) => r.key === 'Comment')).toBe(true);
    expect(countRemovable(before.records)).toBeGreaterThan(0);
    const written = await stripFile('shot.png', toBuffer(src));
    expect(ascii(written.buffer, 1, 3)).toBe('PNG');
    expect(parsePngText(written.buffer).some((r) => r.key === 'Comment')).toBe(false);
    expect(written.removedCount).toBeGreaterThan(0);
    expect(written.remainingRemovable).toBe(0);
  });

  it('does not treat PNG IHDR fields as removable', async () => {
    const src = samplePng(false);
    const parsed = await parseFile('plain.png', toBuffer(src));
    for (const key of ['BitDepth', 'ColorType', 'Filter', 'Interlace']) {
      const row = parsed.records.find((r) => r.key === key);
      if (row) expect(row.removable).toBe(false);
    }
    expect(countRemovable(parsed.records)).toBe(0);
    await expect(stripFile('plain.png', toBuffer(src))).rejects.toMatchObject({ code: 'nothing_removable' });
  });

  it('does not treat SVG title and desc as removable', async () => {
    const src = sampleSvg('<title>Logo</title><desc>Mark</desc>');
    const parsed = await parseFile('logo.svg', toBuffer(src));
    expect(parsed.records.some((r) => r.key === 'title' && r.writable && !r.removable)).toBe(true);
    expect(parsed.records.some((r) => r.key === 'desc' && r.writable && !r.removable)).toBe(true);
    expect(countRemovable(parsed.records)).toBe(0);
    await expect(stripFile('logo.svg', toBuffer(src))).rejects.toMatchObject({ code: 'nothing_removable' });
  });

  it('still counts SVG comments as removable', async () => {
    const src = sampleSvg('<title>Logo</title><!-- secret -->');
    const parsed = await parseFile('logo.svg', toBuffer(src));
    expect(parsed.records.some((r) => r.key === 'comments' && r.removable)).toBe(true);
    expect(countRemovable(parsed.records)).toBeGreaterThan(0);
    const written = await stripFile('logo.svg', toBuffer(src));
    expect(written.removedCount).toBeGreaterThan(0);
    expect(written.remainingRemovable).toBe(0);
  });

  it('throws nothing_removable for a CSV without a BOM', async () => {
    await expect(stripFile('data.csv', toBuffer(sampleCsv(false)))).rejects.toMatchObject({ code: 'nothing_removable' });
  });

  it('strips a CSV BOM via stripFile', async () => {
    const written = await stripFile('data.csv', toBuffer(sampleCsv(true)));
    expect(written.buffer[0]).toBe('n'.charCodeAt(0));
    expect(written.remainingRemovable).toBe(0);
  });
});
