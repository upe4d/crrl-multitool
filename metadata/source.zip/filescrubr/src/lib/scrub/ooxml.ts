import JSZip from 'jszip';
import { ScrubError } from './errors';
import { FORMAT_CAPS, type FormatHandler, type FormatId, type MetadataRecord } from './types';
import { refineZipFormat } from './detect';
import { rec } from './records';
import { escapeRe, setXmlText, xmlText } from './xml';

const CORE_FIELDS: { tag: string; key: string; writable: boolean }[] = [
  { tag: 'dc:title', key: 'title', writable: true },
  { tag: 'dc:subject', key: 'subject', writable: true },
  { tag: 'dc:creator', key: 'creator', writable: true },
  { tag: 'dc:description', key: 'description', writable: true },
  { tag: 'cp:keywords', key: 'keywords', writable: true },
  { tag: 'cp:lastModifiedBy', key: 'lastModifiedBy', writable: true },
  { tag: 'cp:revision', key: 'revision', writable: false },
  { tag: 'cp:lastPrinted', key: 'lastPrinted', writable: false },
  { tag: 'cp:category', key: 'category', writable: true },
  { tag: 'cp:contentStatus', key: 'contentStatus', writable: true },
  { tag: 'dcterms:created', key: 'created', writable: false },
  { tag: 'dcterms:modified', key: 'modified', writable: false },
];

const APP_FIELDS = ['Application', 'Company', 'Manager', 'TotalTime', 'Template', 'AppVersion', 'PresentationFormat', 'HyperlinkBase'];
const MAX_ZIP_ENTRIES = 4096;

export async function parseOoxml(buffer: ArrayBuffer, hinted?: FormatId): Promise<{ format: FormatId; records: MetadataRecord[] }> {
  const zip = await unzip(buffer);
  const format = hinted && hinted !== 'unknown' ? hinted : refineZipFormat(Object.keys(zip.files));
  if (format === 'unknown') throw new ScrubError('unsupported', 'This ZIP archive is not a Word, Excel, or PowerPoint file.');
  const records: MetadataRecord[] = [];
  const core = await readFile(zip, 'docProps/core.xml');
  if (core) {
    for (const field of CORE_FIELDS) {
      const value = xmlText(core, field.tag);
      if (value) records.push(rec('Office', field.key, value, field.writable, true));
    }
  }
  const app = await readFile(zip, 'docProps/app.xml');
  if (app) {
    for (const tag of APP_FIELDS) {
      const value = xmlText(app, tag);
      if (!value) continue;
      if (tag === 'TotalTime' && value === '0') continue;
      const structural = tag === 'Application' || tag === 'AppVersion' || tag === 'PresentationFormat';
      records.push(rec('Office', tag, value, tag === 'Company' || tag === 'Manager', !structural));
    }
  }
  const custom = await readFile(zip, 'docProps/custom.xml');
  if (custom) records.push(rec('Office', 'custom.xml', 'Custom document properties present', false, true));
  if (zip.file(/comments.*\.xml$/i).length) {
    records.push(rec('Office', 'comments', 'Comment files present', false, true));
  }
  return { format, records };
}

export async function stripOoxml(buffer: ArrayBuffer): Promise<Uint8Array> {
  const zip = await unzip(buffer);
  await sanitizeCore(zip, {});
  await sanitizeApp(zip, true);
  const removed: string[] = [];
  const drop = (path: string) => {
    zip.remove(path);
    removed.push(path);
  };
  if (zip.file('docProps/custom.xml')) drop('docProps/custom.xml');
  for (const file of Object.keys(zip.files)) {
    if (/printerSettings/i.test(file) || /docProps\/thumbnail/i.test(file)) drop(file);
    if (/(^|\/)(comments|commentsExtended|commentsIds|commentsExtensible)[^/]*\.xml$/i.test(file)) drop(file);
  }
  await scrubPackagePointers(zip, removed);
  const word = await readFile(zip, 'word/document.xml');
  if (word) {
    zip.file('word/document.xml', word.replace(/\s+w:rsid\w*="[^"]*"/g, ''));
  }
  return zipToBytes(zip);
}

export async function applyOoxmlEdits(buffer: ArrayBuffer, edits: Record<string, string>): Promise<Uint8Array> {
  const zip = await unzip(buffer);
  await sanitizeCore(zip, edits);
  await sanitizeApp(zip, false, edits);
  return zipToBytes(zip);
}

async function unzip(buffer: ArrayBuffer): Promise<JSZip> {
  try {
    const zip = await JSZip.loadAsync(buffer);
    if (Object.keys(zip.files).length > MAX_ZIP_ENTRIES) {
      throw new ScrubError(
        'too_large',
        'This Office file has too many parts to process in the browser.',
        'Try a simpler document.',
      );
    }
    return zip;
  } catch (err) {
    if (err instanceof ScrubError) throw err;
    const msg = err instanceof Error ? err.message : '';
    if (/password|encrypt/i.test(msg)) {
      throw new ScrubError('encrypted', 'This file is password-protected and cannot be opened here.');
    }
    throw new ScrubError('parse_failed', 'Could not read this Office file. It may be damaged or encrypted.');
  }
}

async function readFile(zip: JSZip, path: string): Promise<string | null> {
  const file = zip.file(path);
  if (!file) return null;
  return file.async('string');
}

async function sanitizeCore(zip: JSZip, edits: Record<string, string>) {
  const core = await readFile(zip, 'docProps/core.xml');
  if (!core) return;
  let xml = core;
  const writable = CORE_FIELDS.filter((f) => f.writable);
  if (Object.keys(edits).length === 0) {
    for (const field of CORE_FIELDS) xml = setXmlText(xml, field.tag, '');
  } else {
    for (const field of writable) {
      if (field.key in edits) xml = setXmlText(xml, field.tag, edits[field.key] ?? '');
    }
  }
  zip.file('docProps/core.xml', xml);
}

async function sanitizeApp(zip: JSZip, blankAll: boolean, edits: Record<string, string> = {}) {
  const app = await readFile(zip, 'docProps/app.xml');
  if (!app) return;
  let xml = app;
  if (blankAll) {
    for (const tag of ['Company', 'Manager', 'HyperlinkBase', 'Template']) xml = setXmlText(xml, tag, '');
    xml = setXmlText(xml, 'TotalTime', '0');
  } else {
    if ('Company' in edits) xml = setXmlText(xml, 'Company', edits.Company ?? '');
    if ('Manager' in edits) xml = setXmlText(xml, 'Manager', edits.Manager ?? '');
  }
  zip.file('docProps/app.xml', xml);
}

async function zipToBytes(zip: JSZip): Promise<Uint8Array> {
  const buf = await zip.generateAsync({ type: 'uint8array', compression: 'DEFLATE' });
  return buf;
}

async function scrubPackagePointers(zip: JSZip, removed: string[]) {
  if (removed.length === 0) return;
  const parts = [...new Set(removed.map((p) => `/${p.replace(/^\/+/, '')}`))];
  const bases = [...new Set(removed.map((p) => p.split('/').pop()).filter((n): n is string => Boolean(n)))];
  for (const path of Object.keys(zip.files)) {
    const lower = path.replace(/\\/g, '/').toLowerCase();
    if (!(lower.endsWith('.rels') || lower.endsWith('[content_types].xml'))) continue;
    const file = zip.file(path);
    if (!file) continue;
    let xml = await file.async('string');
    const before = xml;
    for (const part of parts) {
      xml = xml.replace(new RegExp(`<Override\\b[^>]*PartName="${escapeRe(part)}"[^/]*/>`, 'gi'), '');
      xml = xml.replace(new RegExp(`<Override\\b[^>]*PartName="${escapeRe(part)}"[^>]*>\\s*</Override>`, 'gi'), '');
    }
    for (const name of bases) {
      xml = xml.replace(new RegExp(`<Relationship\\b[^>]*Target="[^"]*${escapeRe(name)}"[^/]*/>`, 'gi'), '');
      xml = xml.replace(new RegExp(`<Relationship\\b[^>]*Target="[^"]*${escapeRe(name)}"[^>]*>\\s*</Relationship>`, 'gi'), '');
    }
    xml = xml.replace(/<Relationship\b[^>]*Type="[^"]*(?:comments|custom-properties)[^"]*"[^/]*\/>/gi, '');
    xml = xml.replace(/<Relationship\b[^>]*Type="[^"]*(?:comments|custom-properties)[^"]*"[^>]*>\s*<\/Relationship>/gi, '');
    if (xml !== before) zip.file(path, xml);
  }
}

export function ooxmlHandler(id: 'docx' | 'xlsx' | 'pptx'): FormatHandler {
  return {
    id,
    caps: FORMAT_CAPS[id],
    async parse(buffer) {
      return { records: (await parseOoxml(buffer, id)).records };
    },
    strip(buffer) {
      return stripOoxml(buffer);
    },
    edit(buffer, edits) {
      return applyOoxmlEdits(buffer, edits);
    },
  };
}
