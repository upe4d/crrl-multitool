import JSZip from 'jszip';
import piexif from 'piexifjs';
import { PDFDocument } from 'pdf-lib';
import { fromLatin1 } from './bytes';

export function concatBytes(parts: Uint8Array[]): Uint8Array {
  const out = new Uint8Array(parts.reduce((n, p) => n + p.length, 0));
  let o = 0;
  for (const p of parts) {
    out.set(p, o);
    o += p.length;
  }
  return out;
}

export function toBuffer(u: Uint8Array): ArrayBuffer {
  return u.buffer.slice(u.byteOffset, u.byteOffset + u.byteLength) as ArrayBuffer;
}

export function truncated(u: Uint8Array, bytes = 12): Uint8Array {
  return u.subarray(0, Math.min(bytes, u.length));
}

export function sampleUnknown(): Uint8Array {
  return new Uint8Array([0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
}

export function sampleOle(): Uint8Array {
  return new Uint8Array([0xd0, 0xcf, 0x11, 0xe0, 0xa1, 0xb1, 0x1a, 0xe1, 0, 0, 0, 0]);
}

export function ftyp(major: string, compatible: string[] = []): Uint8Array {
  const size = 16 + compatible.length * 4;
  const out = new Uint8Array(Math.max(size, 12));
  out[0] = (size >>> 24) & 0xff;
  out[1] = (size >>> 16) & 0xff;
  out[2] = (size >>> 8) & 0xff;
  out[3] = size & 0xff;
  out.set([0x66, 0x74, 0x79, 0x70], 4);
  for (let i = 0; i < 4; i++) out[8 + i] = major.charCodeAt(i) || 0x20;
  compatible.forEach((brand, n) => {
    for (let i = 0; i < 4; i++) out[16 + n * 4 + i] = brand.charCodeAt(i) || 0x20;
  });
  return out;
}

export function sampleHeic(): Uint8Array {
  return ftyp('heic', ['mif1']);
}

export function sampleVideo(): Uint8Array {
  return ftyp('avc1', ['isom']);
}

const CRC_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    table[n] = c >>> 0;
  }
  return table;
})();

function crc32(buf: Uint8Array): number {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]!) & 0xff]! ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

export function pngChunk(type: string, data: Uint8Array): Uint8Array {
  const typeBytes = new TextEncoder().encode(type);
  const body = new Uint8Array(4 + data.length);
  body.set(typeBytes, 0);
  body.set(data, 4);
  const out = new Uint8Array(12 + data.length);
  const view = new DataView(out.buffer);
  view.setUint32(0, data.length);
  out.set(body, 4);
  view.setUint32(8 + data.length, crc32(body));
  return out;
}

export function samplePng(withText = true): Uint8Array {
  const sig = new Uint8Array([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);
  const ihdr = new Uint8Array(13);
  const ihdrView = new DataView(ihdr.buffer);
  ihdrView.setUint32(0, 1);
  ihdrView.setUint32(4, 1);
  ihdr[8] = 8;
  ihdr[9] = 2;
  const text = new TextEncoder().encode('Comment\0secret author');
  const idat = new Uint8Array([0x08, 0xd7, 0x63, 0xf8, 0xcf, 0xc0, 0x00, 0x00, 0x03, 0x01, 0x01, 0x00]);
  const parts = [sig, pngChunk('IHDR', ihdr)];
  if (withText) parts.push(pngChunk('tEXt', text));
  parts.push(pngChunk('IDAT', idat), pngChunk('IEND', new Uint8Array()));
  return concatBytes(parts);
}

export function sampleJpeg(orientation = 6): Uint8Array {
  const zeroth: Record<number, unknown> = {};
  zeroth[piexif.ImageIFD.Orientation] = orientation;
  zeroth[piexif.ImageIFD.Artist] = 'Secret Artist';
  zeroth[piexif.ImageIFD.Copyright] = 'Secret Corp';
  const dumped = fromLatin1(piexif.dump({
    '0th': zeroth,
    Exif: {},
    GPS: {},
    '1st': {},
    thumbnail: undefined,
  }));
  const app1 = new Uint8Array(4 + dumped.length);
  app1[0] = 0xff;
  app1[1] = 0xe1;
  app1[2] = ((dumped.length + 2) >> 8) & 0xff;
  app1[3] = (dumped.length + 2) & 0xff;
  app1.set(dumped, 4);
  const com = new Uint8Array([0xff, 0xfe, 0x00, 0x08, 0x68, 0x69, 0x00, 0x00, 0x00, 0x00]);
  const sos = new Uint8Array([0xff, 0xda, 0x00, 0x08, 0x01, 0x01, 0x00, 0x00, 0x3f, 0x00, 0x7f, 0xff, 0xd9]);
  return concatBytes([new Uint8Array([0xff, 0xd8]), app1, com, sos]);
}

export function sampleGif(): Uint8Array {
  return new Uint8Array([
    0x47, 0x49, 0x46, 0x38, 0x39, 0x61,
    0x01, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00,
    0x21, 0xfe, 0x07, 0x73, 0x65, 0x63, 0x72, 0x65, 0x74, 0x21, 0x00,
    0x2c, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x01, 0x00, 0x00,
    0x02, 0x02, 0x4c, 0x01, 0x00,
    0x3b,
  ]);
}

function riffWrap(form: string, chunks: Uint8Array[]): Uint8Array {
  const body = concatBytes([new TextEncoder().encode(form), ...chunks]);
  const out = new Uint8Array(8 + body.length);
  out.set([0x52, 0x49, 0x46, 0x46]);
  new DataView(out.buffer).setUint32(4, body.length, true);
  out.set(body, 8);
  return out;
}

function riffChunk(id: string, data: Uint8Array): Uint8Array {
  const padded = data.length + (data.length % 2);
  const out = new Uint8Array(8 + padded);
  for (let i = 0; i < 4; i++) out[i] = id.charCodeAt(i);
  new DataView(out.buffer).setUint32(4, data.length, true);
  out.set(data, 8);
  return out;
}

export function sampleWebp(): Uint8Array {
  const vp8 = riffChunk('VP8 ', new Uint8Array([0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]));
  const exif = riffChunk('EXIF', new Uint8Array([0x45, 0x78, 0x69, 0x66, 0x00, 0x00, 0x00, 0x00]));
  return riffWrap('WEBP', [vp8, exif]);
}

export function sampleWav(): Uint8Array {
  const fmt = riffChunk('fmt ', new Uint8Array(16));
  const data = riffChunk('data', new Uint8Array(8));
  const inam = new TextEncoder().encode('Secret Track');
  const infoPayload = concatBytes([
    new TextEncoder().encode('INFO'),
    riffChunk('INAM', concatBytes([inam, new Uint8Array([0])])),
  ]);
  const list = riffChunk('LIST', infoPayload);
  return riffWrap('WAVE', [fmt, list, data]);
}

export function sampleSvg(extra = '<!-- secret --><title>Logo</title>'): Uint8Array {
  return new TextEncoder().encode(`<svg xmlns="http://www.w3.org/2000/svg">${extra}</svg>`);
}

export function sampleCsv(withBom = true): Uint8Array {
  const body = 'name,city\nAda,London\n';
  return new TextEncoder().encode(withBom ? `\uFEFF${body}` : body);
}

function be32(n: number): number[] {
  return [(n >>> 24) & 0xff, (n >>> 16) & 0xff, (n >>> 8) & 0xff, n & 0xff];
}

function isoBox(type: string, payload: number[]): number[] {
  const size = 8 + payload.length;
  const typeBytes = [type.charCodeAt(0), type.charCodeAt(1), type.charCodeAt(2), type.charCodeAt(3)];
  return [...be32(size), ...typeBytes, ...payload];
}

export function sampleM4a(): Uint8Array {
  const ftypBytes = isoBox('ftyp', [0x4d, 0x34, 0x41, 0x20, 0, 0, 0, 0, 0x4d, 0x34, 0x41, 0x20]);
  const udta = isoBox('udta', [0, 0, 0, 0]);
  const mdat = isoBox('mdat', new Array(16).fill(0x11));
  return new Uint8Array([...ftypBytes, ...udta, ...mdat]);
}

function synchsafeBytes(value: number): number[] {
  return [(value >>> 21) & 0x7f, (value >>> 14) & 0x7f, (value >>> 7) & 0x7f, value & 0x7f];
}

export function sampleMp3(): Uint8Array {
  const title = new TextEncoder().encode('Secret Song');
  const payload = new Uint8Array(1 + title.length);
  payload[0] = 3;
  payload.set(title, 1);
  const frame = new Uint8Array(10 + payload.length);
  frame.set([0x54, 0x49, 0x54, 0x32]);
  frame[4] = (payload.length >>> 24) & 0xff;
  frame[5] = (payload.length >>> 16) & 0xff;
  frame[6] = (payload.length >>> 8) & 0xff;
  frame[7] = payload.length & 0xff;
  frame.set(payload, 10);
  const header = new Uint8Array([0x49, 0x44, 0x33, 3, 0, 0, ...synchsafeBytes(frame.length)]);
  const audio = new Uint8Array([0xff, 0xfb, 0x90, 0x00, 0x00, 0x00, 0x00, 0x00]);
  const tag = new Uint8Array(128);
  tag.set([0x54, 0x41, 0x47]);
  tag.set(new TextEncoder().encode('ID3v1 title'), 3);
  return concatBytes([header, frame, audio, tag]);
}

function flacBlock(type: number, last: boolean, data: Uint8Array): Uint8Array {
  const out = new Uint8Array(4 + data.length);
  out[0] = (last ? 0x80 : 0) | type;
  out[1] = (data.length >>> 16) & 0xff;
  out[2] = (data.length >>> 8) & 0xff;
  out[3] = data.length & 0xff;
  out.set(data, 4);
  return out;
}

export function sampleFlac(): Uint8Array {
  const streaminfo = new Uint8Array(34);
  const vendor = new TextEncoder().encode('test');
  const comment = new TextEncoder().encode('TITLE=Secret Flac');
  const vorbis = new Uint8Array(4 + vendor.length + 4 + 4 + comment.length);
  const view = new DataView(vorbis.buffer);
  view.setUint32(0, vendor.length, true);
  vorbis.set(vendor, 4);
  view.setUint32(4 + vendor.length, 1, true);
  view.setUint32(8 + vendor.length, comment.length, true);
  vorbis.set(comment, 12 + vendor.length);
  return concatBytes([
    new TextEncoder().encode('fLaC'),
    flacBlock(0, false, streaminfo),
    flacBlock(4, true, vorbis),
  ]);
}

async function sampleOoxml(kind: 'docx' | 'xlsx' | 'pptx'): Promise<Uint8Array> {
  const zip = new JSZip();
  const part = kind === 'docx' ? 'word/document.xml' : kind === 'xlsx' ? 'xl/workbook.xml' : 'ppt/presentation.xml';
  zip.file(
    '[Content_Types].xml',
    `<?xml version="1.0"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="xml" ContentType="application/xml"/><Override PartName="/${part}" ContentType="application/xml"/></Types>`,
  );
  zip.file(part, `<?xml version="1.0"?><root/>`);
  zip.file(
    'docProps/core.xml',
    `<?xml version="1.0"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/"><dc:title>Secret Title</dc:title><dc:creator>Secret Author</dc:creator><cp:lastModifiedBy>Editor</cp:lastModifiedBy></cp:coreProperties>`,
  );
  zip.file(
    'docProps/app.xml',
    `<?xml version="1.0"?><Properties><Application>Test</Application><Company>Secret Co</Company><Manager>Boss</Manager><TotalTime>12</TotalTime></Properties>`,
  );
  return zip.generateAsync({ type: 'uint8array' });
}

export function sampleDocx(): Promise<Uint8Array> {
  return sampleOoxml('docx');
}

export function sampleXlsx(): Promise<Uint8Array> {
  return sampleOoxml('xlsx');
}

export function samplePptx(): Promise<Uint8Array> {
  return sampleOoxml('pptx');
}

export async function samplePdf(): Promise<Uint8Array> {
  const pdf = await PDFDocument.create();
  pdf.addPage();
  pdf.setTitle('Secret Title');
  pdf.setAuthor('Secret Author');
  pdf.setSubject('Secret Subject');
  pdf.setKeywords(['secret']);
  pdf.setCreator('Secret Creator');
  pdf.setProducer('Secret Producer');
  pdf.setCreationDate(new Date('2020-01-01T00:00:00Z'));
  pdf.setModificationDate(new Date('2021-01-01T00:00:00Z'));
  return new Uint8Array(await pdf.save({ updateFieldAppearances: false }));
}

export async function sampleEncryptedPdf(): Promise<Uint8Array> {
  const pdf = await PDFDocument.create();
  pdf.addPage();
  pdf.setTitle('Locked');
  const encrypt = (pdf as unknown as { encrypt?: (opts: { userPassword: string; ownerPassword: string }) => void }).encrypt;
  if (typeof encrypt === 'function') {
    encrypt.call(pdf, { userPassword: 'secret', ownerPassword: 'secret' });
    return new Uint8Array(await pdf.save({ updateFieldAppearances: false }));
  }
  const raw = '%PDF-1.4\n1 0 obj<< /Encrypt 2 0 R >>endobj\n2 0 obj<< /Filter /Standard >>endobj\ntrailer<< /Root 1 0 R /Encrypt 2 0 R >>\n%%EOF\n';
  return new TextEncoder().encode(raw);
}

export type FixtureFile = {
  filename: string;
  mime: string;
  bytes: Uint8Array;
};

export async function fixtureFor(format: string): Promise<FixtureFile> {
  switch (format) {
    case 'jpeg':
      return { filename: 'photo.jpg', mime: 'image/jpeg', bytes: sampleJpeg() };
    case 'png':
      return { filename: 'shot.png', mime: 'image/png', bytes: samplePng() };
    case 'webp':
      return { filename: 'pic.webp', mime: 'image/webp', bytes: sampleWebp() };
    case 'gif':
      return { filename: 'anim.gif', mime: 'image/gif', bytes: sampleGif() };
    case 'svg':
      return { filename: 'logo.svg', mime: 'image/svg+xml', bytes: sampleSvg() };
    case 'mp3':
      return { filename: 'track.mp3', mime: 'audio/mpeg', bytes: sampleMp3() };
    case 'wav':
      return { filename: 'clip.wav', mime: 'audio/wav', bytes: sampleWav() };
    case 'm4a':
      return { filename: 'song.m4a', mime: 'audio/mp4', bytes: sampleM4a() };
    case 'flac':
      return { filename: 'song.flac', mime: 'audio/flac', bytes: sampleFlac() };
    case 'docx':
      return { filename: 'doc.docx', mime: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', bytes: await sampleDocx() };
    case 'xlsx':
      return { filename: 'sheet.xlsx', mime: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', bytes: await sampleXlsx() };
    case 'pptx':
      return { filename: 'deck.pptx', mime: 'application/vnd.openxmlformats-officedocument.presentationml.presentation', bytes: await samplePptx() };
    case 'csv':
      return { filename: 'data.csv', mime: 'text/csv', bytes: sampleCsv(true) };
    case 'pdf':
      return { filename: 'file.pdf', mime: 'application/pdf', bytes: await samplePdf() };
    case 'heic':
      return { filename: 'photo.heic', mime: 'image/heic', bytes: sampleHeic() };
    case 'ole':
      return { filename: 'report.doc', mime: 'application/msword', bytes: sampleOle() };
    case 'video':
      return { filename: 'clip.mp4', mime: 'video/mp4', bytes: sampleVideo() };
    default:
      return { filename: 'notes.bin', mime: 'application/octet-stream', bytes: sampleUnknown() };
  }
}
