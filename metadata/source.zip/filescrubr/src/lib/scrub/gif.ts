import { ascii, concat, latin1, u8 } from './bytes';
import { ScrubError } from './errors';
import { FORMAT_CAPS, type FormatHandler, type MetadataRecord } from './types';

export function parseGifMeta(buffer: ArrayBuffer | Uint8Array): MetadataRecord[] {
  const { comments } = scanGif(u8(buffer));
  return comments.map((value, i) => ({
    group: 'GIF',
    key: comments.length > 1 ? `Comment ${i + 1}` : 'Comment',
    value,
    writable: false,
    removable: true,
  }));
}

export function stripGif(buffer: ArrayBuffer | Uint8Array): Uint8Array {
  return scanGif(u8(buffer)).clean;
}

function scanGif(buf: Uint8Array): { comments: string[]; clean: Uint8Array } {
  if (!ascii(buf, 0, 6).startsWith('GIF8')) {
    throw new ScrubError('parse_failed', 'Not a valid GIF file.');
  }
  const comments: string[] = [];
  const parts: Uint8Array[] = [];
  let i = 6;
  parts.push(buf.subarray(0, 13));
  i = 13;
  const packed = buf[10]!;
  if (packed & 0x80) {
    const gct = 3 * (2 ** ((packed & 7) + 1));
    parts.push(buf.subarray(13, 13 + gct));
    i = 13 + gct;
  }
  while (i < buf.length) {
    const b = buf[i]!;
    if (b === 0x3b) {
      parts.push(buf.subarray(i, i + 1));
      break;
    }
    if (b === 0x2c) {
      if (i + 10 > buf.length) break;
      const lctPacked = buf[i + 9]!;
      let end = i + 10;
      if (lctPacked & 0x80) end += 3 * (2 ** ((lctPacked & 7) + 1));
      end += 1;
      end = skipSubBlocks(buf, end);
      parts.push(buf.subarray(i, end));
      i = end;
      continue;
    }
    if (b === 0x21) {
      const label = buf[i + 1];
      const start = i;
      i += 2;
      if (label === 0xfe) {
        const { text, next } = readSubBlocks(buf, i);
        comments.push(text);
        i = next;
        continue;
      }
      if (label === 0xff) {
        const blockSize = buf[i]!;
        const id = latin1(buf.subarray(i + 1, i + 1 + Math.min(blockSize, 11)));
        i = skipSubBlocks(buf, i);
        if (id.startsWith('XMP Data')) continue;
        parts.push(buf.subarray(start, i));
        continue;
      }
      i = skipSubBlocks(buf, i);
      parts.push(buf.subarray(start, i));
      continue;
    }
    i += 1;
  }
  return { comments, clean: concat(parts) };
}

function skipSubBlocks(buf: Uint8Array, start: number): number {
  let i = start;
  while (i < buf.length) {
    const size = buf[i]!;
    if (size === 0) return i + 1;
    i += 1 + size;
  }
  return buf.length;
}

function readSubBlocks(buf: Uint8Array, start: number): { text: string; next: number } {
  let i = start;
  let text = '';
  while (i < buf.length) {
    const size = buf[i]!;
    if (size === 0) return { text, next: i + 1 };
    text += latin1(buf.subarray(i + 1, i + 1 + size));
    i += 1 + size;
  }
  return { text, next: i };
}

export const gifHandler: FormatHandler = {
  id: 'gif',
  caps: FORMAT_CAPS.gif,
  parse(buffer) {
    return { records: parseGifMeta(buffer) };
  },
  strip(buffer) {
    return stripGif(buffer);
  },
};
