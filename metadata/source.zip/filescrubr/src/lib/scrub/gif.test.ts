import { describe, expect, it } from 'vitest';
import { ascii } from './bytes';
import { parseGifMeta, stripGif } from './gif';
import { sampleGif } from './test-fixtures';

describe('gif', () => {
  it('removes comments and keeps a valid GIF89a image', () => {
    const src = sampleGif();
    expect(parseGifMeta(src).some((r) => r.value.includes('secret'))).toBe(true);
    const out = stripGif(src);
    expect(ascii(out, 0, 6)).toBe('GIF89a');
    expect(out[out.length - 1]).toBe(0x3b);
    expect([...out].includes(0x2c)).toBe(true);
    expect(parseGifMeta(out)).toEqual([]);
    expect(new TextDecoder().decode(out)).not.toContain('secret');
  });
});
