export type FormatId =
  | 'jpeg'
  | 'png'
  | 'webp'
  | 'gif'
  | 'svg'
  | 'mp3'
  | 'wav'
  | 'm4a'
  | 'flac'
  | 'docx'
  | 'xlsx'
  | 'pptx'
  | 'csv'
  | 'pdf'
  | 'heic'
  | 'ole'
  | 'video'
  | 'unknown';

export interface MetadataRecord {
  group: string;
  key: string;
  value: string;
  writable: boolean;
  removable: boolean;
}

export interface FormatCaps {
  read: boolean;
  strip: boolean;
  edit: boolean;
  inspectOnlyReason?: string;
  inspectOnlyHint?: string;
}

export type ScrubErrorCode =
  | 'too_large'
  | 'multiple'
  | 'unsupported'
  | 'ole'
  | 'video'
  | 'parse_failed'
  | 'encrypted'
  | 'invalid_output'
  | 'heic_write'
  | 'nothing_removable'
  | 'download_failed'
  | 'timeout'
  | 'worker'
  | 'aborted'
  | 'generic'
  | 'busy';

export interface ParseResult {
  format: FormatId;
  mime: string;
  extension: string;
  records: MetadataRecord[];
  caps: FormatCaps;
  warnings: string[];
  orientation?: number;
}

export interface WriteResult {
  buffer: Uint8Array;
  records: MetadataRecord[];
  warnings: string[];
  removedCount: number;
  remainingRemovable: number;
}

export interface FormatParse {
  records: MetadataRecord[];
  orientation?: number;
  warnings?: string[];
}

export interface WriteContext {
  orientation?: number;
}

export interface FormatHandler {
  id: FormatId;
  caps: FormatCaps;
  parse(buffer: ArrayBuffer): FormatParse | Promise<FormatParse>;
  strip?(buffer: ArrayBuffer, ctx?: WriteContext): Uint8Array | Promise<Uint8Array>;
  edit?(buffer: ArrayBuffer, edits: Record<string, string>): Uint8Array | Promise<Uint8Array>;
}

export type WorkerOp = 'parse' | 'strip' | 'applyEdits';

export interface WorkerRequest {
  id: number;
  op: WorkerOp;
  filename: string;
  buffer: ArrayBuffer;
  edits?: Record<string, string>;
}

export interface WorkerResponse {
  id: number;
  ok: boolean;
  format?: FormatId;
  mime?: string;
  extension?: string;
  records?: MetadataRecord[];
  caps?: FormatCaps;
  warnings?: string[];
  buffer?: ArrayBuffer;
  removedCount?: number;
  remainingRemovable?: number;
  error?: { code: ScrubErrorCode; message: string; hint?: string };
}

export const FORMAT_CAPS: Record<FormatId, FormatCaps> = {
  jpeg: { read: true, strip: true, edit: true },
  png: { read: true, strip: true, edit: true },
  webp: { read: true, strip: true, edit: false },
  gif: { read: true, strip: true, edit: false },
  svg: { read: true, strip: true, edit: true },
  mp3: { read: true, strip: true, edit: true },
  wav: { read: true, strip: true, edit: true },
  m4a: { read: true, strip: true, edit: false },
  flac: { read: true, strip: true, edit: false },
  docx: { read: true, strip: true, edit: true },
  xlsx: { read: true, strip: true, edit: true },
  pptx: { read: true, strip: true, edit: true },
  csv: { read: true, strip: true, edit: false },
  pdf: { read: true, strip: true, edit: true },
  heic: {
    read: true,
    strip: false,
    edit: false,
    inspectOnlyReason: 'HEIC can be viewed but not rewritten in the browser.',
    inspectOnlyHint: 'Export as JPEG and drop that file to delete or edit metadata.',
  },
  ole: {
    read: false,
    strip: false,
    edit: false,
    inspectOnlyReason: 'Legacy .doc / .xls / .ppt are not supported.',
    inspectOnlyHint: 'Save as .docx, .xlsx, or .pptx and drop again.',
  },
  video: {
    read: false,
    strip: false,
    edit: false,
    inspectOnlyReason: 'Video files are not supported.',
    inspectOnlyHint: 'For audio in an MPEG-4 container, drop an .m4a file.',
  },
  unknown: {
    read: false,
    strip: false,
    edit: false,
    inspectOnlyReason: 'This file type is not supported.',
  },
};

export const FORMAT_LABEL: Record<FormatId, string> = {
  jpeg: 'JPEG',
  png: 'PNG',
  webp: 'WebP',
  gif: 'GIF',
  svg: 'SVG',
  mp3: 'MP3',
  wav: 'WAV',
  m4a: 'M4A',
  flac: 'FLAC',
  docx: 'DOCX',
  xlsx: 'XLSX',
  pptx: 'PPTX',
  csv: 'CSV',
  pdf: 'PDF',
  heic: 'HEIC',
  ole: '.doc / .xls / .ppt',
  video: 'Video',
  unknown: 'Unknown',
};

export function supportedLabel(): string {
  return (Object.keys(FORMAT_CAPS) as FormatId[])
    .filter((id) => FORMAT_CAPS[id].read && FORMAT_CAPS[id].strip)
    .map((id) => FORMAT_LABEL[id])
    .join(', ');
}

export const ACCEPT_ATTR = [
  '.jpg', '.jpeg', '.png', '.webp', '.gif', '.svg',
  '.mp3', '.wav', '.m4a', '.flac',
  '.docx', '.xlsx', '.pptx', '.csv', '.pdf',
  '.heic', '.heif',
  'image/jpeg', 'image/png', 'image/webp', 'image/gif', 'image/svg+xml',
  'audio/mpeg', 'audio/wav', 'audio/mp4', 'audio/flac',
  'application/pdf',
].join(',');
