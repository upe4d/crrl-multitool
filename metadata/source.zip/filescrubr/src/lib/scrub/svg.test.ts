import { describe, expect, it } from 'vitest';
import { applySvgEdits, hasActiveContent, parseSvg, stripSvg } from './svg';

describe('svg', () => {
  it('reports and strips script, handlers, and javascript URLs', () => {
    const src = `<svg xmlns="http://www.w3.org/2000/svg">
      <script>alert(1)</script>
      <a href="javascript:alert(2)">x</a>
      <rect width="1" height="1" onclick="evil()"/>
      <title>ok</title>
    </svg>`;
    expect(hasActiveContent(src)).toBe(true);
    expect(parseSvg(src).some((r) => r.key === 'active content')).toBe(true);
    const out = stripSvg(src);
    expect(out).not.toMatch(/<script/i);
    expect(out).not.toMatch(/onclick/i);
    expect(out).not.toMatch(/javascript:/i);
    expect(hasActiveContent(out)).toBe(false);
    expect(out).toContain('<title>ok</title>');
  });

  it('treats title and desc as editable, not removable', () => {
    const src = `<svg xmlns="http://www.w3.org/2000/svg">
      <title>Logo</title>
      <desc>Mark</desc>
    </svg>`;
    const records = parseSvg(src);
    expect(records.find((r) => r.key === 'title')).toMatchObject({ writable: true, removable: false });
    expect(records.find((r) => r.key === 'desc')).toMatchObject({ writable: true, removable: false });
    expect(records.every((r) => !r.removable)).toBe(true);
  });

  it('still reports comments and metadata as removable', () => {
    const src = `<svg xmlns="http://www.w3.org/2000/svg">
      <title>Logo</title>
      <!-- secret -->
      <metadata><rdf:RDF/></metadata>
    </svg>`;
    const records = parseSvg(src);
    expect(records.find((r) => r.key === 'title')?.removable).toBe(false);
    expect(records.find((r) => r.key === 'comments')?.removable).toBe(true);
    expect(records.find((r) => r.key === 'metadata')?.removable).toBe(true);
  });

  it('edits title and desc', () => {
    const src = `<svg xmlns="http://www.w3.org/2000/svg"><title>Logo</title><desc>Mark</desc><!-- x --></svg>`;
    const out = applySvgEdits(src, { title: 'Ada', desc: 'Note' });
    expect(out).toContain('<title>Ada</title>');
    expect(out).toContain('<desc>Note</desc>');
    expect(out).not.toContain('<!--');
  });
});
