import { describe, expect, it } from 'vitest';
import { parseWebpMeta, stripWebp } from './webp';
import { sampleWebp } from './test-fixtures';
import { ascii } from './bytes';

describe('webp', () => {
  it('reports EXIF and strips it', () => {
    const src = sampleWebp();
    expect(parseWebpMeta(src).some((r) => r.key === 'EXIF')).toBe(true);
    const out = stripWebp(src);
    expect(ascii(out, 0, 4)).toBe('RIFF');
    expect(ascii(out, 8, 4)).toBe('WEBP');
    expect(parseWebpMeta(out).some((r) => r.key === 'EXIF')).toBe(false);
  });
});
