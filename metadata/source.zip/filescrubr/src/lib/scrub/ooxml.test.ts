import { describe, expect, it } from 'vitest';
import { applyOoxmlEdits, parseOoxml, stripOoxml } from './ooxml';
import { sampleDocx, samplePptx, sampleXlsx, toBuffer } from './test-fixtures';

describe('ooxml', () => {
  it('parses and strips Word core properties', async () => {
    const src = await sampleDocx();
    const before = await parseOoxml(toBuffer(src), 'docx');
    expect(before.format).toBe('docx');
    expect(before.records.some((r) => r.key === 'title' && r.value === 'Secret Title')).toBe(true);
    const out = await stripOoxml(toBuffer(src));
    const after = await parseOoxml(toBuffer(out), 'docx');
    expect(after.records.some((r) => r.key === 'title' && r.value === 'Secret Title')).toBe(false);
    expect(after.records.some((r) => r.key === 'Company' && r.value === 'Secret Co')).toBe(false);
  });

  it('edits title and creator', async () => {
    const src = await sampleDocx();
    const out = await applyOoxmlEdits(toBuffer(src), { title: 'Ada', creator: 'Lovelace' });
    const after = await parseOoxml(toBuffer(out), 'docx');
    expect(after.records.some((r) => r.key === 'title' && r.value === 'Ada')).toBe(true);
    expect(after.records.some((r) => r.key === 'creator' && r.value === 'Lovelace')).toBe(true);
  });

  it('identifies xlsx and pptx', async () => {
    expect((await parseOoxml(toBuffer(await sampleXlsx()), 'xlsx')).format).toBe('xlsx');
    expect((await parseOoxml(toBuffer(await samplePptx()), 'pptx')).format).toBe('pptx');
  });
});
