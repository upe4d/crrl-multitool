import exifr from 'exifr';
import type { MetadataRecord } from './types';

const SKIP = new Set([
  'unprocessed', 'errors', 'thumbnail', 'MakerNote', 'UserComment', 'ComponentsConfiguration',
]);

const GPS_KEYS = new Set(['latitude', 'longitude', 'GPSLatitude', 'GPSLongitude', 'GPSAltitude', 'GPSImgDirection', 'GPSDateStamp', 'GPSTimeStamp']);

const STRUCTURAL_KEYS = new Set([
  'ImageWidth', 'ImageHeight', 'ExifImageWidth', 'ExifImageHeight',
  'PixelXDimension', 'PixelYDimension',
  'BitsPerSample', 'BitDepth', 'ColorType', 'Filter', 'Interlace',
  'Compression', 'PhotometricInterpretation', 'SamplesPerPixel',
  'PlanarConfiguration', 'Orientation',
  'XResolution', 'YResolution', 'ResolutionUnit',
  'ColorSpace', 'YCbCrPositioning', 'YCbCrCoefficients', 'YCbCrSubSampling',
  'ReferenceBlackWhite', 'WhitePoint', 'PrimaryChromaticities',
  'ExifVersion', 'FlashpixVersion',
  'JFIFVersion', 'JFIFUnits', 'XDensity', 'YDensity',
  'JFIFThumbnailWidth', 'JFIFThumbnailHeight',
  'ProfileDescription', 'ProfileVersion', 'ProfileClass', 'ColorSpaceData',
  'DeviceManufacturer', 'DeviceModel', 'ColorSpaceData',
  'InteropIndex', 'InteroperabilityIndex', 'InteroperabilityVersion',
]);

export function rec(
  group: string,
  key: string,
  value: string,
  writable: boolean,
  removable = true,
): MetadataRecord {
  return { group, key, value, writable, removable };
}

function isStructuralExif(key: string): boolean {
  if (STRUCTURAL_KEYS.has(key)) return true;
  const lower = key.toLowerCase();
  if (lower === 'orientation') return true;
  if (lower.startsWith('jfif')) return true;
  if (lower.includes('icc') || lower.startsWith('profile')) return true;
  if (lower === 'imagewidth' || lower === 'imageheight') return true;
  if (lower === 'pixelxdimension' || lower === 'pixelydimension') return true;
  if (lower === 'exifimagewidth' || lower === 'exifimageheight') return true;
  if (lower === 'bitdepth' || lower === 'colortype' || lower === 'filter' || lower === 'interlace') return true;
  return false;
}

function orientationNumber(raw: unknown): number | undefined {
  if (typeof raw === 'number' && raw >= 1 && raw <= 8) return raw;
  if (typeof raw === 'string') {
    const n = Number.parseInt(raw, 10);
    if (n >= 1 && n <= 8) return n;
  }
  return undefined;
}

export async function parseWithExifr(buffer: ArrayBuffer): Promise<{ records: MetadataRecord[]; orientation?: number; warning?: string }> {
  let parsed: Record<string, unknown> | undefined;
  let orientRaw: Record<string, unknown> | undefined;
  let warning: string | undefined;
  try {
    parsed = await exifr.parse(buffer, {
      tiff: true,
      xmp: true,
      icc: false,
      iptc: true,
      jfif: true,
      ihdr: true,
      gps: true,
      mergeOutput: true,
      reviveValues: true,
      translateKeys: true,
      translateValues: true,
      sanitize: true,
    }) as Record<string, unknown> | undefined;
  } catch {
    parsed = undefined;
    warning = 'Could not read embedded EXIF; showing file-level fields only.';
  }
  try {
    orientRaw = await exifr.parse(buffer, {
      tiff: true,
      pick: ['Orientation'],
      mergeOutput: true,
      translateKeys: false,
      translateValues: false,
    }) as Record<string, unknown> | undefined;
  } catch {
    orientRaw = undefined;
  }

  const records: MetadataRecord[] = [];
  let orientation = orientationNumber(
    orientRaw?.Orientation ?? orientRaw?.orientation ?? orientRaw?.[0x0112] ?? orientRaw?.['274'],
  );

  if (parsed) {
    for (const [key, raw] of Object.entries(parsed)) {
      if (SKIP.has(key) || raw == null) continue;
      if (key.toLowerCase() === 'orientation') {
        orientation = orientation ?? orientationNumber(raw);
      }
      const value = stringifyMeta(raw);
      if (!value) continue;
      const group = GPS_KEYS.has(key) || key.startsWith('GPS') ? 'GPS' : key.startsWith('IPTC') ? 'IPTC' : 'EXIF';
      const removable = !isStructuralExif(key);
      records.push(rec(group, key, value, false, removable));
    }
  }

  if (typeof parsed?.latitude === 'number' && typeof parsed?.longitude === 'number') {
    const existing = records.find((r) => r.key === 'coordinates');
    if (!existing) {
      records.unshift(rec(
        'GPS',
        'coordinates',
        `${(parsed.latitude as number).toFixed(6)}, ${(parsed.longitude as number).toFixed(6)}`,
        false,
        true,
      ));
    }
  }

  return { records, orientation, warning };
}

export function stringifyMeta(value: unknown): string {
  if (value == null) return '';
  if (typeof value === 'string') return value.trim();
  if (typeof value === 'number' || typeof value === 'boolean') return String(value);
  if (value instanceof Date) return value.toISOString();
  if (value instanceof Uint8Array || ArrayBuffer.isView(value)) {
    return `[embedded, ${(value as Uint8Array).byteLength} bytes]`;
  }
  if (Array.isArray(value)) {
    if (value.every((v) => typeof v === 'number') && value.length > 8) {
      return `[${value.length} numbers]`;
    }
    return value.map((v) => stringifyMeta(v)).filter(Boolean).join(', ');
  }
  if (typeof value === 'object') {
    try {
      const json = JSON.stringify(value);
      return json.length > 240 ? `${json.slice(0, 237)}…` : json;
    } catch {
      return '[object]';
    }
  }
  return String(value);
}

export function fileRecords(filename: string, format: string, bytes: number): MetadataRecord[] {
  return [
    rec('File', 'name', filename, false, false),
    rec('File', 'type', format, false, false),
    rec('File', 'size', `${bytes} bytes`, false, false),
  ];
}

export function countRemovable(records: MetadataRecord[]): number {
  return records.filter((r) => r.removable).length;
}

export function mergeWritable(records: MetadataRecord[], keys: string[]): MetadataRecord[] {
  const set = new Set(keys);
  return records.map((r) => (set.has(r.key) ? { ...r, writable: true } : r));
}
