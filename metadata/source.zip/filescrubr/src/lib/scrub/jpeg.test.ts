import { describe, expect, it } from 'vitest';
import { applyJpegEdits, stripJpeg } from './jpeg';
import { parseWithExifr } from './records';
import { sampleJpeg, toBuffer } from './test-fixtures';

function hasMarker(buf: Uint8Array, marker: number): boolean {
  for (let i = 0; i < buf.length - 1; i++) {
    if (buf[i] === 0xff && buf[i + 1] === marker) return true;
  }
  return false;
}

describe('jpeg', () => {
  it('strips APP1/COM and keeps numeric orientation', async () => {
    const src = sampleJpeg(6);
    const { orientation } = await parseWithExifr(toBuffer(src));
    expect(orientation).toBe(6);

    const out = stripJpeg(src, orientation);
    expect(out[0]).toBe(0xff);
    expect(out[1]).toBe(0xd8);
    expect(hasMarker(out, 0xfe)).toBe(false);
    expect(hasMarker(out, 0xe1)).toBe(true);

    const { orientation: kept } = await parseWithExifr(toBuffer(out));
    expect(kept).toBe(6);
  });

  it('writes Artist and can clear it', async () => {
    const src = sampleJpeg();
    const edited = applyJpegEdits(src, { Artist: 'Ada Lovelace' });
    const { records } = await parseWithExifr(toBuffer(edited));
    expect(records.some((r) => r.key === 'Artist' && r.value.includes('Ada'))).toBe(true);

    const cleared = applyJpegEdits(edited, { Artist: '' });
    const after = await parseWithExifr(toBuffer(cleared));
    expect(after.records.some((r) => r.key === 'Artist')).toBe(false);
  });
});
