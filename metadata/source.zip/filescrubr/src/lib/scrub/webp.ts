import { ascii, concat, u32le, u8 } from './bytes';
import { ScrubError } from './errors';
import { parseWithExifr, rec } from './records';
import { walkRiff } from './riff';
import { FORMAT_CAPS, type FormatHandler, type MetadataRecord } from './types';

export function parseWebpMeta(buffer: ArrayBuffer | Uint8Array): MetadataRecord[] {
  const records: MetadataRecord[] = [];
  walkRiff(u8(buffer), 'WEBP', (fourcc, data) => {
    if (fourcc === 'EXIF') records.push(rec('WebP', 'EXIF', `[embedded, ${data.length} bytes]`, false, true));
    if (fourcc === 'XMP ') records.push(rec('WebP', 'XMP', `[embedded, ${data.length} bytes]`, false, true));
    if (fourcc === 'ICCP') records.push(rec('WebP', 'ICC profile', `[embedded, ${data.length} bytes]`, false, false));
  });
  return records;
}

export function stripWebp(buffer: ArrayBuffer | Uint8Array): Uint8Array {
  const buf = u8(buffer);
  if (ascii(buf, 0, 4) !== 'RIFF' || ascii(buf, 8, 4) !== 'WEBP') {
    throw new ScrubError('parse_failed', 'Not a valid WebP file.');
  }
  const parts: Uint8Array[] = [];
  let i = 12;
  while (i + 8 <= buf.length) {
    const fourcc = ascii(buf, i, 4);
    const size = u32le(buf, i + 4);
    const padded = size + (size % 2);
    const end = i + 8 + padded;
    if (end > buf.length + 1) break;
    if (fourcc === 'VP8X' && size >= 1) {
      const copy = buf.slice(i, Math.min(end, buf.length));
      copy[8] = copy[8]! & ~(1 << 3) & ~(1 << 4);
      parts.push(copy);
    } else if (fourcc !== 'EXIF' && fourcc !== 'XMP ') {
      parts.push(buf.subarray(i, Math.min(end, buf.length)));
    }
    i = end;
  }
  const body = concat(parts);
  const out = new Uint8Array(12 + body.length);
  out.set(buf.subarray(0, 12), 0);
  out.set(body, 12);
  const view = new DataView(out.buffer);
  view.setUint32(4, out.length - 8, true);
  return out;
}

export const webpHandler: FormatHandler = {
  id: 'webp',
  caps: FORMAT_CAPS.webp,
  async parse(buffer) {
    const { records, orientation, warning } = await parseWithExifr(buffer);
    return {
      records: records.length ? records : parseWebpMeta(buffer),
      orientation,
      warnings: warning ? [warning] : [],
    };
  },
  strip(buffer) {
    return stripWebp(buffer);
  },
};
