import { FEATURE_LIST, RELATED_TOOLS, SITE } from './site';
import { formatCopyPlain } from './scrub/copy';

export type JsonLd = Record<string, unknown>;

function absoluteUrl(path: string): string {
  return new URL(path, SITE.url).toString();
}

const ogImageUrl = () => absoluteUrl(SITE.ogImage);

export function websiteJsonLd(): JsonLd {
  return {
    '@context': 'https://schema.org',
    '@type': 'WebSite',
    name: SITE.name,
    url: SITE.url,
    description: SITE.description,
    inLanguage: 'en',
    image: ogImageUrl(),
  };
}

export function webApplicationJsonLd(): JsonLd {
  return {
    '@context': 'https://schema.org',
    '@type': 'WebApplication',
    name: SITE.name,
    url: SITE.url,
    description: SITE.description,
    applicationCategory: 'UtilitiesApplication',
    operatingSystem: 'Any',
    browserRequirements: 'Requires a modern web browser with File API support',
    isAccessibleForFree: true,
    offers: {
      '@type': 'Offer',
      price: '0',
      priceCurrency: 'USD',
    },
    featureList: FEATURE_LIST,
    screenshot: ogImageUrl(),
    image: ogImageUrl(),
  };
}

export function faqPageJsonLd(): JsonLd {
  return {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: [
      {
        '@type': 'Question',
        name: 'What is File Scrubr?',
        acceptedAnswer: {
          '@type': 'Answer',
          text: `File Scrubr is a free online tool for editing and deleting file metadata. All processing happens client-side in the browser. Developed by ${SITE.publisher.name}.`,
        },
      },
      {
        '@type': 'Question',
        name: 'Do you offer any other free online tools?',
        acceptedAnswer: {
          '@type': 'Answer',
          text: `Yes, for all your file conversion needs, check out ${RELATED_TOOLS[0].name} — a free privacy-first file convertor supporting many popular file types. We also have ${RELATED_TOOLS[1].name} — a free, modern bible browser and random verse generator.`,
        },
      },
      {
        '@type': 'Question',
        name: 'Does File Scrubr upload my files?',
        acceptedAnswer: {
          '@type': 'Answer',
          text: 'File Scrubr is a static website. Your file is read with the browser File API, parsed locally, and downloaded from a blob URL. Nothing is uploaded. There is no server-side processing and no analytics.',
        },
      },
      {
        '@type': 'Question',
        name: 'What files can I scrub?',
        acceptedAnswer: {
          '@type': 'Answer',
          text: formatCopyPlain(),
        },
      },
      {
        '@type': 'Question',
        name: 'What are the limits?',
        acceptedAnswer: {
          '@type': 'Answer',
          text: 'One file at a time. 50 MB maximum (20 MB on devices with under 4 GB of RAM). Password-protected and damaged files cannot be opened. Delete removes what this app can reach; a warning is shown if some tags remain.',
        },
      },
    ],
  };
}

export function breadcrumbJsonLd(): JsonLd {
  return {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: [
      {
        '@type': 'ListItem',
        position: 1,
        name: 'Home',
        item: absoluteUrl('/'),
      },
      {
        '@type': 'ListItem',
        position: 2,
        name: 'About',
        item: absoluteUrl('/about/'),
      },
    ],
  };
}

export function homeJsonLd(): JsonLd[] {
  return [websiteJsonLd(), webApplicationJsonLd()];
}

export function aboutJsonLd(): JsonLd[] {
  return [webApplicationJsonLd(), faqPageJsonLd(), breadcrumbJsonLd()];
}
