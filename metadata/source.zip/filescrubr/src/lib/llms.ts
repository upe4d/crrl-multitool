import { RELATED_TOOLS, SITE, SUPPORTED_LABEL } from './site';
import { formatCopyLines } from './scrub/copy';

export function robotsTxt(): string {
  const agents = [
    'GPTBot',
    'ChatGPT-User',
    'Google-Extended',
    'Bingbot',
    'ClaudeBot',
    'PerplexityBot',
    'Applebot-Extended',
  ];

  const aiBlocks = agents
    .map((agent) => `User-agent: ${agent}\nAllow: /`)
    .join('\n\n');

  return [
    'User-agent: *',
    'Allow: /',
    '',
    aiBlocks,
    '',
    `Sitemap: ${new URL('/sitemap-index.xml', SITE.url).toString()}`,
    '',
  ].join('\n');
}

export function llmsTxt(): string {
  return `# ${SITE.name}

> ${SITE.description}

${SITE.name} is a privacy-first file metadata editor. It is a free online tool for editing and deleting file metadata. All processing happens client-side in the browser. Developed by ${SITE.publisher.name} (${SITE.publisher.url}). Files are read with the browser File API, parsed locally, and downloaded from a blob URL. Nothing is uploaded. There is no server-side processing and no analytics.

Supported formats: ${SUPPORTED_LABEL}. HEIC tags can be viewed when the browser can parse them; rewriting is not supported. Legacy .doc, .xls, and .ppt are not supported.

Limits: one file at a time, 50 MB maximum (20 MB on devices with under 4 GB of RAM). Password-protected and damaged files cannot be opened.

Related tools: ${RELATED_TOOLS[0].name} (${RELATED_TOOLS[0].url}) for privacy-first file conversion, and ${RELATED_TOOLS[1].name} (${RELATED_TOOLS[1].url}) for a modern bible browser and random verse generator.

## Pages

- [Home](${SITE.url}/): In-browser metadata scrubber. Drop a file to inspect, edit, or delete metadata.
- [About](${SITE.url}/about/): What File Scrubr is, related tools, privacy model, supported formats, and limits.

## Optional

- [Full documentation for LLMs](${SITE.url}/llms-full.txt)
`;
}

export function llmsFullTxt(): string {
  return `# ${SITE.name}

> ${SITE.description}

${SITE.name} is a privacy-first file metadata editor developed by ${SITE.publisher.name} (${SITE.publisher.url}). It is a static website hosted as a Cloudflare Pages build. There are no server functions and no uploads. A file is read with the browser File API, parsed locally in JavaScript, and downloaded from a blob URL. You can confirm this in DevTools → Network: no file bytes leave the page. There is no analytics.

Related tools: ${RELATED_TOOLS[0].name} (${RELATED_TOOLS[0].url}) is a free privacy-first file convertor supporting many popular file types. ${RELATED_TOOLS[1].name} (${RELATED_TOOLS[1].url}) is a free, modern bible browser and random verse generator.

## Product

- Inspect metadata tags in images, audio, Office files, CSV, and PDFs
- Delete metadata the app can reach
- Edit common tags on supported formats
- JPEG orientation is preserved so photos do not rotate after a scrub
- One file at a time
- 50 MB maximum (20 MB on devices with under 4 GB of RAM)
- Password-protected and damaged files cannot be opened
- Delete removes what this app can reach; a warning is shown if some tags remain

## Supported formats

${formatCopyLines().map((line) => `- ${line}`).join('\n')}

## How a browser scrub works

### Office documents (.docx, .xlsx, .pptx)

Modern Office files are compressed ZIP archives containing nested XML. They often hold author and company names in docProps/core.xml, editing time and revision history, change tracking or comments, and local printer or file paths.

The app unzips the file, parses docProps/core.xml and app.xml, strips or sanitizes those tags, removes review tracking nodes where it can, and re-zips the document for download.

### Vector graphics (.svg)

SVGs are plain-text XML. Design tools frequently inject creator tags, layer names, creation dates, hardcoded absolute file paths, and hidden layers that still contain draft artwork.

The browser parses the text with DOMParser, strips metadata, comments, and editor-specific attributes, and removes elements marked hidden.

### Audio (.mp3, .m4a, .wav)

Audio files can carry ID3 or INFO tags beyond track names: recording software, hardware identifiers, GPS from mobile recorders, and private encoder tags.

JavaScript reads the file as an ArrayBuffer, locates ID3v2 headers or WAV INFO chunks, zeroes or overwrites those frames, and outputs the cleaned blob.

## Pages

- Home: ${SITE.url}/
- About: ${SITE.url}/about/
`;
}
