import { supportedLabel } from './scrub/types';

export const SITE = {
  name: 'File Scrubr',
  url: 'https://filescrubr.com',
  locale: 'en_US',
  description:
    'Inspect, edit, and delete metadata from images, audio, Office files, and PDFs in your browser. Files never leave your device.',
  keywords: [
    'metadata scrubber',
    'EXIF remover',
    'strip metadata',
    'remove EXIF from photos',
    'PDF metadata editor',
    'Office document properties',
    'DOCX metadata',
    'file metadata',
    'privacy',
    'in-browser',
    'no upload',
    'SVG metadata',
    'audio ID3 tags',
  ],
  ogImage: '/assets/og.png',
  ogImageAlt:
    'File Scrubr — inspect, edit, and delete file metadata in your browser. Files never leave your device.',
  ogImageType: 'image/png',
  ogImageWidth: 1200,
  ogImageHeight: 630,
  themeColor: '#000000',
  publisher: {
    name: 'montanadigital.dev',
    url: 'https://montanadigital.dev',
  },
  github: 'https://github.com/montana-digital/filescrubr',
};

export const RELATED_TOOLS = [
  { name: 'askjeeves.cc', url: 'https://askjeeves.cc' },
  { name: 'blessedtxts.com', url: 'https://blessedtxts.com' },
];

export const SUPPORTED_LABEL = supportedLabel();

export const FEATURE_LIST = [
  'Inspect file metadata in the browser',
  'Delete EXIF and other metadata tags',
  'Edit metadata on supported formats',
  'No uploads — files never leave the device',
  SUPPORTED_LABEL,
];

export const ABOUT_DESCRIPTION =
  'How File Scrubr reads, edits, and deletes EXIF, Office, PDF, and audio metadata entirely in your browser. Files never leave your device.';
