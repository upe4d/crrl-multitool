import { expect, test } from '@playwright/test';
import { FORMAT_CAPS, type FormatId } from '../src/lib/scrub/types';
import { fixtureFor } from '../src/lib/scrub/test-fixtures';

const SMOKE: FormatId[] = [
  'jpeg', 'png', 'webp', 'gif', 'svg', 'mp3', 'wav', 'm4a', 'flac',
  'docx', 'xlsx', 'pptx', 'csv', 'pdf', 'heic',
];

test.describe('per-format smoke', () => {
  for (const format of SMOKE) {
    test(`loads ${format}`, async ({ page }) => {
      const file = await fixtureFor(format);
      await page.goto('/');
      await page.locator('#scrub-input').setInputFiles({
        name: file.filename,
        mimeType: file.mime,
        buffer: Buffer.from(file.bytes),
      });
      await expect(page.locator('#scrub-results')).toBeVisible({ timeout: 15_000 });
      await expect(page.locator('#scrub-filename')).toContainText(file.filename);
      const status = page.locator('#scrub-status');
      await expect(status).not.toHaveAttribute('data-kind', 'error');

      const caps = FORMAT_CAPS[format];
      if (!caps.edit) await expect(page.locator('#btn-edit')).toBeHidden();
      if (!caps.strip) await expect(page.locator('#btn-delete')).toBeHidden();
    });
  }
});
