import { expect, test } from '@playwright/test';
import { sampleCsv, sampleHeic, sampleOle, samplePng, sampleUnknown, sampleVideo, truncated } from '../src/lib/scrub/test-fixtures';

async function drop(page: import('@playwright/test').Page, name: string, mime: string, bytes: Uint8Array) {
  await page.locator('#scrub-input').setInputFiles({
    name,
    mimeType: mime,
    buffer: Buffer.from(bytes),
  });
}

test.describe('error journeys', () => {
  test('unsupported file shows an error hint and keeps the dropzone', async ({ page }) => {
    await page.goto('/');
    await drop(page, 'notes.bin', 'application/octet-stream', sampleUnknown());
    const status = page.locator('#scrub-status');
    await expect(status).toHaveAttribute('data-kind', 'error');
    await expect(status).toContainText('not supported');
    await expect(page.locator('#scrub-results')).toBeHidden();
  });

  test('legacy OLE is rejected with a save-as hint', async ({ page }) => {
    await page.goto('/');
    await drop(page, 'report.doc', 'application/msword', sampleOle());
    await expect(page.locator('#scrub-status')).toHaveAttribute('data-kind', 'error');
    await expect(page.locator('#scrub-status')).toContainText('.docx');
  });

  test('video is rejected', async ({ page }) => {
    await page.goto('/');
    await drop(page, 'clip.mp4', 'video/mp4', sampleVideo());
    await expect(page.locator('#scrub-status')).toHaveAttribute('data-kind', 'error');
    await expect(page.locator('#scrub-status')).toContainText('Video files are not supported');
  });

  test('HEIC is inspect-only', async ({ page }) => {
    await page.goto('/');
    await drop(page, 'photo.heic', 'image/heic', sampleHeic());
    await expect(page.locator('#scrub-results')).toBeVisible();
    await expect(page.locator('#scrub-status')).toHaveAttribute('data-kind', 'warn');
    await expect(page.locator('#btn-delete')).toBeHidden();
    await expect(page.locator('#btn-edit')).toBeHidden();
  });

  test('CSV without a BOM has no Delete action', async ({ page }) => {
    await page.goto('/');
    await drop(page, 'data.csv', 'text/csv', sampleCsv(false));
    await expect(page.locator('#scrub-results')).toBeVisible();
    await expect(page.locator('#btn-delete')).toBeHidden();
    await expect(page.locator('#scrub-status')).toContainText('No removable metadata');
  });

  test('truncated PNG shows a parse error', async ({ page }) => {
    await page.goto('/');
    await drop(page, 'shot.png', 'image/png', truncated(samplePng(), 20));
    await expect(page.locator('#scrub-status')).toHaveAttribute('data-kind', 'error');
    await expect(page.locator('#scrub-status')).toContainText('Could not read this file');
    await expect(page.locator('#scrub-results')).toBeHidden();
  });

  test('two files dropped at once are rejected', async ({ page }) => {
    await page.goto('/');
    await page.evaluate(() => {
      const dt = new DataTransfer();
      dt.items.add(new File(['a'], 'a.png', { type: 'image/png' }));
      dt.items.add(new File(['b'], 'b.png', { type: 'image/png' }));
      const drop = document.getElementById('dropzone');
      drop?.dispatchEvent(new DragEvent('drop', { bubbles: true, cancelable: true, dataTransfer: dt }));
    });
    await expect(page.locator('#scrub-status')).toContainText('Drop one file at a time');
  });
});
