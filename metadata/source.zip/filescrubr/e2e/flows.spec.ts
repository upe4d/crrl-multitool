import { expect, test } from '@playwright/test';
import { sampleJpeg, samplePng, sampleSvg } from '../src/lib/scrub/test-fixtures';

test.describe('scrub flows', () => {
  test('strips PNG metadata and keeps Download available', async ({ page }) => {
    await page.goto('/');
    const [download] = await Promise.all([
      page.waitForEvent('download'),
      (async () => {
        await page.locator('#scrub-input').setInputFiles({
          name: 'shot.png',
          mimeType: 'image/png',
          buffer: Buffer.from(samplePng()),
        });
        await expect(page.locator('#scrub-results')).toBeVisible();
        await page.locator('#btn-delete').click();
      })(),
    ]);
    expect(download.suggestedFilename()).toMatch(/-scrubbed\.png$/);
    await expect(page.locator('#scrub-status')).toContainText(/Removed \d+ field/);
    await expect(page.locator('#btn-download')).toBeVisible();
  });

  test('edits SVG title, saves, and downloads', async ({ page }) => {
    await page.goto('/');
    await page.locator('#scrub-input').setInputFiles({
      name: 'logo.svg',
      mimeType: 'image/svg+xml',
      buffer: Buffer.from(sampleSvg('<title>Logo</title><desc>Mark</desc><!-- secret -->')),
    });
    await expect(page.locator('#scrub-results')).toBeVisible();
    await page.locator('#btn-edit').click();
    await page.locator('[data-edit-key="title"]').fill('Ada');
    await page.locator('#btn-save').click();
    await expect(page.locator('#scrub-status')).toContainText('Changes saved');
    const [download] = await Promise.all([
      page.waitForEvent('download'),
      page.locator('#btn-download').click(),
    ]);
    expect(download.suggestedFilename()).toMatch(/-scrubbed\.svg$/);
  });

  test('Escape cancels edit and Clear restores the dropzone', async ({ page }) => {
    await page.goto('/');
    await page.locator('#scrub-input').setInputFiles({
      name: 'photo.jpg',
      mimeType: 'image/jpeg',
      buffer: Buffer.from(sampleJpeg()),
    });
    await expect(page.locator('#scrub-results')).toBeVisible();
    await page.locator('#btn-edit').click();
    await expect(page.locator('#btn-save')).toBeVisible();
    await page.keyboard.press('Escape');
    await expect(page.locator('#scrub-status')).toContainText('Edit cancelled');
    await page.locator('#btn-clear').click();
    await expect(page.locator('#scrub-results')).toBeHidden();
    await expect(page.locator('#scrub-status')).toContainText('Ready');
  });
});
