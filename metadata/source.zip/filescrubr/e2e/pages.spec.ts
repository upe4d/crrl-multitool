import { expect, test } from '@playwright/test';

test.describe('pages', () => {
  test('home shows the dropzone', async ({ page }) => {
    await page.goto('/');
    await expect(page.getByRole('heading', { name: 'File Scrubr' })).toBeVisible();
    await expect(page.locator('#dropzone')).toBeVisible();
    await expect(page.locator('#scrub-status')).toContainText('Ready');
  });

  test('about lists format capabilities', async ({ page }) => {
    await page.goto('/about/');
    await expect(page.getByRole('heading', { name: 'About' })).toBeVisible();
    await expect(page.locator('body')).toContainText('JPEG, PNG');
    await expect(page.locator('body')).toContainText('HEIC');
    await expect(page.locator('body')).toContainText('Privacy first, file metadata editor');
    await expect(page.getByRole('heading', { name: 'What is File Scrubr?' })).toBeVisible();
    await expect(page.getByRole('heading', { name: 'Do you offer any other free online tools?' })).toBeVisible();
    await expect(page.locator('.footer').getByRole('link', { name: 'File Scrubr' })).toHaveAttribute(
      'href',
      '/',
    );
    await expect(page.locator('.footer').getByRole('link', { name: 'montanadigital.dev' })).toHaveAttribute(
      'href',
      'https://montanadigital.dev',
    );
    await expect(page.locator('.footer').getByRole('link', { name: 'GitHub repository' })).toHaveAttribute(
      'href',
      'https://github.com/montana-digital/filescrubr',
    );
  });

  test('unknown routes render 404', async ({ page }) => {
    const res = await page.goto('/no-such-page/');
    expect(res?.status()).toBe(404);
    await expect(page.getByRole('heading', { name: '404' })).toBeVisible();
    await expect(page.getByRole('link', { name: 'Go home' })).toBeVisible();
  });

  test('nav moves between home and about', async ({ page }) => {
    await page.goto('/');
    await page.locator('.nav-links').getByRole('link', { name: 'About' }).click();
    await expect(page).toHaveURL(/\/about\/$/);
    await page.locator('.nav-links').getByRole('link', { name: 'Home' }).click();
    await expect(page).toHaveURL(/\/$/);
  });

  test('home head has indexable SEO metadata', async ({ page }) => {
    await page.goto('/');
    const canonical = page.locator('link[rel="canonical"]');
    await expect(canonical).toHaveAttribute('href', 'https://filescrubr.com/');
    await expect(page.locator('meta[property="og:image"]')).toHaveAttribute(
      'content',
      'https://filescrubr.com/assets/og.png',
    );
    await expect(page.locator('meta[name="robots"]')).toHaveAttribute(
      'content',
      'index, follow, max-image-preview:large',
    );
    await expect(page.locator('link[rel="alternate"][href="/llms.txt"]')).toHaveCount(1);

    const jsonLd = await page
      .locator('script[type="application/ld+json"]')
      .evaluateAll((els) => els.map((el) => el.textContent ?? ''));
    expect(jsonLd.join('\n')).toContain('"WebSite"');
    expect(jsonLd.join('\n')).toContain('"WebApplication"');
  });

  test('404 is excluded from indexing', async ({ page }) => {
    await page.goto('/no-such-page/');
    await expect(page.locator('meta[name="robots"]')).toHaveAttribute('content', 'noindex, nofollow');
    await expect(page.locator('link[rel="canonical"]')).toHaveCount(0);
    await expect(page.locator('script[type="application/ld+json"]')).toHaveCount(0);
  });
});
