# Contributing to File Scrubr

Thanks for taking an interest. This is a small static Astro site: metadata parsing runs entirely in the browser.

## Setup

- Node 22+ (`.nvmrc`)
- `npm install`
- `npm run dev` — local site
- `npm test` — Vitest unit tests
- `npm run check` — `astro check` / TypeScript
- `npm run test:e2e` — Playwright (builds the site first)

Please run `npm test` and `npm run check` before opening a pull request.

## Layout

| Path | Role |
| --- | --- |
| `src/lib/scrub/` | Domain engine: detect, handlers, engine, errors, types |
| `src/workers/scrub.worker.ts` | Worker wrapper around `handleJob` |
| `src/scripts/scrub/` | UI: dropzone, table, status, download, session |
| `src/pages/` | Astro pages and static text routes |
| `src/layouts/` | Document shell |
| `e2e/` | Playwright specs |

## Adding a format

1. Add the id to `FormatId` and `FORMAT_CAPS` in `src/lib/scrub/types.ts`.
2. Add user-facing copy to `FORMAT_COPY` in `src/lib/scrub/copy.ts`.
3. Teach `src/lib/scrub/detect.ts` how to recognize the file (extension and/or magic bytes).
4. Implement `parse` / `strip` / `edit` in `src/lib/scrub/<format>.ts` and export a `FormatHandler`.
5. Register it in `src/lib/scrub/registry.ts`.
6. Add a fixture in `src/lib/scrub/test-fixtures.ts` and a colocated `*.test.ts`.
7. Extend `e2e/scrub.spec.ts` if the format should appear in the smoke list.

Handlers must not throw raw library messages at the user. Use `ScrubError` / `Errors` from `src/lib/scrub/errors.ts`.

## Product copy

Format capability text lives in `FORMAT_COPY`. About, `/llms-full.txt`, and the FAQ JSON-LD all read from that list. Do not duplicate those bullets in page markup.

## License

By contributing, you agree that your work is licensed under AGPL-3.0-or-later, the same license as the project.
